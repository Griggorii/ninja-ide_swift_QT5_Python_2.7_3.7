
import sys
from PyQt5.QtWidgets import QApplication
from dialog import Python3.7


if __name__ == "__main__":
    app = QApplication(sys.argv)
    widget = Python3.7()
    widget.show()
    sys.exit(app.exec_())

