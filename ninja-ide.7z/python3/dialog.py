
from PyQt5.QtWidgets import QDialog


class Python3.7(QDialog):

    def __init__(self, parent=None):
        super().__init__(parent)
