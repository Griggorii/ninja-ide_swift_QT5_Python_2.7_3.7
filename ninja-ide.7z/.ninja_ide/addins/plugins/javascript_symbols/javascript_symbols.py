# -*- coding: utf-8 *-*

import re

from ninja_ide.core import plugin
from ninja_ide.core import plugin_interfaces

EXTENSION = 'js'


class JavascriptSymbols(plugin.Plugin):

    def initialize(self):
        self.explorer_s = self.locator.get_service('explorer')
        # Set a project handler for NINJA-IDE Plugin
        self.explorer_s.set_symbols_handler(
            EXTENSION, JavascriptSymbolsHandler()
        )


class JavascriptSymbolsHandler(plugin_interfaces.ISymbolsHandler):

    _r_function = re.compile(r'^\s*function\s*([a-zA-Z0-9_-]+)\s*\(')
    _r_function_var = re.compile(
        r'^\s*(?:var\s+)?([a-zA-Z0-9_-]+)\s*=\s*function\s*\('
    )
    _r_angular_statement = re.compile(
        r'''^\s*([a-zA-Z0-9_-]+)\.(directive|controller|service|filter|factory)\s*\(['"]([a-zA-Z0-9_-]+)'''
    )

    def obtain_symbols(self, source):
        """Returns a dict with the javascript symbols for sources."""

        functions = {}

        fun, varfun, ang = self._r_function, self._r_function_var, self._r_angular_statement

        for nro, line in enumerate(source.split('\n')):

            if not line:
                continue

            m = fun.match(line) or varfun.match(line) or ang.match(line)
            if not m:
                continue

            groups = m.groups()
            if len(groups) == 1:
                name = groups[0]
            else:
                name = "angular %s %s: %s" % groups
            functions[name] = {'functions':[],'lineno':nro+1}

        return {'functions': functions}
