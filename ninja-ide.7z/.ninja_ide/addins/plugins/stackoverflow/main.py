# -*- coding: utf-8 -*-
# PEP8:OK, LINT:OK, PY3:OK


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" StackOverflow Ninja "
__version__ = ' 0.4 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 15/07/2013 '
__prj__ = ' stackoverflow '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from sip import setapi
from datetime import datetime
from subprocess import call
try:
    from commands import getoutput
except ImportError:
    from subprocess import check_output as getoutput  # lint:ok

from PyQt4.QtGui import (QLabel, QPushButton, QWidget, QDockWidget, QVBoxLayout,
    QSizePolicy, QCursor, QLineEdit, QIcon, QCheckBox, QColor, QApplication,
    QMessageBox, QGraphicsDropShadowEffect, QSpinBox, QScrollArea, QTextEdit)

from PyQt4.QtCore import Qt

from ninja_ide.gui.explorer.explorer_container import ExplorerContainer
from ninja_ide.core import plugin


# API 2
(setapi(a, 2) for a in ("QDate", "QDateTime", "QString", "QTime", "QUrl",
                        "QTextStream", "QVariant"))


# constans
HELPMSG = '''
<h3>StackOverflow Ninja</h3>
Query StackOverflow to <b>help you solve problems</b>.<br><br>
<i>This is a Frontend to <a href="https://github.com/gleitz/howdoi">HowDoI</a>
</i><br><br>
''' + ''.join((__doc__, __version__, __license__, 'by', __author__, __email__))


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.answer, self.numbera = QLineEdit(), QSpinBox()
        self.answer.setPlaceholderText(' how to format string ')
        self.answer.returnPressed.connect(self.run)
        self.answer.setFocus()
        self.numbera.setValue(3)
        self.chckbx1 = QCheckBox('Display the full text of the answers')
        self.chckbx2 = QCheckBox('Display only the Link of the answers')
        self.chckbx3 = QCheckBox('Copy full text of the answers to Clipboard')
        self.chckbx4 = QCheckBox('Search only Python related answers')
        self.chckbx5 = QCheckBox('Clear all the Cache on Exit')
        self.chrt = QCheckBox('LOW CPU priority for Backend Process')
        [_.setChecked(True) for _ in (self.chrt, self.chckbx4)]
        self.output, self.lastone = QTextEdit(), QLabel()
        self.output.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.button = QPushButton('Search solution')
        self.button.setCursor(QCursor(Qt.PointingHandCursor))
        self.button.setMinimumSize(100, 50)
        self.button.clicked.connect(self.run)
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0)
        glow.setBlurRadius(99)
        glow.setColor(QColor(99, 255, 255))
        self.button.setGraphicsEffect(glow)
        glow.setEnabled(True)

        class TransientWidget(QWidget):
            ' persistant widget thingy '
            def __init__(self, widget_list):
                ' init sub class '
                super(TransientWidget, self).__init__()
                vbox = QVBoxLayout(self)
                for each_widget in widget_list:
                    vbox.addWidget(each_widget)

        tw = TransientWidget((QLabel('<i>Ask Questions and get Solutions !'),
            QLabel('<b>Ask a Question:'), self.answer, self.chckbx1,
            self.chckbx2, self.chckbx3, self.chckbx4, self.chrt, self.chckbx5,
            QLabel('<b>Number of answers (Best answer ordered):'), self.numbera,
            QLabel('<b>Get Solutions:'), self.output, self.lastone, self.button,
        ))
        self.scrollable, self.dock = QScrollArea(), QDockWidget()
        self.scrollable.setWidgetResizable(True)
        self.scrollable.setWidget(tw)
        self.dock.setWindowTitle(__doc__)
        self.dock.setStyleSheet('QDockWidget::title{text-align: center;}')
        self.dock.setWidget(self.scrollable)
        ExplorerContainer().addTab(self.dock, "StackOverflow")
        QPushButton(QIcon.fromTheme("help-about"), 'About', self.dock
        ).clicked.connect(lambda: QMessageBox.information(self.dock, __doc__,
        HELPMSG))

    def run(self):
        ' run the encoding '
        self.button.setDisabled(True)
        self.output.clear()
        self.output.setText(getoutput(' '.join((
            'chrt -i 0' if self.chrt.isChecked() is True else '', 'howdoi',
            '--all' if self.chckbx1.isChecked() is True else '',
            '--link' if self.chckbx2.isChecked() is True else '',
            '--num-answers {}'.format(self.numbera.value()), self.answer.text(),
            'python' if self.chckbx4.isChecked() is True else ''))))
        if self.chckbx3.isChecked() is True:
            QApplication.clipboard().setText(self.output.toPlainText())
        self.lastone.setText('<b>Last Answers:</b> {}'.format(
            datetime.today().isoformat().split('.')[0]))
        self.output.selectAll()
        self.output.setFocus()
        self.button.setDisabled(False)

    def finish(self):
        ' clear when finish '
        if self.chckbx5.isChecked() is True:
            call('howdoi --clear-cache', shell=True)


###############################################################################


if __name__ == "__main__":
    print(__doc__)
