# -*- coding: utf-8 -*-
# PEP8:OK, LINT:OK, PY3:OK


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja Sphinx "
__version__ = ' 0.8 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 10/10/2013 '
__prj__ = ' " sphinx '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path, linesep, chmod
from sip import setapi
from datetime import datetime
from subprocess import call

from PyQt4.QtGui import (QLabel, QCompleter, QDirModel, QPushButton, QWidget,
  QFileDialog, QDockWidget, QVBoxLayout, QSizePolicy, QCursor, QLineEdit, QIcon,
  QCheckBox, QGraphicsDropShadowEffect, QColor, QMessageBox, QGroupBox,
  QComboBox, QGraphicsBlurEffect, QScrollArea)

from PyQt4.QtCore import Qt, QDir, QProcess

try:
    from PyKDE4.kdeui import KTextEdit as QTextEdit
except ImportError:
    from PyQt4.QtGui import QTextEdit  # lint:ok


from ninja_ide.gui.explorer.explorer_container import ExplorerContainer
from ninja_ide.core import plugin


# API 2
(setapi(a, 2) for a in ("QDate", "QDateTime", "QString", "QTime", "QUrl",
                        "QTextStream", "QVariant"))


# constans
HELPMSG = ''.join((__doc__, ',v', __version__, __license__, 'by', __author__))
CSS3 = '''

@import url(http://bootswatch.com/CSSCUSTOM/bootstrap.min.css);

@import url(https://fonts.googleapis.com/css?family=CSSWEBFONT);
    *{font-family:'CSSWEBFONT';border-radius:5px}

body,.body{background-color:transparent;
    background:url(
    'http://subtlepatterns.subtlepatterns.netdna-cdn.com/patterns/CSSBACKGR.png'
    ) no-repeat center center fixed;
    -webkit-background-size:cover;-moz-background-size:cover;
    -o-background-size:cover;-ms-background-size:cover;background-size:cover
}
'''


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.process = QProcess()
        self.process.readyReadStandardOutput.connect(self.readOutput)
        self.process.readyReadStandardError.connect(self.readErrors)
        self.process.finished.connect(self._process_finished)
        # self.process.error.connect(self._process_error)

        self.sourceDirectory, self.outputDirectory = None, None

        self.group2 = QGroupBox()
        self.group2.setTitle(' Paths ')
        self.inf = QLineEdit(path.expanduser("~"))
        self.inf.setPlaceholderText(' /full/path/to/directory ')
        self.out, self.fle = QLineEdit(path.expanduser("~")), QLineEdit()
        self.out.setPlaceholderText(' /full/path/to/directory ')
        self.fle.setPlaceholderText(' /full/path/to/single/file ')
        self.completer, self.dirs = QCompleter(self), QDirModel(self)
        self.dirs.setFilter(QDir.AllEntries | QDir.NoDotAndDotDot)
        self.completer.setModel(self.dirs)
        self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.completer.setCompletionMode(QCompleter.PopupCompletion)
        self.inf.setCompleter(self.completer)
        self.out.setCompleter(self.completer)
        self.fle.setCompleter(self.completer)
        self.open1 = QPushButton(QIcon.fromTheme("folder-open"), 'Open')
        self.open1.setCursor(QCursor(Qt.PointingHandCursor))
        self.open1.clicked.connect(lambda: self.inf.setText(str(
            QFileDialog.getExistingDirectory(self.dock, "Open Source Directory",
            path.expanduser("~")))))
        self.open2 = QPushButton(QIcon.fromTheme("folder-open"), 'Open')
        self.open2.setCursor(QCursor(Qt.PointingHandCursor))
        self.open2.clicked.connect(lambda: self.out.setText(str(
            QFileDialog.getExistingDirectory(self.dock, "Open Target Directory",
            path.expanduser("~")))))
        self.open3 = QPushButton(QIcon.fromTheme("folder-open"), 'Open')
        self.open3.setCursor(QCursor(Qt.PointingHandCursor))
        self.open3.clicked.connect(lambda: self.fle.setText(str(
            QFileDialog.getOpenFileName(self.dock, "Open a Target File...",
            path.expanduser("~"), ';;'.join(['{}(*.{})'.format(e.upper(), e)
                for e in ['py', 'pyw', '*']])))))
        vboxg2 = QVBoxLayout(self.group2)
        for each_widget in (
            QLabel('Source Directory Project:'), self.inf, self.open1,
            QLabel(' Target Directory Outputs: '), self.out, self.open2,
            QLabel(' Source Single File (Optional):'), self.fle, self.open3, ):
            vboxg2.addWidget(each_widget)

        self.group1 = QGroupBox()
        self.group1.setTitle(' Options ')
        self.chckbx1 = QCheckBox(' Inject Twitter Bootstrap CSS3 ')
        self.chckbx1.toggled.connect(self.toggle_styles_group)
        self.chckbx2 = QCheckBox(' Warn all missing references ')
        self.chckbx3 = QCheckBox(' Open Docs when done building ')
        self.chckbx4 = QCheckBox('Save Bash script to reproduce Sphinx Builds')
        vboxg1 = QVBoxLayout(self.group1)
        for each_widget in (self.chckbx1, self.chckbx2,
                            self.chckbx3, self.chckbx4):
            vboxg1.addWidget(each_widget)
            each_widget.setChecked(True)

        self.group3 = QGroupBox()
        self.group3.setTitle(' Styles ')
        self.group3.setGraphicsEffect(QGraphicsBlurEffect(self))
        self.group3.graphicsEffect().setEnabled(False)
        self.basecss, self.fontcss = QComboBox(), QComboBox()
        self.basecss.addItems(['slate', 'united', 'spacelab', 'superhero',
            'simplex', 'journal', 'flatly', 'cyborg', 'cosmo', 'cerulean'])
        self.fontcss.addItems(['Ubuntu Light', 'Oxygen', 'Roboto', 'Droid Sans',
            'Open Sans', 'Pacifico', 'Rancho', 'Arvo', 'Fresca', 'Graduate'])
        self.backcss = QComboBox()
        self.backcss.addItems(['shattered', 'retina_wood', 'ricepaper',
            'brickwall', 'sneaker_mesh_fabric', 'diagonales_decalees',
            'noisy_grid', 'pw_pattern', 'escheresque', 'diamond_upholstery'])
        vboxg3 = QVBoxLayout(self.group3)
        for each_widget in (QLabel('<b>Twitter Bootstrap Theme'), self.basecss,
            QLabel('<b>Fonts Family'), self.fontcss,
            QLabel('<b>Background Seamless Tiled Pattern'), self.backcss):
            vboxg3.addWidget(each_widget)

        self.output = QTextEdit('''
        My brain is something more than merely mortal; As time will show.
        - Ada Lovelace ''')
        self.output.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.button = QPushButton('Document My Code')
        self.button.setCursor(QCursor(Qt.PointingHandCursor))
        self.button.setMinimumSize(75, 50)
        self.button.clicked.connect(self.build)
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0)
        glow.setBlurRadius(99)
        glow.setColor(QColor(99, 255, 255))
        self.button.setGraphicsEffect(glow)

        class TransientWidget(QWidget):
            ' persistant widget thingy '
            def __init__(self, widget_list):
                ' init sub class '
                super(TransientWidget, self).__init__()
                vbox = QVBoxLayout(self)
                for each_widget in widget_list:
                    vbox.addWidget(each_widget)

        tw = TransientWidget((self.group2, self.group1, self.group3,
            QLabel(linesep + ' Logs: '), self.output, self.button))
        self.scrollable, self.dock = QScrollArea(), QDockWidget()
        self.scrollable.setWidgetResizable(True)
        self.scrollable.setWidget(tw)
        self.dock.setWindowTitle(__doc__)
        self.dock.setStyleSheet('QDockWidget::title{text-align: center;}')
        self.dock.setWidget(self.scrollable)
        ExplorerContainer().addTab(self.dock, "Sphinx")
        QPushButton(QIcon.fromTheme("help-about"), 'About', self.dock
            ).clicked.connect(lambda:
            QMessageBox.information(self.dock, __doc__, HELPMSG))

    def readOutput(self):
        """Read and append sphinx-build output to the logBrowser"""
        self.output.append(str(self.process.readAllStandardOutput()))

    def readErrors(self):
        """Read and append sphinx-build errors to the logBrowser"""
        self.output.append(self.formatErrorMsg(str(
                                        self.process.readAllStandardError())))

    def formatErrorMsg(self, msg):
        """Format error messages in red color"""
        return self.formatMsg(msg, 'red')

    def formatInfoMsg(self, msg):
        """Format informative messages in blue color"""
        return self.formatMsg(msg, 'green')

    def formatMsg(self, msg, color):
        """Format message with the given color"""
        return '<font color="{}">{}</font>'.format(color, msg)

    def build(self):
        """Main function calling sphinx-build to generate the project"""
        self.output.setText('')
        self.output.append(self.formatInfoMsg(
                            'INFO: OK: Starting at {}'.format(datetime.now())))
        self.button.setDisabled(True)
        self.sourceDirectory = str(self.inf.text()).strip()
        self.outputDirectory = str(self.out.text()).strip()
        if not len(self.sourceDirectory):
            self.output.append(' ERROR: FAIL: Source directory cannot be empty')
        else:
            self.output.append(self.formatInfoMsg(
            'INFO: OK: Source Directory is {}'.format(self.sourceDirectory)))
        if not len(self.outputDirectory):
            self.output.append(' ERROR: FAIL: Output directory cannot be empty')
        else:
            self.output.append(self.formatInfoMsg(
            'INFO: OK: Output Directory is {}'.format(self.outputDirectory)))
        if not(len(self.sourceDirectory) or len(self.outputDirectory)):
            self.button.setDisabled(False)
            return
        self.output.append(self.formatInfoMsg('INFO:OK: Building. Please wait'))

        args = ['-n' if self.chckbx2.isChecked() is True else '',
                '-b', 'html', self.sourceDirectory, self.outputDirectory]
        if len(self.fle.text()):
            args.append(str(self.fle.text()).strip().replace('file:///', '/'))
            self.output.append(self.formatInfoMsg(
                'INFO: OK: Source Single File is {}'.format(self.fle.text())))
        self.output.append(self.formatInfoMsg('INFO:OK: Running sphinx-build!'))

        self.process.start('sphinx-build', args)
        if not self.process.waitForStarted():
            self.output.append(self.formatErrorMsg('ERROR: FAIL: Build Failed'))
            self.output.append(self.formatErrorMsg(
                'ERROR: FAIL: Failed with Arguments: {} '.format(args)))
            self.button.setEnabled(True)
            return
        # write a .sh bash script file on target
        if self.chckbx4.isChecked() is True:
            sh_file = 'build_sphinx_documentation.sh'
            with open(path.join(self.sourceDirectory, sh_file), 'w') as _sh:
                self.output.append(self.formatInfoMsg('''INFO: OK: Writing Bash:
                    {}'''.format(path.join(self.sourceDirectory, sh_file))))
                _sh.write('#!/usr/bin/env bash {}'.format(linesep) +
                          'sphinx-build {}'.format(' '.join(args)))
                _sh.close()
            self.output.append(self.formatInfoMsg('INFO: OK: Bash chmod: 775'))
            try:
                chmod(path.join(self.sourceDirectory, sh_file), 0775)  # Py2
            except:
                chmod(path.join(self.sourceDirectory, sh_file), 0o775)  # Py3
        self.button.setEnabled(True)

    def _process_finished(self):
        """sphinx-build finished sucessfully"""
        self.output.append(self.formatInfoMsg(
                            'INFO: OK: Finished at {}'.format(datetime.now())))
        if self.chckbx1.isChecked() is True:
            with open(path.join(self.outputDirectory, '_static', 'default.css'),
                'a') as f:
                css = CSS3.replace('CSSWEBFONT', str(self.fontcss.currentText())
                      ).replace('CSSBACKGR', str(self.backcss.currentText())
                      ).replace('CSSCUSTOM', str(self.basecss.currentText()))
                f.write(css)
                f.close()
        if self.chckbx3.isChecked() is True:
            call('xdg-open ' + path.join(self.outputDirectory, 'index.html'),
                 shell=True)

    def toggle_styles_group(self):
        ' toggle on or off the styles checkboxes '
        try:
            if self.chckbx1.isChecked() is True:
                self.group3.graphicsEffect().setEnabled(False)
                self.group3.setEnabled(True)
            else:
                self.group3.graphicsEffect().setEnabled(True)
                self.group3.setEnabled(False)
        except:
            pass


###############################################################################


if __name__ == "__main__":
    print(__doc__)
