# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja PySide to PyQt "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 05/09/2013 '
__prj__ = ' pyside2pyqt '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path

from PyQt4.QtGui import QFileDialog, QIcon, QAction

from ninja_ide.core import plugin


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.loca = self.locator.get_service("menuApp")
        self.loca.add_action(QAction(QIcon.fromTheme("edit-select-all"), "PySide to PyQt", self, triggered=lambda: self.locator.get_service("editor").add_editor(content=str(open(path.abspath(QFileDialog.getOpenFileName(None, "{} - Open a PySide PY File".format(__doc__), path.expanduser("~"), 'PY(*.py)')), 'r').read()).strip().replace('PySide', 'PyQt4').replace('Signal', 'pyqtSignal').replace('Slot', 'pyqtSlot').replace('Property', 'pyqtProperty').replace('pyside-uic', 'pyuic4').replace('pyside-rcc', 'pyrcc4').replace('pyside-lupdate', 'pylupdate4'), syntax='python')))
        self.loca.add_action(QAction(QIcon.fromTheme("edit-select-all"), "PyQt to PySide", self, triggered=lambda: self.locator.get_service("editor").add_editor(content=str(open(path.abspath(QFileDialog.getOpenFileName(None, "{} - Open a PyQt 4 PY File".format(__doc__), path.expanduser("~"), 'PY(*.py)')), 'r').read()).strip().replace('PyQt4', 'PySide').replace('pyqtSignal', 'Signal').replace('pyqtSlot', 'Slot').replace('pyqtProperty', 'Property').replace('pyuic4', 'pyside-uic').replace('pyrcc4', 'pyside-rcc').replace('pylupdate4', 'pyside-lupdate'), syntax='python')))


###############################################################################


if __name__ == "__main__":
    print(__doc__)
