# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja Secure Paste "
__version__ = ' 0.2 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 01/09/2013 '
__prj__ = ' securepaste '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path
from sip import setapi
from json import loads
from getpass import getuser
from requests import post
from random import choice
from string import letters, digits
from datetime import datetime
from webbrowser import open_new_tab
try:
    from urllib import urlopen
except ImportError:
    from urllib.request import urlopen  # lint:ok

from PyQt4.QtGui import (QLabel, QCompleter, QDirModel, QPushButton, QWidget,
  QFileDialog, QDockWidget, QVBoxLayout, QCursor, QLineEdit, QIcon, QGroupBox,
  QCheckBox, QGraphicsDropShadowEffect, QGraphicsBlurEffect, QColor, QComboBox,
  QApplication, QMessageBox, QScrollArea)

from PyQt4.QtCore import Qt, QDir

try:
    from PyKDE4.kdeui import KTextEdit as QTextEdit
except ImportError:
    from PyQt4.QtGui import QTextEdit  # lint:ok

from ninja_ide.gui.explorer.explorer_container import ExplorerContainer
from ninja_ide.core import plugin


# API 2
(setapi(a, 2) for a in ("QDate", "QDateTime", "QString", "QTime", "QUrl",
                        "QTextStream", "QVariant"))


# constans
HELPMSG = '''
<h3>Ninja Secure Paste</h3>
Secure Encrypted Password Protected Paste.
<ul>
<li>Paste sensitive data like passwords with security
<li>Make Collections of Public Pastes grouped per Project
</ul>
<i>GitHub Secret Gists are Public to everyone on internet!</i>
<br><br>
''' + ''.join((__doc__, __version__, __license__, 'by', __author__, __email__))
TIME = {'1 Week': 604800, '1 Day': 86400, '1 Hour': 3600, '1 Min': 60,
        '1 Month': 2592000, '1 Year': 31622400, 'Forever': 0}
FORMATZ = ("python", "bash", "javascript", "text", "ruby", "diff", "css", "gdb",
    "abap", "6502acme", "actionscript", "actionscript3", "ada", "algol68",
    "apache", "applescript", "apt_sources", "asm", "asp", "autoconf", "php",
    "autohotkey", "autoit", "avisynth", "awk", "basic4gl", "bf", "xml", "perl",
    "bibtex", "blitzbasic", "bnf", "boo", "c", "c_loadrunner", "c_mac",
    "caddcl", "cadlisp", "cfdg", "cfm", "chaiscript", "cil", "clojure", "cmake",
    "cobol", "cpp", "cpp-qt", "csharp", "cuesheet", "d", "dcs", "delphi",
    "diff", "div", "dos", "dot", "e", "ecmascript", "eiffel", "email", "epc",
    "erlang", "f1", "falcon", "fo", "fortran", "freebasic", "fsharp", "4cs",
    "gambas", "gdb", "genero", "genie", "gettext", "glsl", "gml", "gnuplot",
    "go", "groovy", "gwbasic", "haskell", "hicest", "68000devpac", "hq9plus",
    "html4strict", "icon", "idl", "ini", "inno", "intercal", "io", "j", "java",
    "java5", "jquery", "6502kickass", "kixtart", "klonec", "klonecpp", "latex",
    "lb", "lisp", "locobasic", "logtalk", "lolcode", "lotusformulas",
    "lotusscript", "lscript", "lsl2", "lua", "m68k", "magiksf", "make",
    "mapbasic", "matlab", "mirc", "mmix", "modula2", "modula3", "mpasm", "mxml",
    "mysql", "newlisp", "nsis", "oberon2", "objc", "objeck", "ocaml",
    "ocaml-brief", "oobas", "oracle11", "oracle8", "oxygene", "oz", "pascal",
    "pcre", "per", "perl", "perl6", "pf", "php", "php-brief", "pic16", "pike",
    "pixelbender", "plsql", "postgresql", "povray", "powerbuilder",
    "powershell", "progress", "prolog", "properties", "providex", "purebasic",
    "python", "q", "qbasic", "rails", "rebol", "reg", "robots", "rpmspec",
    "rsplus", "ruby", "sas", "scala", "scheme", "scilab", "sdlbasic",
    "smalltalk", "smarty", "sql", "systemverilog", "6502tasm", "tcl",
    "teraterm", "text", "thinbasic", "tsql", "typoscript", "unicon", "vala",
    "vb", "vbnet", "verilog", "vhdl", "vim", "visualfoxpro", "visualprolog",
    "whitespace", "whois", "winbatch", "xbasic", "xml", "xorg_conf", "xpp",
    "z80", "zxbasic")


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        ec = ExplorerContainer()
        super(Main, self).initialize(*args, **kwargs)

        self.editor_s = self.locator.get_service('editor')
        self.ex_locator = self.locator.get_service('explorer')
        # directory auto completer
        self.completer, self.dirs = QCompleter(self), QDirModel(self)
        self.dirs.setFilter(QDir.AllEntries | QDir.NoDotAndDotDot)
        self.completer.setModel(self.dirs)
        self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.completer.setCompletionMode(QCompleter.PopupCompletion)

        self.group0 = QGroupBox()
        self.group0.setTitle(' Source ')
        self.source = QComboBox()
        self.source.addItems(['Clipboard', 'Local File', 'Remote URL',
                              'Ninja Whole Text', 'Ninja Text Selection'])
        self.source.currentIndexChanged.connect(self.on_source_changed)
        self.infile = QLineEdit(path.expanduser("~"))
        self.infile.setPlaceholderText(' /full/path/to/file.py ')
        self.infile.setCompleter(self.completer)
        self.open = QPushButton(QIcon.fromTheme("folder-open"), 'Open')
        self.open.setCursor(QCursor(Qt.PointingHandCursor))
        self.open.clicked.connect(lambda: self.infile.setText(str(
            QFileDialog.getOpenFileName(self.dock, "Open a File to read from",
            path.expanduser("~"), ';;'.join(['{}(*.{})'.format(e.upper(), e)
            for e in ['py', 'pyw', 'css', 'html', 'js', 'txt', '*']])))))
        self.inurl = QLineEdit('http://www.')
        self.inurl.setPlaceholderText('http://www.full/url/to/remote/file.html')
        self.output, self.target, self.time = QTextEdit(), QTextEdit(), QLabel()
        self.target.setReadOnly(True)
        vboxg0 = QVBoxLayout(self.group0)
        for each_widget in (self.source, self.infile, self.open, self.inurl,
            self.output, ):
            vboxg0.addWidget(each_widget)
        [a.hide() for a in iter((self.infile, self.open, self.inurl))]

        self.group1 = QGroupBox()
        self.group1.setTitle(' Security ')
        self.group1.setCheckable(True)
        self.group1.setGraphicsEffect(QGraphicsBlurEffect(self))
        self.group1.graphicsEffect().setEnabled(False)
        self.group1.toggled.connect(self.toggle_group)
        self.paste_private = QCheckBox('Paste is Private and Non-Searchable')
        self.paste_private.setChecked(True)
        self.user, self.password = QLineEdit(getuser()), QLineEdit()
        self.password.setPlaceholderText(' Type your PASSWORD here ! ')
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setFocus()
        self.passshow = QCheckBox('Show password as plain text')
        self.passshow.stateChanged.connect(lambda: self.password.setEchoMode(2)
            if self.password.echoMode() != QLineEdit.Password
            else self.password.setEchoMode(0))
        self.genpass = QPushButton(QIcon.fromTheme("face-smile"),
                                   'Suggest me a Password')
        self.genpass.clicked.connect(lambda: self.password.setEchoMode(0))
        self.genpass.released.connect(lambda: self.password.setText(
            ''.join(choice(letters + digits) for _ in range(6))))
        vboxg1 = QVBoxLayout(self.group1)
        for each_widget in (QLabel('<b>User'), self.user,
            QLabel('<b>Password'), self.password, self.passshow, self.genpass,
            self.paste_private):
            vboxg1.addWidget(each_widget)

        self.group2 = QGroupBox()
        self.group2.setTitle(' General ')
        self.paste_lang, self.paste_expire = QComboBox(), QComboBox()
        self.paste_lang.addItems(
                    [a.upper() if len(a) < 4 else a.title() for a in FORMATZ])
        self.paste_expire.addItems(
        ['1 Day', '1 Week', '1 Month', '1 Hour', '1 Min', '1 Year', 'Forever'])
        self.paste_expire.currentIndexChanged.connect(lambda:
            self.paste_title.setText("{} code({} expire)".format(
            getuser().title(), self.paste_expire.currentText())))
        self.paste_title = QLineEdit("{} code({} expire)".format(
            getuser().title(), self.paste_expire.currentText()))
        self.chckbx1 = QCheckBox('Lower case ALL the text')
        self.chckbx2 = QCheckBox('Remove Spaces, Tabs, New Lines, Empty Lines')
        self.chckbx3 = QCheckBox('Copy URL to ClipBoard when done')
        self.chckbx4 = QCheckBox('Open URL with Web Browser when done')
        self.paste_project = QLineEdit()
        self.paste_project.setPlaceholderText(' Type your PROJECT name here ')
        self.gen_projectnm = QPushButton(QIcon.fromTheme("face-smile"),
                                   'Get from Ninja active project')
        self.gen_projectnm.clicked.connect(lambda: self.paste_project.setText(
            self.ex_locator.get_tree_projects()._get_project_root().name))
        self.genlink = QPushButton('Open Collection of Pastes of this Project')
        self.genlink.clicked.connect(lambda: open_new_tab(
            "http://paste.kde.org/~{}/api/json/all".format(
            str(self.paste_project.text()).strip())))
        vboxg2 = QVBoxLayout(self.group2)
        for each_widget in (QLabel('<b>Code Language'), self.paste_lang,
            QLabel('<b>Paste Title'), self.paste_title,
            QLabel('<b>Paste Expire'), self.paste_expire,
            QLabel('''<b>Project Name (Optional)</b><br><small>
            <i>This makes Collections of Public Pastes grouped per Project'''),
            self.paste_project, self.gen_projectnm, self.genlink,
            self.chckbx1, self.chckbx2, self.chckbx3, self.chckbx4):
            vboxg2.addWidget(each_widget)

        self.button = QPushButton(QIcon.fromTheme("face-cool"), 'Secure Paste!')
        self.button.setCursor(QCursor(Qt.PointingHandCursor))
        self.button.setMinimumSize(100, 50)
        self.button.clicked.connect(self.run)
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0)
        glow.setBlurRadius(99)
        glow.setColor(QColor(99, 255, 255))
        self.button.setGraphicsEffect(glow)
        glow.setEnabled(True)

        class TransientWidget(QWidget):
            ' persistant widget thingy '
            def __init__(self, widget_list):
                ' init sub class '
                super(TransientWidget, self).__init__()
                vbox = QVBoxLayout(self)
                for each_widget in widget_list:
                    vbox.addWidget(each_widget)

        tw = TransientWidget((QLabel('<b>Password Protected Paste'),
            self.group0, self.group1, self.group2,
            QLabel('<center><b>Target Links'), self.target, self.time,
            self.button))
        self.scrollable, self.dock = QScrollArea(), QDockWidget()
        self.scrollable.setWidgetResizable(True)
        self.scrollable.setWidget(tw)
        self.dock.setWindowTitle(__doc__)
        self.dock.setStyleSheet('QDockWidget::title{text-align: center;}')
        self.dock.setWidget(self.scrollable)
        ec.addTab(self.dock, "Paste")
        QPushButton(QIcon.fromTheme("help-about"), 'About', self.dock
          ).clicked.connect(lambda: QMessageBox.information(self.dock, __doc__,
            HELPMSG))

    def run(self):
        ' run the string replacing '
        if self.source.currentText() == 'Local File':
            with open(path.abspath(str(self.infile.text()).strip()), 'r') as f:
                txt = str(f.read()).encode("utf-8")
        elif self.source.currentText() == 'Remote URL':
            txt = urlopen(str(self.inurl.text()).strip()).read().encode("utf-8")
        elif  self.source.currentText() == 'Clipboard':
            txt = str(self.output.toPlainText()).encode("utf-8") if str(
                self.output.toPlainText()) is not '' else str(
                    QApplication.clipboard().text()).encode("utf-8")
        elif self.source.currentText() == 'Ninja Whole Text':
            txt = self.editor_s.get_text().encode("utf-8")
        else:
            txt = self.editor_s.get_actual_tab().textCursor().selectedText()
        txt = txt.lower() if self.chckbx1.isChecked() is True else txt
        txt = " ".join(txt.strip().split()
                       ) if self.chckbx2.isChecked() is True else txt
        self.output.clear()
        self.output.setPlainText(txt)
        respo = loads(post("http://paste.kde.org",
            data={"paste_data": txt,
                  "paste_lang": str(self.paste_lang.currentText()),
                  "paste_user": str(self.user.text()).strip(),
                  "paste_password": str(self.password.text()).strip(),
                  "paste_private": str(self.paste_private.checkState()).lower(),
                  "paste_expire": str(TIME[self.paste_expire.currentText()]),
                  "paste_project": str(self.paste_project.text()).strip(),
                  "paste_title": str(self.paste_title.text()).strip(),
                  "api_submit": "true", "mode": "json", }).content)['result']
        p_url = "http://paste.kde.org/{}/{}".format(respo['id'], respo['hash'])
        if self.chckbx3.isChecked() is True:
            QApplication.clipboard().setText(p_url)
        if self.chckbx4.isChecked() is True:
            open_new_tab(p_url)
        self.target.append(p_url)
        self.target.setFocus()
        self.output.show()
        self.output.clear()
        self.time.setText('''<b>Last Paste:</b>
                         {}'''.format(datetime.now().isoformat().split('.')[0]))

    def on_source_changed(self):
        ' do something when the desired source has changed '
        if self.source.currentText() == 'Local File':
            self.open.show()
            self.infile.show()
            self.inurl.hide()
            self.output.hide()
        elif  self.source.currentText() == 'Remote URL':
            self.inurl.show()
            self.open.hide()
            self.infile.hide()
            self.output.hide()
        elif  self.source.currentText() == 'Clipboard':
            self.output.show()
            self.open.hide()
            self.infile.hide()
            self.inurl.hide()
            self.output.setText(QApplication.clipboard().text())
        elif self.source.currentText() == 'Ninja Whole Text':
            self.output.show()
            self.open.hide()
            self.infile.hide()
            self.inurl.hide()
            self.output.setText(self.editor_s.get_text().encode("utf-8"))
        else:
            self.output.show()
            self.open.hide()
            self.infile.hide()
            self.inurl.hide()
            self.output.setText(self.editor_s.get_actual_tab().textCursor(
                                ).selectedText().encode("utf-8"))

    def toggle_group(self):
        ' toggle on or off the css checkboxes '
        if self.group1.isChecked() is True:
            self.paste_private.setChecked(True)
            self.group1.graphicsEffect().setEnabled(False)
        else:
            self.paste_private.setChecked(False)
            self.group1.graphicsEffect().setEnabled(True)


###############################################################################


if __name__ == "__main__":
    print(__doc__)
