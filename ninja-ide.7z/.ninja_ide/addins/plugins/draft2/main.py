# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:OK


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja Draft  "
__version__ = ' 0.4 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 15/10/2013 '
__prj__ = ' draft_agile '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path
import codecs

from PyQt4.QtGui import (QPushButton, QDockWidget, QVBoxLayout, QAction,
    QIcon, QMessageBox, QToolBar, QGroupBox, QTabWidget, QScrollArea,
    QFileDialog, QColorDialog)

try:
    from PyKDE4.kdeui import KTextEdit as QTextEdit
except ImportError:
    from PyQt4.QtGui import QTextEdit  # lint:ok

from ninja_ide.core import plugin
from ninja_ide import resources

from pinta import ScribbleArea


# constants
HELP = '''
<h3>Draft Notes</h3>
Fork of unmaintained "Draft" plugin, with additional features.<br>
<ul>
<li>"Scratchpad (Draw)" quick sketch of ideas and wireframes.
<li>Draft can be made temporarily Read Only with a button.
</ul>
''' + ''.join((__doc__, __version__, __license__, 'by', __author__, __email__))
DRAFT_FILE = path.join(resources.HOME_NINJA_PATH, "draft.txt")


###############################################################################


class Main(plugin.Plugin):
    ' main class '
    def initialize(self):
        ' init the plugin '
        self.mainwidget = QTabWidget()
        self.mainwidget.tabCloseRequested.connect(lambda:
            self.mainwidget.setTabPosition(1)
            if self.mainwidget.tabPosition() == 0
            else self.mainwidget.setTabPosition(0))
        self.mainwidget.setStyleSheet('QTabBar{font-weight:bold;}')
        self.mainwidget.setMovable(True)
        self.mainwidget.setTabsClosable(True)
        self.scrollable = QScrollArea()
        self.scrollable.setWidgetResizable(True)
        self.scrollable.setWidget(self.mainwidget)
        self.dock = QDockWidget()
        self.dock.setWindowTitle(__doc__)
        self.dock.setStyleSheet('QDockWidget::title{text-align: center;}')
        self.dock.setWidget(self.scrollable)
        self.misc = self.locator.get_service('misc')
        self.misc.add_widget(self.dock,
                             QIcon.fromTheme("x-office-address-book"), __doc__)
        self.tab1, self.tab2 = QGroupBox(), QGroupBox()
        for a, b in ((self.tab1, ' Draft ( Notes ) '),
                     (self.tab2, ' Scratchpad ( Draw ) ')):
            a.setTitle(b)
            a.setToolTip(b)
            self.mainwidget.addTab(a, QIcon.fromTheme("text-x-generic"), b)
        QPushButton(QIcon.fromTheme("help-about"), 'About', self.dock
        ).clicked.connect(lambda: QMessageBox.about(self.dock, __doc__, HELP))

        self.editor_draft, self.drawpad = QTextEdit(), ScribbleArea()
        self.editor_draft.textChanged.connect(self.on_editor_project_changed)
        QVBoxLayout(self.tab1).addWidget(self.editor_draft)
        QVBoxLayout(self.tab2).addWidget(self.drawpad)
        self.drawpad.clearImage()
        QPushButton('Make ReadOnly', self.tab1).clicked.connect(lambda:
            self.editor_draft.setReadOnly(False)
            if self.editor_draft.isReadOnly() is True
            else self.editor_draft.setReadOnly(True))

        self.opn = QAction("Open", self, triggered=lambda:
            self.drawpad.openImage(QFileDialog.getOpenFileName(self.dock,
            "Open", path.expanduser("~"))))
        self.sve = QAction("Save", self, triggered=lambda:
            self.drawpad.saveImage(QFileDialog.getSaveFileName(self.dock,
            "Save", path.expanduser("~"), 'JPG(*.jpg)'), 'JPG'))
        self.prnt = QAction("Print", self, triggered=self.drawpad.print_)
        self.clr = QAction("Clear", self, triggered=self.drawpad.clearImage)
        self.wmax = QAction("+ Pen Width", self, triggered=lambda:
            self.drawpad.setPenWidth(self.drawpad.penWidth() * 2
            if self.drawpad.penWidth() < 10 else 1))
        self.wmin = QAction("- Pen Width", self, triggered=lambda:
            self.drawpad.setPenWidth(self.drawpad.penWidth() / 2
            if self.drawpad.penWidth() > 1 else 10))
        self.col = QAction("Pen Color", self, triggered=lambda:
            self.drawpad.setPenColor(QColorDialog.getColor()))
        QToolBar(self.tab2).addActions((self.sve, self.opn, self.prnt, self.clr,
                                        self.wmax, self.wmin, self.col))

        if path.exists(DRAFT_FILE):
            with codecs.open(DRAFT_FILE, encoding='utf-8') as fp:
                self.editor_draft.setPlainText(fp.read())

    def finish(self):
        ' save when finish '
        self.on_editor_project_changed()

    def on_editor_project_changed(self):
        ' save when change '
        with codecs.open(DRAFT_FILE, "w", encoding='utf-8') as fp:
            fp.write(self.editor_draft.toPlainText())


###############################################################################


if __name__ == "__main__":
    print(__doc__)
