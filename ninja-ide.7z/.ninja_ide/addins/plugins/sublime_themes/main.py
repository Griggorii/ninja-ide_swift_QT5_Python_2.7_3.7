# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Sublime Text 3 Themes "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 12/12/2013 '
__prj__ = ' sublime_themes '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path
from sys import platform
from string import maketrans
from json import dumps
from plistlib import readPlist

from PyQt4.QtGui import QAction, QFileDialog, QIcon

from ninja_ide.core import plugin


# http://docs.sublimetext.info/en/latest/basic_concepts.html#the-data-directory
if 'linux' in platform:
    DEFAULT_PATH = path.join(path.expanduser('~'), '.config', 'sublime-text-3',
                             'Packages', 'User')
elif 'darwin' in platform:
    DEFAULT_PATH = path.join(path.expanduser('~'), 'Library',
                   'Application Support', 'Sublime Text 3', 'Packages', 'User')
else:
    # http://technet.microsoft.com/en-us/library/cc962614.aspx   > Win2000 ?
    DEFAULT_PATH = path.join('%APPDATA%', 'Sublime Text 3', 'Packages', 'User')
if not path.isdir(DEFAULT_PATH):  # directory does not exist fallback to home
    DEFAULT_PATH = path.expanduser('~')


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.locator.get_service("menuApp").add_action(QAction(QIcon.fromTheme(
        "applications-graphics"), __doc__, self, triggered=lambda: self.run()))

    def run(self):
        """ sequence of methods """
        color = {}
        xml_file = str(QFileDialog.getOpenFileName(None, __doc__, DEFAULT_PATH,
        ';;'.join(['{}(*.{})'.format(e.upper(), e) for e in ['tmTheme', '*']])))
        # docs.python.org/dev/library/plistlib.html
        theme = readPlist(xml_file)
        # UGLY: dont blame me, blame those who like to use XML crappy format  :/
        color['brace'] = theme['settings'][0]['settings']['bracketsForeground']
        color['brace-background'] = theme['settings'][0]['settings']['bracketsForeground'].lower().translate(maketrans('0123456789abcdef', 'fedcba9876543210'))
        color['brace-foreground'] = theme['settings'][0]['settings']['bracketsForeground']
        color['comment'] = theme['settings'][1]['settings']['foreground']
        color['current-line'] = theme['settings'][0]['settings']['lineHighlight']
        color['definition'] = theme['settings'][1]['settings']['foreground'].lower().translate(maketrans('0123456789abcdef', 'fedcba9876543210'))
        color['editor-background'] = theme['settings'][0]['settings']['background']
        color['editor-selection-background'] = theme['settings'][0]['settings']['selection'].lower().translate(maketrans('0123456789abcdef', 'fedcba9876543210'))
        color['editor-selection-color'] = theme['settings'][0]['settings']['selection']
        color['editor-text'] = theme['settings'][0]['settings']['foreground']
        color['error-underline'] = theme['settings'][21]['settings']['foreground']
        color['fold-area'] = theme['settings'][0]['settings']['caret'].lower().translate(maketrans('0123456789abcdef', 'fedcba9876543210'))
        color['fold-arrow'] = theme['settings'][0]['settings']['caret']
        color['keyword'] = theme['settings'][7]['settings']['foreground']
        color['linkNavigate'] = '#128'
        color['numbers'] = theme['settings'][3]['settings']['foreground']
        color['operator'] = theme['settings'][3]['settings']['foreground'].lower().translate(maketrans('0123456789abcdef', 'fedcba9876543210'))
        color['pep8-underline'] = theme['settings'][-1]['settings']['foreground']
        color['properObject'] = theme['settings'][12]['settings']['foreground']
        color['selected-word'] = theme['settings'][-1]['settings']['foreground'].lower().translate(maketrans('0123456789abcdef', 'fedcba9876543210'))
        color['sidebar-background'] = theme['settings'][0]['settings']['findHighlight']
        color['sidebar-foreground'] = theme['settings'][0]['settings']['findHighlightForeground']
        color['spaces'] = theme['settings'][0]['settings']['invisibles']
        color['string'] = theme['settings'][2]['settings']['foreground']
        color['string2'] = theme['settings'][0]['settings']['invisibles'].lower().translate(maketrans('0123456789abcdef', 'fedcba9876543210'))
        color_theme_file = xml_file.replace('.tmTheme', '.color')
        with open(color_theme_file, 'w') as f:
            f.write(dumps(color, indent=4, sort_keys=True))
        with open(color_theme_file, 'r') as f:
            self.locator.get_service("editor").add_editor(content=f.read(),
                                                          syntax='python')


###############################################################################


if __name__ == "__main__":
    print(__doc__)