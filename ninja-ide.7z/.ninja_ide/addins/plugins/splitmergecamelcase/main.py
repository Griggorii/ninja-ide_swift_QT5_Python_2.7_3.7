# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja Split and Merge CamelCase "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 15/10/2013 '
__prj__ = ' '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from re import sub

from PyQt4.QtGui import QIcon, QAction

from ninja_ide.core import plugin


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.locator.get_service("menuApp").add_action(QAction(QIcon.fromTheme("edit-select-all"), "Split from CamelCase", self, triggered=lambda: self.locator.get_service("editor").insert_text(sub(r'([A-Z])', r' \1', self.locator.get_service("editor").get_actual_tab().textCursor().selectedText().encode("utf-8").strip()).lower())))
        self.locator.get_service("menuApp").add_action(QAction(QIcon.fromTheme("edit-select-all"), "Merge to CamelCase", self, triggered=lambda: self.locator.get_service("editor").insert_text(''.join(self.locator.get_service("editor").get_actual_tab().textCursor().selectedText().encode("utf-8").strip().title().split()))))
        self.locator.get_service("menuApp").add_action(QAction(QIcon.fromTheme("edit-select-all"), "CamelCase to under_score", self, triggered=lambda: self.locator.get_service("editor").insert_text('_'.join(sub(r'([A-Z])', r' \1', self.locator.get_service("editor").get_actual_tab().textCursor().selectedText().encode("utf-8").strip()).lower().split()))))


###############################################################################


if __name__ == "__main__":
    print(__doc__)
