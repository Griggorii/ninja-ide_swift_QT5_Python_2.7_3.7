# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Optimize Imports "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 30/11/2013 '
__prj__ = ' '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path
try:
    from urllib import urlopen
except ImportError:
    from urllib.request import urlopen  # lint:ok

from PyQt4.QtGui import (QInputDialog, QApplication, QDialog, QGroupBox, QMenu,
    QFileDialog, QLabel, QPushButton, QGraphicsDropShadowEffect, QLineEdit,
    QComboBox, QColor, QVBoxLayout, QCheckBox, QSpinBox)

from ninja_ide.core import plugin


from isort import SortImports


HELPMSG = '''Sort imports alphabetically and automatically separated sections.
<br>By Default it will always produce PEP8 / Lint compliant changes.<br>
''' + ''.join((__doc__, ', v', __version__, __license__, 'by', __author__))


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.menu = QMenu(__doc__)
        self.menu.addAction('Optimize imports', lambda: SortImports(file_path=
          self.locator.get_service("editor").get_opened_documents()[
          self.locator.get_service("editor").get_tab_manager().currentIndex()]))
        self.menu.addAction('Optimize imports advanced + Options',
            lambda: self.dialog.show())
        self.menu.addSeparator()
        self.menu.addAction('Ignore this Line while optimizing imports', lambda:
            self.locator.get_service("editor").insert_text('  # isort:skip'))
        self.menu.addAction('Ignore this File while optimizing imports', lambda:
          self.locator.get_service("editor").insert_text('  # isort:skip_file'))
        self.locator.get_service("menuApp").add_menu(self.menu)
        self.dialog, self.group0 = QDialog(), QGroupBox(__doc__)
        self.source, self.target = QComboBox(), QComboBox()
        self.source.addItems(['Current File', 'Clipboard', 'Local File',
                              'Remote URL'])
        self.target.addItems(['In Place', 'New File', 'Write to Local File'])
        self.to_add = QLineEdit()
        self.button = QPushButton('Optimize Imports')
        self.indent, self.maxlen = QSpinBox(), QSpinBox()
        self.indent.setRange(2, 10)
        self.indent.setValue(4)
        self.indent.setSingleStep(2)
        self.maxlen.setRange(75, 999)
        self.maxlen.setValue(80)
        self.maxlen.setSingleStep(2)
        self.diff = QCheckBox('Print a Diff to STDOUT for all the changes')
        self.diff.toggled.connect(lambda: self.target.setCurrentIndex(1)
            if self.diff.isChecked() else self.target.setCurrentIndex(0))
        self.clipb = QCheckBox('Copy output to ClipBoard when done')
        self.bylen = QCheckBox('Sort Imports by their total string lengths')
        [a.setChecked(True) for a in (self.diff, self.clipb, self.bylen)]
        self.button.setMinimumSize(400, 50)
        self.button.clicked.connect(self.run)
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0)
        glow.setBlurRadius(99)
        glow.setColor(QColor(99, 255, 255))
        self.button.setGraphicsEffect(glow)
        vboxg0 = QVBoxLayout(self.group0)
        for each_widget in (QLabel('<b>Source'), self.source,
            QLabel('<b>Target'), self.target,
            QLabel('<b>Imports to Add (comma separated)'), self.to_add,
            QLabel('<b>Indentation Spaces'), self.indent,
            QLabel('<b>Max Line Lenght'), self.maxlen, self.clipb, self.diff,
            self.bylen, QLabel('<center><br><small><i>{}'.format(HELPMSG)),
            self.button):
            vboxg0.addWidget(each_widget)
        QVBoxLayout(self.dialog).addWidget(self.group0)

    def run(self):
        ' run optimization of imports '
        if self.source.currentIndex() is 0:
            fpath = self.locator.get_service("editor").get_opened_documents()[
            self.locator.get_service("editor").get_tab_manager().currentIndex()]
            fcontent = None
        elif self.source.currentIndex() is 1:
            fpath = None
            fcontent = str(QApplication.clipboard().text())
        elif self.source.currentIndex() is 2:
            fpath = path.abspath(QFileDialog.getOpenFileName(None, __doc__,
                    path.expanduser("~"), '*.PY(*.py)'))
            fcontent = None
        elif self.source.currentIndex() is 3:
            fpath = None
            fcontent = urlopen(str(QInputDialog.getText(None, __doc__, "URL:",
                text='https://www.')[0]).strip()).read().encode("utf-8")
        output = SortImports(file_path=fpath, file_contents=fcontent,
            write_to_stdout=False if self.target.currentIndex() is 0 else True,
            show_diff=True if self.diff.isChecked() else False, check=False,
            length_sort=True if self.bylen.isChecked() else False,
            line_length=self.maxlen.value(), indent=' ' * self.indent.value(),
            add_imports=[a.strip()
                        for a in str(self.to_add.text()).strip().split(',')]
        ).output
        if self.clipb.isChecked():
            QApplication.clipboard().setText(output)
        if self.target.currentIndex() is 1:
            self.locator.get_service("editor").add_editor(content=output,
                syntax='python' if not self.diff.isChecked() else 'diff')
        elif self.target.currentIndex() is 2:
            with open(path.abspath(QFileDialog.getSaveFileName(None, __doc__,
                    path.expanduser("~"), '*.PY(*.py)')), 'w') as f:
                f.write(output)
        self.dialog.hide()


###############################################################################


if __name__ == "__main__":
    print(__doc__)
