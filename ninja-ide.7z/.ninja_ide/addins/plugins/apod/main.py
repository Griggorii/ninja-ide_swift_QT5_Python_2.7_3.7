# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja NASA Astronomy Picture of the Day "
__version__ = ' 0.2 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 05/09/2013 '
__prj__ = ' apod '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path
from tempfile import gettempdir

from PyQt4.QtCore import QTimer
from requests import get

from ninja_ide.core import plugin
from ninja_ide.gui.ide import IDE


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        QTimer.singleShot(60000, lambda: IDE().setStyleSheet(
            'QMainWindow{border-image:url(' + str(self.download_apod()) +
            ') 0 0 0 0 stretch stretch}'))

    def download_apod(self):
        """Download NASA Astronomy Picture of the Day and return its filename"""
        nasa = 'http://apod.nasa.gov/apod/'
        img = [a[10:-1] for a in get(nasa).iter_lines() if a.startswith('<IMG')]
        filename = path.join(gettempdir(), img[0].lower().split('/')[-1])
        if not path.isfile(filename):
            r = get(nasa + img[0], stream=True, timeout=5)
            with open(filename, 'wb') as f:
                for chunk in r.iter_content(chunk_size=1024):  # chunks to disk
                    if chunk:  # skip keep alive fake chunk
                        f.write(chunk)
                        f.flush()
        return filename


###############################################################################


if __name__ == "__main__":
    print(__doc__)
