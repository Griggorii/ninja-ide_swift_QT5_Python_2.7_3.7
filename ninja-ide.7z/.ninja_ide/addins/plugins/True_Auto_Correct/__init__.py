# *-* coding: UTF-8 *-*
from True_Auto_Correct import Autocompleter
