# -*- coding: utf-8 *-*

from __future__ import unicode_literals

from PyQt4.QtCore import SIGNAL
from PyQt4.QtGui import (QTreeWidget, QTreeWidgetItem, QHeaderView,
                         QAbstractItemView)

from ninja_ide.core import plugin

def parse_rest_tree(text):
    """
    Parse a text and gives as output the title hierarchy.

    The output is a list of tuples "(level, title, line)".
    """

    # TODO: check for orphan nodes and non consistent hierarchy

    # characters which can be used as delimiters for sections
    header_chars = ['*', '=', '-', '^', '#', '`', ':', "'", '"', '~', '_',
                        '+', '<', '>']

    tree = []
    # characters which are used as delimiters, stored in the hierarchical order
    levels = []

    # this variable is used to skip the parsing of the two lines when we haved
    # a title surrounded with delimiters
    ignore_line = 0

    text = text.splitlines()
    for i, line in enumerate(text):
        if ignore_line != 0:
            ignore_line -= 1
            continue

        line = line.strip()
        try:
            char = line[0]
        except IndexError:
            continue

        # check if the first line character can be used for header, and
        # check that the whole line is made of the character
        if char in header_chars and False not in [c == char for c in line]:
            # first and second line after the one which is parsed
            if char not in levels:
                levels.append(char)

            title, line2 = text[i+1:i+3]
            # line where is the title (counter start at 0)
            title_line = i+1

            try:
                char_after = line2[0]
            except IndexError:
                char_after = ''

            # check if we have a surrounded title, and in the other case
            # grab the title in the previous line
            if char_after in header_chars and False not in [c == char_after
                                                            for c in line]:
                ignore_line = 2
            else:
                # line before the current one
                title = text[i-1]
                title_line = i-1

            # TODO: display error message
            # compare line length of the title and of the headers ; be careful
            # with encoding and non-ascii characters
            if len(title) != len(line):
                #.decode('utf-8')
                continue

            tree.append((levels.index(char), title, title_line))

    return tree


class RestEditor(plugin.Plugin):

    def initialize(self):
        self.main_s = self.locator.get_service('editor')
        self.explorer_s = self.locator.get_service('explorer')

        self._rest_tree_widget = RestWidget(self.locator)
        self.explorer_s.add_tab(self._rest_tree_widget, "ReST")

class RestWidget(QTreeWidget):

    def __init__(self, locator):
        QTreeWidget.__init__(self)
        self.locator = locator
        self._explorer_s = self.locator.get_service('explorer')
        self._main_s = self.locator.get_service('editor')
        #on current tab changed refresh
        self._main_s.currentTabChanged.connect(self._on_tab_changed)
        #on file saved refresh
        self._main_s.fileSaved.connect(self._on_file_saved)

        self.header().setHidden(True)
        self.setSelectionMode(self.SingleSelection)
        self.setAnimated(True)
        self.header().setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.header().setResizeMode(0, QHeaderView.ResizeToContents)
        self.header().setStretchLastSection(False)

        self.connect(self, SIGNAL("itemClicked(QTreeWidgetItem *, int)"),
            self._go_to_definition)

    def _on_tab_changed(self):
        self.refresh_rest_tree()

    def _on_file_saved(self, fileName):
        self.refresh_rest_tree()

    def refresh_rest_tree(self):
        editorWidget = self._main_s.get_editor()
        if editorWidget:
            source = self._main_s.get_text()
            self._parse_rest(source)

    def _go_to_definition(self, item):
        #the root doesn't go to anywhere
        if item.parent() is not None:
            self._main_s.jump_to_line(item.lineno)

    def _parse_rest(self, source):
        self.clear()
        root = QTreeWidgetItem(self, ['ReST tree'])

        hierarchy = parse_rest_tree(source)

        # store the last parents at each level (given by the index)
        last_parents = []
        last_level = 0

        for level, title, line in hierarchy:

            if level == 0:
                item = RestTreeItem(root, [title], line)
                last_parents = [item]
            else:
                if level > last_level:
                    parent = last_parents[-1]
                    item = RestTreeItem(parent, [title], line)
                    last_parents.append(item)
                elif level < last_level:
                    last_parents = last_parents[:level]
                    parent = last_parents[-1]
                    item = RestTreeItem(parent, [title], line)
                    last_parents.append(item)
                else:
                    parent = last_parents[-2]
                    item = RestTreeItem(parent, [title], line)
                    last_parents[-1] = item

            last_level = level

        self.expandAll()


class RestTreeItem(QTreeWidgetItem):

    def __init__(self, parent, content, lineno):
        QTreeWidgetItem.__init__(self, parent, content)
        self.lineno = lineno
