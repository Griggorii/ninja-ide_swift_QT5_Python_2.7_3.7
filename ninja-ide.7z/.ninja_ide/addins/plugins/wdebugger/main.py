# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja Remote Debugger "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 30/10/2013 '
__prj__ = ' '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from webbrowser import open_new_tab
from PyQt4.QtGui import QMenu, QInputDialog, QApplication, QMessageBox

from PyQt4.QtCore import QProcess

from ninja_ide.core import plugin


KEYSHORT = '''<h3>Web GUI Keyboard Shortcuts</h3>
<ul>
    <li>[Ctrl] + [↓] or [F11]....Step into (In)
    <li>[Ctrl] + [→] or [F10]....Step over (Next)
    <li>[Ctrl] + [↑] or [F9].....Step out (Previous)
    <li>[Ctrl] + [←] or [F8].....Continue (Run)
    <li>[F7].....................Until (Loop to Next)
    <li>[Enter]..................Eval current line
    <li>[Shift] + [Enter]........Multi-lines operations
    <li>MiddleClick over Source..Debug Object under Cursor
    <li>LeftClick over Margin....Insert or Remove Break Point
</ul>
<b>Web GUI In-Line Debug Syntax:</b>
    <ul><li>[file/module][:lineno][#function][,condition]</ul>
<center><small>
<i>This is a frontend to <a href="https://github.com/Kozea/wdb">wdb</a><br>
''' + ''.join((__doc__, ', v', __version__, __license__, 'by', __author__))


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.menu, self.process = QMenu(__doc__), QProcess(self)
        self.menu.addAction('Start Debugger Process', lambda: self.run(0))
        self.menu.addAction('Start Debugger Process + Options', lambda: self.run(1))
        self.menu.addAction('Kill Debugger Process', lambda: self.process.kill())
        # self.menu.addSeparator()
        # self.menu.addAction('Read Debugger Process StandardOutput', lambda: QMessageBox.information(None, __doc__, str(self.process.readAllStandardOutput())))
        # self.menu.addAction('Read Debugger Process StandardError', lambda: QMessageBox.information(None, __doc__, str(self.process.readAllStandardError())))
        self.menu.addSeparator()
        self.menu.addAction('Insert set_trace() to Debug from current line', lambda: self.locator.get_service("editor").insert_text('import wdb; wdb.set_trace()  # Start Trace'))
        self.menu.addAction('Insert with_trace() to Debug from Exceptions', lambda: self.locator.get_service("editor").insert_text('import wdb; with wdb.trace():  # Wrong_Code_Here'))
        self.menu.addAction('Insert start_trace() to start Debug', lambda: self.locator.get_service("editor").insert_text('import wdb; wdb.start_trace()  # Start Trace'))
        self.menu.addAction('Insert stop_trace() to stop Debug', lambda: self.locator.get_service("editor").insert_text('wdb.stop_trace()  # Stop Trace'))
        self.menu.addSeparator()
        self.menu.addAction('Copy set_trace() to Clipboard', lambda: QApplication.clipboard().setText('import wdb; wdb.set_trace()  # Start Trace'))
        self.menu.addAction('Copy with_trace() to Clipboard', lambda: QApplication.clipboard().setText('import wdb; with wdb.trace():  # Wrong_Code_Here'))
        self.menu.addAction('Copy start_trace() to Clipboard', lambda: QApplication.clipboard().setText('import wdb; wdb.start_trace()  # Start Trace'))
        self.menu.addAction('Copy stop_trace() to Clipboard', lambda: QApplication.clipboard().setText('wdb.stop_trace()  # Stop Trace'))
        self.menu.addSeparator()
        self.menu.addAction('Insert Shortcut Alias set_trace()', lambda: self.locator.get_service("editor").insert_text('from wdb.ext import add_w_builtin; add_w_builtin(); w.tf()  # Start Trace'))
        self.menu.addAction('Insert Shortcut Alias with_trace()', lambda: self.locator.get_service("editor").insert_text('from wdb.ext import add_w_builtin; add_w_builtin(); with w.trace():  # Wrong_Code_Here'))
        self.menu.addAction('Insert Shortcut Alias start_trace()', lambda: self.locator.get_service("editor").insert_text('from wdb.ext import add_w_builtin; add_w_builtin(); w.start_trace()  # Start Trace'))
        self.menu.addAction('Insert  Shortcut Alias stop_trace()', lambda: self.locator.get_service("editor").insert_text('w.stop_trace()  # Stop Trace'))
        self.menu.addSeparator()
        self.menu.addAction('Show Web GUI Keyboard Shortcuts', lambda: QMessageBox.information(None, __doc__, KEYSHORT))
        self.menu.addAction('Show Debugging Session currently Open', lambda: open_new_tab('http://localhost:1984'))
        self.locator.get_service("menuApp").add_menu(self.menu)

    def run(self, option):
        ' run backend process '
        if option is 0:
            cmd = 'wdb.server.py'
        else:
            cmd = '{}wdb.server.py --theme={}'.format('chrt -i 0 ' if str(QInputDialog.getItem(None, __doc__, "Debugger Process CPU Priority:", ['LOW CPU Priority', 'High CPU Priority'], 0, False)[0]) in 'LOW CPU Priority' else '', str(QInputDialog.getItem(None, __doc__, "Web GUI Theme Skin:", ['dark', 'light'], 0, False)[0]))
        self.process.start(cmd)
        if not self.process.waitForStarted():
            QMessageBox.information(None, __doc__ + '- ERROR!',
            str(self.process.readAllStandardOutput()) +
            str(self.process.readAllStandardError()))
        else:
            open_new_tab('http://localhost:1984')

    def finish(self):
        ' clear when finish '
        self.process.kill()


###############################################################################


if __name__ == "__main__":
    print(__doc__)
