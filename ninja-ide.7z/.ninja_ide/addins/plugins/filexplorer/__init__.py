# -*- coding: utf-8 -*-
from filexplorer.gui import filexplorerPluginMain