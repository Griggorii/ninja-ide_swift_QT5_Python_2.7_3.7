# -*- coding: UTF-8 -*-
"""hg_integration.py - Hg integration plugin for Ninja-IDE"""

import os.path
import subprocess

from ninja_ide.core import file_manager, plugin
from PyQt4.QtCore import SIGNAL
from PyQt4.QtGui import QAction, QBrush, QColor, QIcon, QMenu

import resources

# Workaround for bug in explorer service's get_item() function
file_manager.belongs_to_folder = lambda path, fileName: fileName.startswith(path)


class HgIntegration(plugin.Plugin):
    def initialize(self):
        # Init your plugin
        self.editor_s = self.locator.get_service("editor")
        self.toolbar_s = self.locator.get_service("toolbar")
        self.explorer_s = self.locator.get_service("explorer")
        self.initialized = False

        # Add toolbar buttons
        self.commit_a = QAction(QIcon(resources.COMMIT_ICON), self.tr("Hg Commit"), self)
        workbench_a = QAction(QIcon(resources.WORKBENCH_ICON), self.tr("Hg Workbench"), self)
        self.toolbar_s.add_action(self.commit_a)
        self.toolbar_s.add_action(workbench_a)
        self.toolbar_s._toolbar.addSeparator()
        self.connect(self.commit_a, SIGNAL("triggered()"), self.commit_current)
        self.connect(workbench_a, SIGNAL("triggered()"), self.workbench_current)
        self.update_toolbar()

        # Add menu and icons to Project Explorer
        self.create_menu()
        self.explorer_s.add_project_menu(self.menu, lang="all")

        # Connect functions to Qt signals
        self.editor_s.fileSaved.connect(self.update_status)
        self.editor_s.currentTabChanged.connect(self.update_toolbar)
        self.explorer_s.projectOpened.connect(self.check_projects)
        self.connect(self.explorer_s.get_tree_projects(), SIGNAL("itemSelectionChanged()"),
            self.update_menu)

    def update_toolbar(self):
        """Update state of commit button based on project"""
        project_path = self.editor_s.get_project_owner()
        if project_path is not None:
            is_repo = os.path.isdir(os.path.join(project_path, ".hg"))
        else:
            is_repo = False
        self.commit_a.setEnabled(is_repo)

    def create_menu(self):
        """Create Hg integration menu for project explorer."""
        self.menu = QMenu("Hg integration")

        commit = self.menu.addAction(self.tr("Commit"))
        workbench = self.menu.addAction(self.tr("Workbench"))
        self.menu.addSeparator()
        status = self.menu.addAction(self.tr("View File Status"))
        diff = self.menu.addAction(self.tr("Visual Diff"))
        self.menu.addSeparator()
        add = self.menu.addAction(self.tr("Add Files..."))
        revert = self.menu.addAction(self.tr("Revert Files..."))
        rename = self.menu.addAction(self.tr("Rename Files..."))
        forget = self.menu.addAction(self.tr("Forget Files..."))
        remove = self.menu.addAction(self.tr("Remove Files..."))
        self.menu.addSeparator()
        refresh = self.menu.addAction(self.tr("Refresh Status"))

        self.menu.connect(commit, SIGNAL("triggered()"), self.hg_commit)
        self.menu.connect(workbench, SIGNAL("triggered()"), self.hg_workbench)
        self.menu.connect(status, SIGNAL("triggered()"), self.hg_status)
        self.menu.connect(diff, SIGNAL("triggered()"), self.hg_diff)
        self.menu.connect(add, SIGNAL("triggered()"), self.hg_add)
        self.menu.connect(revert, SIGNAL("triggered()"), self.hg_revert)
        self.menu.connect(rename, SIGNAL("triggered()"), self.hg_rename)
        self.menu.connect(forget, SIGNAL("triggered()"), self.hg_forget)
        self.menu.connect(remove, SIGNAL("triggered()"), self.hg_remove)
        self.menu.connect(refresh, SIGNAL("triggered()"), self.refresh_status)

    def update_status(self):
        project_path = self.editor_s.get_project_owner()
        if not os.path.isdir(os.path.join(project_path, ".hg")):
            return

        filename = self.editor_s.get_editor_path()
        item = self.explorer_s.get_item(filename)
        if item is None:
            return
        status = subprocess.check_output(["hg", "status", filename], cwd=project_path)
        if status.startswith("M "):
            item.setForeground(0, QBrush(QColor(resources.MODIFIED_COLOR)))
        elif item.foreground(0).color() == QColor(resources.MODIFIED_COLOR):
            item.setForeground(0, QBrush(QColor("white")))

    def check_projects(self, project_path):
        """Change the icons for the versioned files."""
        self.update_toolbar()

        if not self.initialized:
            for project_tree in self.explorer_s.get_opened_projects():
                if os.path.isdir(os.path.join(project_tree.path, ".hg")):
                    self.update_all_statuses(project_tree.path, project_tree.extensions)
                    project_tree.setIcon(0, QIcon(resources.HG_ICON))
            self.initialized = True
        else:
            for project_tree in self.explorer_s.get_opened_projects():
                if project_tree.path == project_path:
                    if os.path.isdir(os.path.join(project_tree.path, ".hg")):
                        self.update_all_statuses(project_tree.path, project_tree.extensions)
                        project_tree.setIcon(0, QIcon(resources.HG_ICON))
                    break

        self.update_menu()

    def update_all_statuses(self, project_path, extensions):
        versioned_files = self.get_versioned_files(project_path)
        modified_files = self.get_modified_files(project_path)
        project_files = self.get_project_files(project_path, extensions)

        for filename in project_files:
            item = self.explorer_s.get_item(os.path.join(project_path, filename))
            if filename in modified_files:
                item.setForeground(0, QBrush(QColor(resources.MODIFIED_COLOR)))
            elif filename not in versioned_files:
                item.setForeground(0, QBrush(QColor(resources.UNVERSIONED_COLOR)))
            else:
                item.setForeground(0, QBrush(QColor("white")))

    def get_versioned_files(self, project_path):
        """Get a list of full paths of all versioned files."""
        v_files = []
        manifest = subprocess.check_output(["hg", "manifest"], cwd=project_path)
        for filename in manifest.strip().split("\n"):
            v_files.append(filename)
        return v_files

    def get_modified_files(self, project_path):
        """Get a list of full paths of all modified files."""
        m_files = []
        status = subprocess.check_output(["hg", "status"], cwd=project_path)
        for line in status.strip().split("\n"):
            if line.startswith("M "):
                m_files.append(line[2:])
        return m_files

    def get_project_files(self, project_path, extensions):
        """Get a list of full paths for all files in the project."""
        p_files = []
        paths = file_manager.open_project_with_extensions(project_path, extensions)
        for dir, files in paths.iteritems():
            if ".hg" in dir:
                continue
            for filename in files[0]:
                p_files.append(os.path.relpath(os.path.join(dir, filename), project_path))
        return p_files

    def update_menu(self):
        selected_item = self.explorer_s.get_current_project_item()
        for project_tree in self.explorer_s.get_opened_projects():
            if selected_item.path.startswith(project_tree.path):
                project_path = project_tree.path
                break
        is_repo = os.path.isdir(os.path.join(project_path, ".hg"))
        self.menu.menuAction().setVisible(is_repo)

    def get_project_path(self):
        selected_item = self.explorer_s.get_current_project_item()
        for project_tree in self.explorer_s.get_opened_projects():
            if selected_item.path.startswith(project_tree.path):
                return project_tree.path
        return None

    def commit_current(self):
        """Call thg commit."""
        subprocess.Popen(["thg", "commit"], cwd=self.editor_s.get_project_owner())

    def workbench_current(self):
        """Call thg workbench."""
        subprocess.Popen(["thg", "workbench"], cwd=self.editor_s.get_project_owner())

    def hg_commit(self):
        """Call thg commit."""
        subprocess.Popen(["thg", "commit"], cwd=self.get_project_path())

    def hg_workbench(self):
        """Call thg workbench."""
        subprocess.Popen(["thg", "workbench"], cwd=self.get_project_path())

    def hg_status(self):
        """Call thg status."""
        selected_item = self.explorer_s.get_current_project_item()
        filename = os.path.join(selected_item.path, selected_item.text(0))
        subprocess.Popen(["thg", "status", filename], cwd=self.get_project_path())

    def hg_diff(self):
        """Call thg diff."""
        selected_item = self.explorer_s.get_current_project_item()
        filename = os.path.join(selected_item.path, selected_item.text(0))
        subprocess.Popen(["thg", "vdiff", filename], cwd=self.get_project_path())

    def hg_add(self):
        """Call thg add."""
        selected_item = self.explorer_s.get_current_project_item()
        filename = os.path.join(selected_item.path, selected_item.text(0))
        subprocess.Popen(["thg", "add", filename], cwd=self.get_project_path())

    def hg_revert(self):
        """Call thg revert."""
        selected_item = self.explorer_s.get_current_project_item()
        filename = os.path.join(selected_item.path, selected_item.text(0))
        subprocess.Popen(["thg", "revert", filename], cwd=self.get_project_path())

    def hg_rename(self):
        """Call thg rename."""
        selected_item = self.explorer_s.get_current_project_item()
        filename = os.path.join(selected_item.path, selected_item.text(0))
        subprocess.Popen(["thg", "rename", filename], cwd=self.get_project_path())

    def hg_forget(self):
        """Call thg forget."""
        selected_item = self.explorer_s.get_current_project_item()
        filename = os.path.join(selected_item.path, selected_item.text(0))
        subprocess.Popen(["thg", "forget", filename], cwd=self.get_project_path())

    def hg_remove(self):
        """Call thg remove."""
        selected_item = self.explorer_s.get_current_project_item()
        filename = os.path.join(selected_item.path, selected_item.text(0))
        subprocess.Popen(["thg", "remove", filename], cwd=self.get_project_path())

    def refresh_status(self):
        """Refresh color coding in the project explorer."""
        self.initialized = False
        self.check_projects(None)

    def finish(self):
        # Shutdown your plugin
        pass

    def get_preferences_widget(self):
        # Return a widget for customize your plugin
        pass
