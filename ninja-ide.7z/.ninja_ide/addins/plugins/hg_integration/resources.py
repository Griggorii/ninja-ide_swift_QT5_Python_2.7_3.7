# -*- coding: UTF-8 -*-

import os.path

icons_path = os.path.join(os.path.dirname(__file__), "icons")

COMMIT_ICON = os.path.join(icons_path, "commit.png")
HG_ICON = os.path.join(icons_path, "hg.png")
WORKBENCH_ICON = os.path.join(icons_path, "workbench.png")

MODIFIED_COLOR = "#000080"  # dark blue
UNVERSIONED_COLOR = "#800000"  # dark red
