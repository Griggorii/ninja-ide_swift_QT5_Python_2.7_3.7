SELENIUM_TEMPLATE = """{}
# imports
import sys
from os import path
from splinter import Browser  # http://splinter.cobrateam.info
# http://nose.readthedocs.org/en/latest/testing_tools.html#tools-for-testing
from nose.tools import (ok_, eq_, raises, timed, set_trace,  # lint:ok
                        make_decorator, istest, nottest, with_setup)  # lint:ok


# constants
sys.path.append("{}")
BASE_URL = '{}'  # 'http://localhost:8000'
AUTH_DATA = {}
FORM_DATA = {}
FILE_UPLD = 'file_upload'
TEST_FILE = __file__
IFRAMEURL = '{}'
JAVASCRPT = '{}'
TITLE_TXT = '{}'


###############################################################################


class Main(object):
    ' main test class '
    def __init__(self):
        ' init test '
        with Browser('{}') as browser:
            self.browser = browser
            {}self.test_page_loading()
            {}self.test_sucess_status_code()
            {}self.test_title()
            {}self.test_title_content()
            {}self.test_cookies()
            {}self.test_back_forward_reload()
            {}self.test_javascript()
            {}self.test_screenshot()
            {}self.test_search()
            {}self.test_iframe()
            {}self.test_canvas_tag()
            {}self.test_svg_tag()
            {}self.test_audio_tag()
            {}self.test_video_tag()
            {}self.test_file_upload(FILE_UPLD, TEST_FILE)

    @timed({})
    def test_page_loading(self):
        'test page loading with a timeout'
        self.browser.visit(BASE_URL)

    @istest
    def test_search(self):
        'add test for Search form here'
        self.browser.fill('q', 'testing search form')
        try:
            match = (self.browser.find_by_name('submit') or
                     # self.browser.find_by_value('submit') or
                     # self.browser.find_link_by_partial_text('submit') or
                     self.browser.find_by_css('submit'))
            match.first.click()
        except:
            pass

    @istest
    def test_audio_tag(self):
        'add test for HTML5 AUDIO tag here'
        return ok_(self.browser.is_element_present_by_tag('audio'))

    @istest
    def test_video_tag(self):
        'add test for HTML5 VIDEO tag here'
        return ok_(self.browser.is_element_present_by_tag('video'))

    @istest
    def test_svg_tag(self):
        'add test for HTML5 SVG tag here'
        return ok_(self.browser.is_element_present_by_tag('svg'))

    @istest
    def test_canvas_tag(self):
        'add test for HTML5 CANVAS tag here'
        return ok_(self.browser.is_element_present_by_tag('canvas'))

    @istest
    def test_javascript(self):
        'test arbitrary javascript code on the page'
        return eq_(self.browser.execute_script(JAVASCRPT), None)

    @istest
    def test_back_forward_reload(self):
        'test reload, back, and forward on the page'
        return eq_(self.browser.reload() and
                   self.browser.back() and
                   self.browser.forward(), None)

    @istest
    def test_iframe(self):
        'test iframe of the page'
        with self.browser.get_iframe(IFRAMEURL) as iframe:
            return ok_(iframe.status_code.is_success())

    @istest
    def test_sucess_status_code(self):
        'test status code of the page, it must be sucess'
        return ok_(self.browser.status_code.is_success())

    @istest
    def test_title(self):
        'test title on the page, it must exist, and not be empty for valid html'
        return ok_(self.browser.title is not '' and
                   self.browser.title is not None)

    @istest
    def test_title_content(self):
        'test title content on the page'
        return eq_(TITLE_TXT in self.browser.title, True)

    @istest
    def test_cookies(self):
        'test add and remove a cookie for the page '
        return eq_(self.browser.cookies.delete('test')
                   if self.browser.cookies.add(FORM_DATA)
                   else self.browser.cookies.delete(), None)

    @nottest
    def test_file_upload(self, where_to_upload, what_to_upload):
        'test status code of the page, it must be sucess'
        return ok_(self.browser.attach_file(where_to_upload, what_to_upload))

    @istest
    def test_screenshot(self):
        'test a screenshot of the page, store it on disk, useful for CSS debug'
        return self.browser.driver.save_screenshot(path.abspath(
               path.join(path.dirname(sys.argv[0]), 'screenshot_selenium.png')))


###############################################################################


if __name__ == "__main__":
    ' main loop '
    Main()
"""


HEADER = '''#!/usr/bin/env python
# -*- coding: utf-8 -*-


# metadata
' Ninja Selenium Test '
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = '{}'
__email__ = ''
__url__ = ''
__date__ = '{}'
__prj__ = ''
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''

'''