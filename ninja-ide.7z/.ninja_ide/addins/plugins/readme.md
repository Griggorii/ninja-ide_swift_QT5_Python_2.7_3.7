kai - Autocomplete plugin for Ninja-IDE
========================================

Simple autocomplete plugin that would suggest possible word completions
based on the text in the current file/tab.

Right now, completions are case sensitive and are listed for 3 or more
characters words (both should be configurable settings in the near future).

 * Ninja-IDE: http://www.ninja-ide.org/


Why kai?
--------

Meaning *intuition*, it is one of the "nine symbolic cuts" (see kuji-kiri [1])
present in some old and traditional schools of Japanese martial arts.

[1] http://en.wikipedia.org/wiki/Kuji-kiri
