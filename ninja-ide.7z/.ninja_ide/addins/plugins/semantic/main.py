# -*- coding: utf-8 -*-
# PEP8:OK, LINT:OK, PY3:OK


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja-IDE Semantic User Experience Plugin "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = 'github.com/juancarlospaco'
__date__ = '01/05/2013'
__prj__ = 'profilergui'
__docformat__ = 'html'
__source__ = ''
__full_licence__ = 'http://opensource.org/licenses/gpl-3.0.html'


# imports
from os import path
from sip import setapi

from PyQt4.QtGui import (QIcon, QLabel, QFileDialog, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QGroupBox, QMessageBox, QCompleter, QDirModel,
    QTabWidget, QDockWidget, QGraphicsDropShadowEffect, QColor, QCursor, )

from PyQt4.QtCore import (Qt, QDir, QFileInfo)

try:
    from PyKDE4.nepomuk import Nepomuk
    from PyKDE4.kdecore import KUrl
    from PyKDE4.kdeui import KTextEdit as QTextEdit
    from PyKDE4.kdeui import KRatingWidget
except ImportError:
    from PyQt4.QtGui import QTextEdit  # lint:ok

from ninja_ide.core import plugin


# API 2
(setapi(a, 2) for a in ("QDate", "QDateTime", "QString", "QTime", "QUrl",
                        "QTextStream", "QVariant"))


# constants
HELPMSG = '''
<h1>NEPOMUK</h1> (Networked Environment for Personal, Ontology-based Management
of Unified Knowledge) an open source standard concerned with development of a
social semantic desktop experience that enriches and interconnects data from
different apps using semantic metadata stored as RDF.
<h4>Example Implementations of this Technology:</h4><ul><li>
<a href="http://youtube.com/watch?v=d41bmTSogA4">Multimedia Files</a></li><li>
<a href="http://youtube.com/watch?v=w_wPbGQksnE">Photography Files</a></li><li>
<a href="http://youtube.com/watch?v=X5xEjMTR9qw">Dolphin File Manager</a></li>
</ul><h4>Documentation of this Technology:</h4><ul><li>
<a href="http://userbase.kde.org/Nepomuk">Users Documentation</a></li><li>
<a href="http://techbase.kde.org/Projects/Nepomuk">Developers Documentation</a>
</li><li>
<a href="http://techbase.kde.org/Projects/Nepomuk">Nepomuk Documentation</a>
</li></ul>
<h4>Notes:</h4>
KDE, Gnome, Ubuntu Unity, HTML5 and Java uses this Technology.<br>
Links are from KDE because the only proper Documentation.<br>
This Plugin is Beta, so dont complain, patch !<br><br> {}
'''.format(''.join((__doc__, ',v', __version__, __license__, 'by', __author__)))


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)

        # directory auto completer
        self.completer = QCompleter(self)
        self.dirs = QDirModel(self)
        self.dirs.setFilter(QDir.AllEntries | QDir.NoDotAndDotDot)
        self.completer.setModel(self.dirs)
        self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.completer.setCompletionMode(QCompleter.PopupCompletion)

        # tab widget
        self.mainwidget = QTabWidget()
        self.mainwidget.setToolTip(__doc__)
        self.mainwidget.setTabShape(QTabWidget.Triangular)
        self.mainwidget.setMovable(True)
        self.mainwidget.setTabsClosable(True)
        self.mainwidget.tabCloseRequested.connect(lambda:
            self.mainwidget.setTabPosition(1)
            if self.mainwidget.tabPosition() == 0
            else self.mainwidget.setTabPosition(0))
        self.dock1 = QDockWidget()
        self.dock2 = QDockWidget()
        for indx, a in enumerate((self.dock1, self.dock2)):
            a.setWindowModality(Qt.NonModal)
            a.setWindowOpacity(0.9)
            a.setWindowTitle('Semantic Files' if indx == 0 else 'Simple Query')
            a.setStyleSheet('QDockWidget::title{text-align:center;}')
            self.mainwidget.addTab(a, QIcon.fromTheme("nepomuk"),
                             'Semantic Files' if indx == 0 else 'Simple Query')

        QPushButton(QIcon.fromTheme("help-about"), 'Help About', self.dock1
          ).clicked.connect(lambda:
          QMessageBox.information(self.dock1, __doc__, HELPMSG))

        # Group of widgets for each tab
        self.group1 = QGroupBox()
        self.filename = QLineEdit()
        self.filename.setPlaceholderText('/full/path/to/one_file.py')
        self.filename.setCompleter(self.completer)
        self.filebttn = QPushButton(QIcon.fromTheme("folder-open"), 'Open File')
        self.filebttn.clicked.connect(lambda: self.filename.setText(str(
            QFileDialog.getOpenFileName(self.mainwidget,
            " Please, open a .py file to add Semantics ", path.expanduser("~"),
            ';;'.join(['(*.{}) {}'.format(e, e.upper()) for e in ['*', 'py']])))
        ))

        self.group1a = QGroupBox()
        self.filetag = QLineEdit()
        self.filetag.setPlaceholderText('Type a short Tag for the choosen File')
        self.filelbl = QLineEdit()
        self.filelbl.setPlaceholderText('Type a descriptive Label for the Tag')
        self.filedsc = QLineEdit()
        self.filedsc.setPlaceholderText('Type a large and detailed Description')
        self.filerat = KRatingWidget()
        self.filerat.setToolTip('Set a File Rating')
        vboxg1a = QHBoxLayout(self.group1a)
        for each_widget in (QLabel('<b>File Tag'), self.filetag,
            QLabel('<b>Tag Label'), self.filelbl,
            QLabel('<b>Description'), self.filedsc,
            QLabel('<b>File Rating'), self.filerat):
            vboxg1a.addWidget(each_widget)

        self.nepobtn = QPushButton(QIcon.fromTheme("nepomuk"), 'Add Semantics')
        self.nepobtn.setMinimumSize(self.nepobtn.size().width(), 50)
        self.nepobtn.clicked.connect(lambda: self.nepomuk_set(
            str(self.filename.text()).strip(), str(self.filetag.text()).strip(),
            str(self.filelbl.text()).strip(), str(self.filedsc.text()).strip()))
        vboxg1 = QVBoxLayout(self.group1)
        for each_widget in (
            QLabel('<b>Choose a File'), self.filename, self.filebttn,
            self.group1a, self.nepobtn):
            vboxg1.addWidget(each_widget)

        self.group2 = QGroupBox()
        self.group2.setTitle('Sorry!, this Tab is not Ready yet...')
        QLabel('<b style="color:red;"><i>Not Ready Yet!', self.dock2)
        self.search = QLineEdit()
        self.search.setPlaceholderText('Type to Query...')
        self.srcbtn = QPushButton(QIcon.fromTheme("folder-open"), 'Query')
        self.result = QTextEdit()
        self.srcbtn.clicked.connect(lambda:
            self.nepomuk_get(str(self.search.text()).strip().lower()))
        vboxg2 = QVBoxLayout(self.group2)
        for each_widget in (
            QLabel('<b>Type for a Semantic Query'), self.search, self.srcbtn,
            QLabel('<b>Semantic Query Results'), self.result):
            vboxg2.addWidget(each_widget)

        # pack the group of widgets on the gui
        self.dock1.setWidget(self.group1)
        self.dock2.setWidget(self.group2)

        # pack the plugin on ninja-ide gui
        self.locator.get_service('misc').add_widget(
                        self.mainwidget, QIcon.fromTheme("nepomuk"), __doc__)

        def must_have_tooltip(widget_list):
            ' widget tuple passed as argument should have tooltips '
            for each_widget in widget_list:
                try:
                    each_widget.setToolTip(each_widget.text())
                except:
                    each_widget.setToolTip(each_widget.currentText())
                finally:
                    each_widget.setCursor(QCursor(Qt.PointingHandCursor))

        def must_glow(widget_list):
            ' apply an glow effect to the widget '
            for glow, each_widget in enumerate(widget_list):
                try:
                    if each_widget.graphicsEffect() is None:
                        glow = QGraphicsDropShadowEffect(self)
                        glow.setOffset(0)
                        glow.setBlurRadius(99)
                        glow.setColor(QColor(99, 255, 255))
                        each_widget.setGraphicsEffect(glow)
                        # glow.setEnabled(False)
                        try:
                            each_widget.clicked.connect(lambda:
                            each_widget.graphicsEffect().setEnabled(True)
                            if each_widget.graphicsEffect().isEnabled() is False
                            else each_widget.graphicsEffect().setEnabled(False))
                        except:
                            each_widget.sliderPressed.connect(lambda:
                            each_widget.graphicsEffect().setEnabled(True)
                            if each_widget.graphicsEffect().isEnabled() is False
                            else each_widget.graphicsEffect().setEnabled(False))
                except:
                    pass

        must_have_tooltip((self.filebttn, self.nepobtn, self.srcbtn, ))
        must_glow((self.nepobtn, self.srcbtn, ))

    def nepomuk_set(self, file_tag=None, __tag='', _label='', _description=''):
        ' Quick and Easy Nepomuk Taggify for Files '
        print((''' INFO: Semantic Desktop Experience is Tagging Files :
              {}, {}, {}, {})'''.format(file_tag, __tag, _label, _description)))
        if Nepomuk.ResourceManager.instance().init() is 0:
            fle = Nepomuk.Resource(KUrl(QFileInfo(file_tag).absoluteFilePath()))
            _tag = Nepomuk.Tag(__tag)
            _tag.setLabel(_label)
            fle.addTag(_tag)
            fle.setRating(int(self.filerat.rating()))
            fle.setDescription(_description)
            print(([str(a.label()) for a in fle.tags()], fle.description()))
            return ([str(a.label()) for a in fle.tags()], fle.description())
        else:
            print(" ERROR: FAIL: Nepomuk is not running ! ")

    def nepomuk_get(self, query_to_search):
        ' Quick and Easy Nepomuk Query for Files '
        print((''' INFO: Semantic Desktop Experience is Quering Files :
              {} '''.format(query_to_search)))
        results = []
        nepo = Nepomuk.Query.QueryServiceClient()
        nepo.desktopQuery("hasTag:{}".format(query_to_search))

        def _query(data):
            ''' ('filename.ext', 'file description', ['list', 'of', 'tags']) '''
            print(([str(a.resource().genericLabel()) for a in data][0],
                   [str(a.resource().description()) for a in data][0],
            [str(a.label()) for a in iter([a.resource().tags() for a in data][0]
            )]))
            self.result.append(str(
                ([str(a.resource().genericLabel()) for a in data][0],
                 [str(a.resource().description()) for a in data][0],
            [str(a.label()) for a in iter([a.resource().tags() for a in data][0]
            )],
            )))
        nepo.newEntries.connect(_query)
        nepo.finishedListing.connect(lambda: nepo.newEntries.disconnect)
        return results


###############################################################################


if __name__ == "__main__":
    print(__doc__)
