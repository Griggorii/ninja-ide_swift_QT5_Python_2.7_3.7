# -*- coding: utf-8 -*-
# PEP8:OK, LINT:OK, PY3:OK


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja PDF Doc Reader "
__version__ = ' 0.4 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 20/07/2013 '
__prj__ = ' pdfview '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path

from PyQt4.QtGui import (QIcon, QLabel, QDockWidget, QPushButton, QFileDialog,
    QWidget, QVBoxLayout, QCursor, QGraphicsDropShadowEffect, QColor,
    QScrollArea)
from PyQt4.QtCore import Qt

try:
    from PyKDE4.kparts import *
    from PyKDE4.kdecore import KUrl, KPluginLoader
except ImportError:
    pass

from ninja_ide.gui.explorer.explorer_container import ExplorerContainer
from ninja_ide.core import plugin


#constans
LASTDOC = path.join(path.abspath(path.dirname(__file__)), "lastdoc.txt")


###############################################################################


class PDFS(plugin.Plugin):
    " PDFS Class "
    def initialize(self, *args, **kwargs):
        " Init Class Terminal "
        ec = ExplorerContainer()
        super(PDFS, self).initialize(*args, **kwargs)
        self.dock, self.scrollable = QDockWidget(), QScrollArea()
        self.dock.setWindowTitle(__doc__)
        self.dock.setStyleSheet('QDockWidget::title{text-align:center}')
        self.scrollable.setWidgetResizable(True)
        self.dock.setWidget(self.scrollable)
        self.openfile = QPushButton(QIcon.fromTheme("folder-open"),
                                    "Open", self.dock)
        self.openfile.setCursor(QCursor(Qt.PointingHandCursor))
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0)
        glow.setBlurRadius(99)
        glow.setColor(QColor(99, 255, 255))
        glow.setEnabled(True)
        self.openfile.setGraphicsEffect(glow)

        class TransientWidget(QWidget):
            ' persistant widget thingy '
            def __init__(self, widget):
                ' init sub class '
                super(TransientWidget, self).__init__()
                QVBoxLayout(self).addWidget(widget)
        try:
            self.factory = KPluginLoader("okularpart").factory()
            self.part = self.factory.create(self)
            self.scrollable.setWidget(TransientWidget(self.part.widget()))
            try:
                self.part.openUrl(KUrl(open(LASTDOC, 'r').read()))
            except:
                pass
            self.openfile.clicked.connect(self.getFile)
        except:
            self.scrollable.setWidget(QLabel("""<center>
            <h3>ಠ_ಠ<br>ERROR: Please, install Okular PDF App and PyKDE!</h3><br>
            <br><i>(Sorry, cant embed non-Qt Apps, Python binding are required)
            </i><center>"""))
        ec.addTab(self.dock, "PDF")

    def getFile(self):
        ' get file from config '
        doc = QFileDialog.getOpenFileName(self.dock, " Open PDF Documentation ",
            path.expanduser("~"), ';;'.join(['{}(*.{})'.format(e.upper(), e)
            for e in ['pdf', 'djvu', 'ps', 'tiff', 'chm', 'dvi', 'xps', 'odt',
            'epub', 'mobi', 'jpg', 'jpeg', 'png', 'gif', 'bmp', 'ico', '*']]))
        self.part.openUrl(KUrl(doc))
        with open(LASTDOC, 'w') as f:
            f.write(doc)


###############################################################################


if __name__ == "__main__":
    print(__doc__)
