# -*- coding: utf-8 -*-
from pdfs.main import PDFS