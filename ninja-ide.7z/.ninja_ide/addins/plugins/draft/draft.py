# -*- coding: UTF-8 -*-

# "THE WISKEY-WARE LICENSE":
# <juan@brainiac> wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a WISKEY in return Juan

#===============================================================================
# DOCS
#===============================================================================

"""A Simple draft editor inspired in "Geany Draft"

1 - Open the misc tab widget
2 - Go to the eraser icon.
3 - Write your text there.
2 - The text will be auto saved for the future.

"""

# ==============================================================================
# META
# ==============================================================================

__prj__ = 'Ninja Draft'
__version__ = '0.1'
__license__ = "THE WISKEY-WARE LICENSE"
__author__ = 'JuanBC'
__email__ = 'jbc.develop@gmail.com'
__url__ = 'https://bitbucket.org/leliel12/ninja-ide_plugins'

__full_license__ = """
"THE WISKEY-WARE LICENSE":
<jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
can do whatever you want with this stuff. If we meet some day, and you think
this stuff is worth it, you can buy me a wiskey in return JuanBC"""


#===============================================================================
# IMPORT
#===============================================================================

import os
import codecs
import string

from PyQt4 import QtGui

from ninja_ide.core import plugin
from ninja_ide import resources


#===============================================================================
# CONSTANTS
#===============================================================================

PATH = os.path.abspath(os.path.dirname(__file__))

ICON_PATH = os.path.join(PATH, "draft.png")

DRAFT_FILE = os.path.join(resources.HOME_NINJA_PATH, "draft.txt")

ENCODING = "utf-8"

DRAFT_DEFAULT_TEXT = """This a simple draft
Write here for and your text will be auto saved
===============================================

"""

# $body
HTML_TEMPLATE = string.Template("""
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html><head><meta name="qrichtext" content="1" /><style type="text/css">
p, li { white-space: pre-wrap; }
</style></head><body style=" font-family:'Ubuntu'; font-size:10pt; font-weight:400; font-style:normal;">$body</body></html>
""".strip())

# $title $doc $author $version $url $license
ABOUT_TEMPLATE = string.Template("""
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">$title</span></p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">$doc</p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">Author: </span>$author</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">Version: </span>$version</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">Homepage: </span><a href="$url"><span style=" text-decoration: underline; color:#0000ff;">$url</span></a></p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">License:</span></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">$license</p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"></p>
""".strip())


#===============================================================================
# PLUGINS
#===============================================================================

class Draft(plugin.Plugin):

    def initialize(self):
        # Init your plugin
        self.misc_s = self.locator.get_service('misc')
        self.editor = QtGui.QPlainTextEdit()

        # add to service
        self.misc_s.add_widget(self.editor, ICON_PATH, __doc__)

        # connect events
        self.editor.textChanged.connect(self.on_editor_textChanged)

        # if exist read old data or set a welcome mensaje
        if os.path.exists(DRAFT_FILE):
            with codecs.open(DRAFT_FILE, encoding=ENCODING) as fp:
                self.editor.setPlainText(fp.read())
        else:
            self.editor.setPlainText(DRAFT_DEFAULT_TEXT)


    def finish(self):
        self.on_editor_textChanged()

    def get_preferences_widget(self):
        richtext = lambda code: "<br/>".join(
            code.replace("<", "&lt;").replace(">", "&gt;").splitlines()
        )
        self.aboutLabel = QtGui.QLabel()
        about_msg = HTML_TEMPLATE.substitute(
                        body=ABOUT_TEMPLATE.substitute(
                            title=richtext(__prj__),
                            doc=richtext(__doc__),
                            author=richtext(__author__),
                            version=richtext(__version__),
                            url=richtext(__url__),
                            license=richtext(__full_license__)
                        )
                    )
        self.aboutLabel.setText(about_msg)
        return self.aboutLabel

    def on_editor_textChanged(self):
        text = self.editor.toPlainText()
        with codecs.open(DRAFT_FILE, "w", encoding=ENCODING) as fp:
            fp.write(text)


#===============================================================================
# MAIN
#===============================================================================

if __name__ == "__main__":
    print(__doc__)
