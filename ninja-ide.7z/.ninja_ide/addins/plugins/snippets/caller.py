#!/usr/bin/env python
# -*- coding: utf-8 *-*

# THE WISKEY-WARE LICENSE
# -----------------------

# "THE WISKEY-WARE LICENSE":
# <jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC


#===============================================================================
# DOCS
#===============================================================================

"""Execute the cmd an return the standar output or raises an exception

"""

    
#===============================================================================
# META
#===============================================================================

__author__ = "jbc <jbc.develop@gmail.com>"
__version__ = "0.2.1"
__license__ = "THE WISKEY-WARE LICENSE"


#===============================================================================
# IMPORTS
#===============================================================================

import subprocess
import shlex


#===============================================================================
# FUNCTIONS
#===============================================================================

def call(cmd):
    """Execute the cmd an return the standar output or raises an exception

    """
    try:
        pcmd = shlex.split(cmd)
        p = subprocess.Popen(pcmd, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()
        if p.returncode:
            raise Exception(stderr)
        return stdout
    except Exception as err:
        return str(err)
    

#==============================================================================
# MAIN
#===============================================================================

if __name__ == "__main__":
    print(__doc__)

