#!/usr/bin/env python
# -*- coding: utf-8 *-*

# THE WISKEY-WARE LICENSE
# -----------------------

# "THE WISKEY-WARE LICENSE":
# <jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC


#===============================================================================
# DOCS
#===============================================================================

"""Plugin for create snippets in Ninja-IDE.

Usage:

  1. Write your template.
  2. When you're editing a file wrote the name of
     the snippet and hit the <TAB> to activate the
     snippets.
  3. The name of the snippet is replaced by its
     contents defined.
  4. The snippet's name are resolved depending on
     the extension of the file being edited. If
     the extension does not exist or no snippet
     searches the group *GENERAL*.

- Use Export Button for copy yours plugin in json file.
- Use Import Button for merge your snippets with exported file.
- Create your own variables or hide the default ones.
- Use your variables as '${VARIABLE NAME}'.

"""


#===============================================================================
# META
#===============================================================================

__prj__ = 'snippets_plugin'
__version__ = '0.4'
__license__ = "THE WISKEY-WARE LICENSE"
__author__ = 'JuanBC'
__email__ = 'jbc.develop@gmail.com'
__url__ = 'https://bitbucket.org/leliel12/ninja-ide_snippets_plugin'
__date__ = '2011/10/27'

__full_license__ = """
"THE WISKEY-WARE LICENSE":
<jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
can do whatever you want with this stuff. If we meet some day, and you think
this stuff is worth it, you can buy me a wiskey in return JuanBC"""


#===============================================================================
# IMPORTS
#===============================================================================

import os
import json
import datetime
import string
import socket
import getpass
import shutil

from PyQt4.QtCore import Qt
from PyQt4.QtCore import pyqtSignal

from PyQt4.QtGui import QInputDialog
from PyQt4.QtGui import QTextCursor
from PyQt4.QtGui import QMessageBox
from PyQt4.QtGui import QListWidgetItem
from PyQt4.QtGui import QFileDialog
from PyQt4.QtGui import QTableWidgetItem

from ninja_ide.core import plugin

from ninja_ide.tools import json_manager
from ninja_ide.gui.editor import editor

import constants
import caller


def str_qt(text):
    '''
    Wrapper to work with PyQT API 1 and 2
    '''
    import sip
    if sip.getapi("QString") == 1:
        from PyQt4.QtCore import QString, QVariant
        if isinstance(text, (QVariant, QString)):
            return str(text.toString())

    return text



#===============================================================================
# VARIABLE EDITION DIALOG
#===============================================================================

class VarsEditDialog(constants.UI("VarsEditDialog.ui")):
    """This dialog is used for edit the user variables

    """

    def __init__(self, variables, *args):
        super(self.__class__, self).__init__(*args)
        self.v_names = variables.keys()
        self.varsTableWidget.setRowCount(len(variables))
        for idx, data in enumerate(variables.items()):
            var_name, var_value = data
            var_name_item = QTableWidgetItem(var_name)
            var_value_item = QTableWidgetItem(var_value)
            self.varsTableWidget.setVerticalHeaderItem(idx, var_name_item)
            self.varsTableWidget.setItem(idx, 0, var_value_item)
        self.varsTableWidget.resizeColumnsToContents()

    def on_newVarButton_pressed(self, *args):
        """Create a new variable using a pop up for prevet duplicated names

        """
        title = self.tr("New Variable")
        msg = self.tr("Variable Name")
        vname, ok = QInputDialog.getText(self, title, msg)
        if ok:
            if str(vname) in self.v_names:
                title = self.tr("Variable Name Exists")
                msg = self.tr("Variable name '%1' already exists")
                QMessageBox.information(self, title, msg.arg(vname))
            else:
                idx = self.varsTableWidget.rowCount()
                var_name_item = QTableWidgetItem(vname)
                var_value_item = QTableWidgetItem(self.tr("<new value>"))
                self.varsTableWidget.setRowCount(idx + 1)
                self.varsTableWidget.setVerticalHeaderItem(idx, var_name_item)
                self.varsTableWidget.setItem(idx, 0, var_value_item)
                self.varsTableWidget.setCurrentItem(var_value_item)
                self.varsTableWidget.editItem(var_value_item)
                self.removeVarButton.setEnabled(True)
                self.v_names.append(vname)

    def on_removeVarButton_pressed(self, *args):
        """Remove a variable

        """
        ridx = self.varsTableWidget.currentRow()
        vname = str(self.varsTableWidget.verticalHeaderItem(ridx).text())
        self.v_names.remove(vname)
        self.varsTableWidget.removeRow(ridx)
        self.removeVarButton.setEnabled(False)

    def on_varsTableWidget_currentCellChanged (self, *args):
        """Activate de remove var Button

        """
        self.removeVarButton.setEnabled(True)

    @property
    def variables(self):
        """Recolect all variables from table and return it as dict}

        """
        vs = {}
        for ridx in range(self.varsTableWidget.rowCount()):
            vname = str(self.varsTableWidget.verticalHeaderItem(ridx).text())
            vvalue = str(self.varsTableWidget.item(ridx, 0).text())
            vs[vname] = vvalue
        return vs


#===============================================================================
# FRAME FOR CONFIGURE YOUR SNIPPET
#===============================================================================

class SnippetConfigurationFrame(constants.UI("SnippetConfigurationFrame.ui")):
    """This Frame is showed in Ninja-Ide preferences dialog.

    """

    # emit this signal on save method
    saved = pyqtSignal(dict, name="saved")

    def __init__(self, snippets, *args):
        super(self.__class__, self).__init__(*args)

        self.editor = editor.create_editor()
        self.editor.setParent(self)
        self.editor.register_syntax(syntax=constants.SYNTAX)
        self.editorLayout.addWidget(self.editor)
        self.vars = snippets.get(constants.USER_VARS_KEY, {})
        self.snippets = snippets
        self.reset()

    def on_languagesList_currentItemChanged(self, enter_item, exit_item):
        """This slot is call when an item changes on languagesList. Creates
        the new snippetList based ons snippets dictionary.

        """
        if enter_item:
            self.removeLanguageButton.setEnabled(True)
            self.newSnippetButton.setEnabled(True)
            self.snippetList.clear()
            lang_snippets = self.snippets[str(enter_item.text())]
            for snippet_name in sorted(lang_snippets.keys()):
                sitem = QListWidgetItem()
                sitem.setData(Qt.AccessibleDescriptionRole, enter_item.text())
                sitem.setText(snippet_name)
                self.snippetList.addItem(sitem)

    def on_snippetList_currentItemChanged(self, enter_item, exit_item):
        """This slot is called when anithing changes in snippetsList
        (on_languagesList_currentItemChanged call this function autmagically)

        1. Store the snippet open.
        2. Set up the editor based on new item

        """
        if exit_item:
            lang = str_qt(exit_item.data(Qt.AccessibleDescriptionRole))
            sname = str(exit_item.text())
            svalue = str(self.editor.get_text())
            if lang in self.snippets and sname in self.snippets[lang]:
                self.snippets[lang][sname] = svalue

        lang = str_qt(enter_item.data(Qt.AccessibleDescriptionRole)) if enter_item else ""
        sname = str(enter_item.text()) if enter_item else ""
        svalue = self.snippets[lang][sname] if enter_item else ""
        read_only = False if enter_item else True

        self.snippetPathLabel.setText("{0} - {1}".format(lang, sname))
        self.editor.setPlainText(svalue)
        self.editor.setReadOnly(read_only)
        self.removeSnippetButton.setEnabled(enter_item != None)

    def on_addLanguageButton_pressed(self, *args):
        """This slot is called when a  addLanguageButton is pressed

        1 - Retrieve the new language name with a poup.
        2 - Verify if the name is not exists.
        3 - Create a new language.
        4 - Change the current item to the new language.


        """
        title = self.tr("New Language")
        msg = self.tr("File Extension")
        lang, ok = QInputDialog.getText(self, title, msg)
        if ok:
            lang = str(lang).lower()
            if lang in self.snippets:
                title = self.tr("Language Extension Exists")
                msg = self.tr("Language extension '%1' already exists")
                QMessageBox.information(self, title, msg.arg(lang))
            else:
                lang_item = QListWidgetItem()
                lang_item.setText(lang)
                self.snippets[lang] = {}
                self.languagesList.addItem(lang_item)
                self.languagesList.setCurrentItem(lang_item)

    def on_newSnippetButton_pressed(self, *args):
        """This slot is called when a  newLanguageButton is pressed

        1 - Retrieve the new snippet name with a poup.
        2 - Verify if the name is not exists.
        3 - Create a new snippet on selected language.
        4 - Change the current snippet to the new snippet.


        """
        title = self.tr("New Snippet")
        msg = self.tr("Snippet Name")
        sname, ok = QInputDialog.getText(self, title, msg)
        if ok:
            lang_item = self.languagesList.currentItem()
            lang = lang_item.text()
            if str(sname) in self.snippets[str(lang)]:
                title = self.tr("Snippet Exists")
                msg = self.tr("Snippet name '%1' already exists in '%2'")
                QMessageBox.information(self, title, msg.arg(sname, lang))
            else:
                snippet_item = QListWidgetItem()
                snippet_item.setText(sname)
                snippet_item.setData(Qt.AccessibleDescriptionRole, lang)
                self.snippets[str(lang)][str(sname)] = ""
                self.snippetList.addItem(snippet_item)
                self.snippetList.setCurrentItem(snippet_item)

    def on_removeLanguageButton_pressed(self, *args):
        """This slot is called when a  removeLanguageButton is pressed

        1 - Retrieve the selected language snippet.
        2 - Ask with a popup if the user really want to delete the language.
        3 - Removes the language.
        4 - If not exists more languages in languagesLists, reset the editor
            and deactivate remove button.


        """
        lang_item = self.languagesList.currentItem()
        lang = str(lang_item.text())

        title = self.tr("Remove Language File Extension")
        msg = self.tr("Remove language file extension '%1'?")
        status = QMessageBox.question(self, title, msg.arg(lang),
                                      QMessageBox.Ok, QMessageBox.Cancel)

        if status == QMessageBox.Ok:
            row = self.languagesList.row(lang_item)
            self.snippets.pop(lang)
            self.languagesList.takeItem(row)
            if not self.languagesList.count():
                self.removeLanguageButton.setEnabled(False)
                self.newSnippetButton.setEnabled(False)
                self.removeSnippetButton.setEnabled(False)

    def on_removeSnippetButton_pressed(self, *args):
        """This slot is called when a  removeSnippetButton is pressed

        1 - Retrieve the new language selected.
        2 - Ask with a popup if the user really want to delete the snippet.
        3 - Removes the snippet.
        4 - If not exists more snippets in snippestLists Reset the editor and
            deactivate remove button.


        """
        snippet_item = self.snippetList.currentItem()
        sname = str(snippet_item.text())
        lang = str_qt(snippet_item.data(Qt.AccessibleDescriptionRole))

        title = self.tr("Remove Snippet")
        msg = self.tr("Remove snippet '%1'?")
        status = QMessageBox.question(self, title, msg.arg(sname),
                                      QMessageBox.Ok, QMessageBox.Cancel)
        if status == QMessageBox.Ok:
            row = self.snippetList.row(snippet_item)
            self.snippets[lang].pop(sname)
            self.snippetList.takeItem(row)
            if not self.snippetList.count():
                self.removeSnippetButton.setEnabled(False)

    def on_varsButton_pressed(self, *args):
        """Open dialog for edit the user variables

        """
        dialog = VarsEditDialog(self.vars)
        dialog.exec_()
        if dialog.result():
            self.vars = dialog.variables
        dialog.destroy()
        del dialog

    def on_importButton_pressed(self, *args):
        """Open a file dialog for merge the snippets with json file

        """
        filepath = QFileDialog.getOpenFileName(
                       self, self.tr("Import Snippets..."),
                       constants.HOME_PATH,
                       self.tr("JSON (*.json)")
                   )
        if filepath:
            try:
                with open(filepath) as fp:
                    imported = json.load(fp)
                for lang_name, lang_snippets in imported.items():
                    if lang_name in self.snippets:
                        self.snippets[lang_name].update(lang_snippets)
                    else:
                        self.snippets[lang_name] = lang_snippets
            except Exception as err:
                title = self.tr("Error")
                msg = str(err)
                QMessageBox.critical(self, title, msg)
            else:
                self.reset()
                title = self.tr("Success!")
                msg = self.tr("Successfully merged imported file: %1").arg(filepath)
                QMessageBox.information(self, title, msg)

    def on_exportButton_pressed(self, *args):
        """Open a file dialog for save the snippets in json file

        """
        s_path = os.path.join(constants.HOME_PATH, "export.json")
        count = 0
        while os.path.exists(s_path):
            count += 1
            s_path = os.path.join(constants.HOME_PATH,
                                  "export_{0}.json".format(count))
        filepath = QFileDialog.getSaveFileName(
                       self, self.tr("Export Snippets..."),
                       s_path,
                       self.tr("JSON (*.json)")
                   )
        if filepath:
            try:
                shutil.copyfile(constants.SNIPPETS_FILE_PATH, filepath)
            except Exception as err:
                title = self.tr("Error")
                msg = str(err)
                QMessageBox.critical(self, title, msg)
            else:
                title = self.tr("Success!")
                msg = self.tr("Successfully export file to: %1").arg(filepath)
                QMessageBox.information(self, title, msg)

    def on_helpButton_pressed(self, *args):
        """Open a modal information dialog with the help_msg of
        the snippet widget.

        """
        help_msg = []
        help_msg.append(str(self.tr(__doc__)))
        help_msg.append(str(self.tr("Variables\n")))
        for k in dir(constants):
            if k.startswith("VAR_"):
                vn, vd, _ = getattr(constants, k)
                vn = vn if vn.startswith("%") else "$" + vn
                doc = "  {0} - {1}".format(vn, str(self.tr(vd)))
                help_msg.append(doc)

        QMessageBox.information(self,
                                self.tr("Help"),
                                "\n".join(help_msg))

    def on_aboutButton_pressed(self, *args):
        """Show the about snippet plugin

        """
        title = self.tr("About...")
        msg = []
        msg.append("{0}: {1}".format(__prj__, __doc__.splitlines()[0]))
        msg.append("Ver.: {0}".format(__version__))
        msg.append("Author: {0} <{1}>".format(__author__, __email__))
        msg.append("Homepage: {0}".format(__url__))
        msg.append("")
        msg.append("License:\n{0}".format(__full_license__))
        QMessageBox.about(self, title, "\n".join(msg))

    def reset(self):
        """Restart all the gui bases on self.snippets"""
        self.removeLanguageButton.setEnabled(False)
        self.newSnippetButton.setEnabled(False)
        self.removeSnippetButton.setEnabled(False)
        self.snippetPathLabel.setText("-")
        self.languagesList.clear()
        self.snippetList.clear()
        self.editor.setPlainText("")
        self.editor.setReadOnly(True)
        for lang_name in sorted(self.snippets.keys()):
            if not lang_name.startswith("_"):
                lang_item = QListWidgetItem()
                lang_item.setText(lang_name)
                self.languagesList.addItem(lang_item)

    def parent(self):
        """This method return a fake hierarchy of parent

        In ninja the editor objects acces to super parent and try to
        execute functions in it. This method
        """
        class Fake(object):
            def __call__(self, *args, **kwargs):
                return Fake()
            def __getattribute__(self, *args, **kwargs):
                return Fake()

        return Fake()

    def save(self):
        """Called from ninja ide when save button is called

        """
        last_snippet_item_edited = self.snippetList.currentItem()
        self.snippetList.currentItemChanged.emit(None, last_snippet_item_edited)
        data = self.snippets
        data.update({constants.USER_VARS_KEY: self.vars})
        self.saved.emit(data)


#===============================================================================
# MAIN PLUGIN
#===============================================================================

class Snippets(plugin.Plugin):

    def _last_word(self, tab):
        """Retrieves the las word before key event was pressed

        """
        to_pos = tab.get_cursor_position()
        from_pos = to_pos - 1
        while from_pos > 0 \
              and not constants.RX_WORD.match(tab.get_selection(from_pos, to_pos)):
            from_pos -= 1
        word = tab.get_selection(from_pos, to_pos).strip()
        if word and from_pos > 0:
            from_pos += 1
        return word, from_pos, to_pos

    def _get_snippet_template(self, word, tab):
        """Retrieve a replacement for a word if is snippet or
        empty string if word is not exist

        """

        filename = os.path.basename(tab.ID).lower()
        lang = filename.rsplit(".", 1)[1] if "." in filename else ""
        return constants._.get(word) \
               or self.snippets.get(lang, {}).get(word) \
               or self.snippets.get("*GENERAL*", {}).get(word) \
               or ""

    def _multicomment2single(self, snippet_template):
        """Replace a multiline comment for inline comment

        """
        cm = "$" + constants.VAR_COMMENT_INLINE[0]
        co = "$" + constants.VAR_COMMENT_OPEN[0]
        cc = "$" + constants.VAR_COMMENT_CLOSE[0]

        replaced = []
        add = False
        for line in snippet_template.splitlines():
            if  co in line:
                line = line.replace(co, cm)
                add = True
            elif add:
                line = cm + " " + line
            if cc in line:
                line = line.replace(cc, "")
                add = False
            replaced.append(line)
        return "\n".join(replaced)

    def _render(self, snippet_template, tab):
        """Render a snippet_template for snippet based on
        project metadata

        """

        # retrieve data
        syntax = self.editor_s.get_file_syntax(tab)
        comments = syntax.get("comment", [])
        ml_comments = syntax.get("multiline_comment", {})

        prj_path = self.editor_s.get_project_owner(tab)
        prj_meta = json_manager.read_ninja_project(prj_path) if prj_path else {}

        now = datetime.datetime.now()

        # replace $co and $ce if this language
        # not have multiline comments
        if not ml_comments:
            snippet_template = self._multicomment2single(snippet_template)

        # cleanup regex expresion from syntax file
        comment_inline = comments[0].replace("\\", "") if len(comments) else ""
        comment_open = ml_comments.get("open", "").replace("\\", "")
        comment_close = ml_comments.get("close", "").replace("\\", "")

        # create te argument
        args = {
            constants.VAR_COMMENT_INLINE[0]: comment_inline,
            constants.VAR_COMMENT_OPEN[0]: comment_open,
            constants.VAR_COMMENT_CLOSE[0]: comment_close,
            constants.VAR_EMAIL[0]: getpass.getuser() + "@" + socket.gethostname(),
            constants.VAR_HOSTNAME[0]: socket.gethostname(),
            constants.VAR_PROJECT[0]: prj_meta.get("name", ""),
            constants.VAR_LICENSE[0]: prj_meta.get("license", ""),
            constants.VAR_USER[0]: getpass.getuser(),
            constants.VAR_DATE[0]: now.strftime("%Y/%m/%d"),
            constants.VAR_YEAR[0]: now.strftime("%Y"),
            constants.VAR_FILE[0]: os.path.basename(tab.ID),
            constants.VAR_TIME[0]:  now.strftime("%H:%M:%S"),
            constants.VAR_ABSFILE[0]: tab.ID
        }

        # patch with user vars
        user_vars = {}
        for vname, vvalue in self.snippets.get(constants.USER_VARS_KEY, {}).items():
            user_vars[vname] = vvalue
        args.update(user_vars)

        # patch te snippet_template
        return string.Template(snippet_template).safe_substitute(**args)

    def _render_cmd(self, render):
        for match in constants.RX_CMD.findall(render):
            cmd = match.split(":", 1)[1][:-1]
            out = caller.call(str(cmd))
            render = render.replace(match, out, 1)
        return render

    def _adjust_tab(self, render, cursor, snippet_start_pos):
        """Fix all lines pading

        """
        cursor.setPosition(snippet_start_pos)
        cursor.movePosition(QTextCursor.StartOfLine,
                            QTextCursor.MoveAnchor, 1)
        pad = snippet_start_pos - cursor.position()
        if pad:
            lines = []
            for idx, line in enumerate(render.splitlines()):
                line = str(line)
                if idx:
                    line = " " * pad + line
                lines.append(line)
            render = "\n".join(lines)
        return render

    def _resolve_cursor(self, render_tabed, from_pos):
        """Betermine the cursor final position based on "%cursor%" word
        and relative position of the render_tabed.

        """
        while render_tabed.count(constants.VAR_CURSOR[0]) > 1:
            render_tabed = render_tabed.replace(constants.VAR_CURSOR[0], "", 1)
        relative_pos = render_tabed.rfind(constants.VAR_CURSOR[0])
        no_cursor_mark = render_tabed.replace(constants.VAR_CURSOR[0], "")
        abs_pos = from_pos + (relative_pos if relative_pos != -1 else len(render_tabed))
        return abs_pos, no_cursor_mark

    def save_snippets_slot(self, snippets):
        """Save the snippets into file path json file

        """
        with open(constants.SNIPPETS_FILE_PATH, "w") as fp:
            json.dump(snippets, fp, indent=2)
        self.snippets = snippets

    def replace_slot(self, event):
        """Slot for replace snippets when TAB key is pressed

        """
        if event.key() == Qt.Key_Tab:

            # get editor
            tab = self.editor_s.get_actual_tab()

            # match the word for replace and the absolute possition
            word, from_pos, to_pos = self._last_word(tab)
            if not word:
                return

            # retrieve a snippet_template for the snippet
            snippet_template = self._get_snippet_template(word, tab).strip()
            if not snippet_template:
                return

            # start transaction to see all steps as one
            cursor = tab.textCursor()
            cursor.beginEditBlock()

            # resolve %cmd:<COMMAND>%
            render_executed = self._render_cmd(snippet_template)

            # render the snippet replace all variables
            render_vars = self._render(render_executed, tab)

            # adjust the tabulation of all line
            render_tabed = self._adjust_tab(render_vars, cursor, from_pos)

            # delete the text to be replaced
            cursor.setPosition(from_pos)
            cursor.movePosition(QTextCursor.NextCharacter,
                                QTextCursor.KeepAnchor,
                                to_pos - from_pos)
            cursor.removeSelectedText()

            # determine the cursor final position of "%cursor%"
            final_pos, render_final = self._resolve_cursor(render_tabed, from_pos)

            # set te position of the cursor for for paste the snippet
            cursor.setPosition(from_pos)
            cursor.insertText(render_final)

            # set the final position of the cursor
            cursor.setPosition(final_pos)

            # end transaction
            cursor.endEditBlock()
            tab.setTextCursor(cursor)

    # SPE
    def initialize(self):
        #Init your plugin
        if not os.path.exists(constants.SNIPPETS_FILE_PATH):
            shutil.copyfile(constants.SNIPPETS_TEMPLATE_FILE_PATH,
                            constants.SNIPPETS_FILE_PATH)
        with open(constants.SNIPPETS_FILE_PATH) as fp:
            self.snippets = json.load(fp)
        self.editor_s = self.locator.get_service('editor')
        self.editor_s.editorKeyPressEvent.connect(self.replace_slot)

    def finish(self):
        #Shutdown your plugin
        pass

    def get_preferences_widget(self):
        #Return a widget for customize yor plugin
        confFrame = SnippetConfigurationFrame(self.snippets)
        confFrame.saved.connect(self.save_snippets_slot)
        return confFrame


#===============================================================================
# MAIN
#===============================================================================

if __name__ == "__main__":
    print(__doc__)

