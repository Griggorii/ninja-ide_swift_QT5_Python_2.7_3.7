#!/usr/bin/env python
# -*- coding: utf-8 *-*

# THE WISKEY-WARE LICENSE
# -----------------------

# "THE WISKEY-WARE LICENSE":
# <jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC


#===============================================================================
# DOCS
#===============================================================================

"""Out of the box snippets creator for snippet_plugin

"""


#===============================================================================
# IMPORTS
#===============================================================================

import os
import re

from ninja_ide import resources

import pycante


#===============================================================================
# PATHS
#===============================================================================

try:
    # ...works on at least windows and linux.
    # In windows it points to the user"s folder
    #  (the one directly under Documents and Settings, not My Documents)

    # In windows, you can choose to care about local versus roaming profiles.
    # You can fetch the current user"s through PyWin32.
    #
    # For example, to ask for the roaming "Application Data" directory:
    # CSIDL_APPDATA asks for the roaming, CSIDL_LOCAL_APPDATA for the local one
    from win32com.shell import shellcon, shell
    HOME_PATH = shell.SHGetFolderPath(0, shellcon.CSIDL_APPDATA, 0, 0)
except ImportError:
    # quick semi-nasty fallback for non-windows/win32com case
    HOME_PATH = os.path.expanduser("~")


PATH = os.path.abspath(os.path.dirname(__file__))

RESOURCES_PATH = os.path.join(PATH, "res")

SNIPPETS_TEMPLATE_FILE_PATH = os.path.join(RESOURCES_PATH, "template.json")

SNIPPETS_FILE_PATH = os.path.join(resources.HOME_NINJA_PATH, "snippets.json")


#===============================================================================
# REGEX
#===============================================================================

RX_WORD = re.compile(r"\s+\S+( +|\t)", re.UNICODE)

RX_CMD = re.compile(r"%cmd:.*?%", re.UNICODE)


#===============================================================================
# VARIABLES
#===============================================================================

# variable = (variable, doc, regex)

VAR_CURSOR = ("%cursor%",
              "Final position of the cursor after aply plugin",
              r"%cursor%")

VAR_CMD = ("%cmd:<COMMAND>%",
           "Execute COMMAND and write the output",
           r"%cmd:.*%")

VAR_COMMENT_INLINE = ("cm",
                      "Comment mark",
                      r"\$cm")

VAR_COMMENT_OPEN = ("co",
                    "Multiline comment start",
                    r"\$co")

VAR_COMMENT_CLOSE = ("cc",
                     "Multiline comment end",
                     r"\$cc")

VAR_EMAIL = ("email",
             "user@hosname",
             r"\$email")

VAR_PROJECT = ("project",
               "Project name",
               r"\$project")

VAR_DATE = ("date",
            "Today  as 'yyyy/mm/dd'",
            r"\$date")

VAR_YEAR = ("year",
            "Actual year",
            r"\$year")

VAR_FILE = ("file",
            "Actual filename",
            r"\$file")

VAR_TIME = ("time",
            "24 hs clock with seconds",
            r"\$time")

VAR_ABSFILE = ("absfile",
               "Absolute path to file",
               r"\$absfile")

VAR_LICENSE = ("license",
               "The license of the project",
               r"\$license")

VAR_USER = ("user",
            "The actual user of the os",
            r"\$user")

VAR_HOSTNAME = ("hostname",
                "The actual hostname",
                r"\$hostname")


#===============================================================================
# KEYS
#===============================================================================

USER_VARS_KEY = "_*VARS*_"


#===============================================================================
# UI'S
#===============================================================================

UI = pycante.EDir(RESOURCES_PATH)


#===============================================================================
# SYNTAX
#===============================================================================

SYNTAX = {
    "regex": (
       [(v[2], "keyword", "bold") 
        for k, v in globals().items() if k.startswith("VAR_")] 
    )
}


#===============================================================================
# MAIN
#===============================================================================

if __name__ == "__main__":
    print(__doc__)




_ = {"aGFrZWJ1bnNoaW5ub2p1dHN1IQ==\n".decode("base64"):  
     "JGNtIE5pbmphIElERSEK\n".decode("base64") * 10}
