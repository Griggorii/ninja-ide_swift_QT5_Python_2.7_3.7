#!/usr/bin/env python
# -*- coding: utf-8 *-*

# THE WISKEY-WARE LICENSE
# -----------------------

# "THE WISKEY-WARE LICENSE":
# <jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC


#===============================================================================
# DOCS
#===============================================================================

"""Plugin for template snippets in ninja-ide

"""


#===============================================================================
# IMPORTS
#===============================================================================

import snippets
from snippets import Snippets


#===============================================================================
# META GATEWAY
#===============================================================================

__prj__ = snippets.__prj__
__version__ = snippets.__version__
__license__ = snippets.__license__
__author__ = snippets.__author__
__email__ = snippets.__email__
__url__ = snippets.__url__
__date__ = snippets.__date__
__full_license__ = snippets.__full_license__


#===============================================================================
# MAIN
#===============================================================================

if __name__ == '__main__':
    print(__doc__)
