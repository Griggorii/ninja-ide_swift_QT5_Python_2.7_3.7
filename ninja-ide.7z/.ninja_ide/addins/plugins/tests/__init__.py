from gui import DjangoContextExplorer
