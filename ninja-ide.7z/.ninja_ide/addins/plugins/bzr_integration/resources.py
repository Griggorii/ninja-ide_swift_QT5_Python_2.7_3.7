# -*- coding: utf-8 *-*
import os


icons_path = os.path.join(os.path.dirname(__file__), 'icons')

VERSIONED_FILE = os.path.join(icons_path, 'bzr.png')
