# *-* coding: UTF-8 *-*

import os
import subprocess

from ninja_ide.core import file_manager
from ninja_ide.core import plugin

from bzrlib.bzrdir import BzrDir
from bzrlib import errors

from PyQt4.QtCore import SIGNAL

from PyQt4.QtGui import QIcon
from PyQt4.QtGui import QMenu

import resources


class BzrMenu(QMenu):
    def __init__(self, bzr_integration):
        QMenu.__init__(self)
        commit = self.addAction(self.tr("Commit"))
        add = self.addAction(self.tr("Add"))
        diff = self.addAction(self.tr("Diff"))
        push = self.addAction(self.tr("Push"))
        pull = self.addAction(self.tr("Pull"))
        self.connect(commit, SIGNAL("triggered()"), bzr_integration.bzr_commit)
        self.connect(diff, SIGNAL("triggered()"), bzr_integration.bzr_diff)
        #XXX: This needs to eventually take into account the file clicked on
        self.connect(add, SIGNAL("triggered()"), bzr_integration.bzr_add)
        self.connect(push, SIGNAL("triggered()"), bzr_integration.bzr_push)
        self.connect(pull, SIGNAL("triggered()"), bzr_integration.bzr_pull)


class bzr_integration(plugin.Plugin):
    def initialize(self):
        #Init your plugin
        self.editor_s = self.locator.get_service('editor')
        self.toolbar_s = self.locator.get_service('toolbar')
        self.menuApp_s = self.locator.get_service('menuApp')
        self.misc_s = self.locator.get_service('misc')
        self.explorer_s = self.locator.get_service('explorer')
        self.project_path = self.explorer_s.get_actual_project()
        # Show versioned files when starting up
        self.show_versioned()
        # Show versioned files when opening a project as well
        self.explorer_s.projectOpened.connect(self.show_versioned)
        self.workingtree = None
        self.branch = None
        self.repo = None

    def show_versioned(self):
        """Change the icons for the versioned files."""
        self.project_path = self.explorer_s.get_actual_project()
        try:
            self.open_branch()
        except errors.NotBranchError:
            # Not versioned with bzr, nobody's perfect
            return
        extra_menu = BzrMenu(self)
        self.explorer_s.add_project_menu(extra_menu, lang='all')
        versioned_files = self.get_versioned_files()
        project_files = self.get_project_files()
        for file in versioned_files:
            if file in project_files:
                item = self.explorer_s.get_item(
                    os.path.join(self.project_path, file))
                if item:
                    item.set_item_icon(QIcon(resources.VERSIONED_FILE))

    def open_branch(self):
        """Open a branch and stick it in the class."""
        (self.workingtree,
         self.branch,
         self.repo,
         path) = BzrDir.open_containing_tree_branch_or_repository(
             self.project_path)

    def get_versioned_files(self):
        """Get a list of full paths of all versioned files."""
        v_files = []
        if self.workingtree:
            basis_tree = self.workingtree.basis_tree()
            basis_tree.lock_read()
            try:
                all_files = basis_tree.list_files()
                for file in all_files:
                    if file[2] == 'file':
                        v_files.append(file[0])
            finally:
                basis_tree.unlock()
        return v_files

    def get_project_files(self):
        """Get a list of full paths for all files in the project."""
        inventory = []
        paths = file_manager.open_project(self.project_path)
        for dir, files in paths.iteritems():
            # Exclude anything in .bzr
            if '.bzr' not in dir:
                rel_dir = dir.replace(self.project_path, '')[1:]
                if rel_dir:
                    rel_dir = rel_dir + '/'
                for file in files[0]:
                    inventory.append(rel_dir + file)
        return inventory

    def bzr_commit(self):
        """Call qbzr commit."""
        subprocess.call(['bzr', 'qcommit'], cwd=self.project_path)

    def bzr_add(self):
        """Call qbzr add."""
        #XXX: This needs to eventually take into account the file clicked on
        subprocess.call(['bzr', 'qadd'], cwd=self.project_path)

    def bzr_diff(self):
        """Call qbzr diff."""
        subprocess.call(['bzr', 'qdiff'], cwd=self.project_path)

    def bzr_push(self):
        """Call qbzr push."""
        subprocess.call(['bzr', 'qpush'], cwd=self.project_path)

    def bzr_pull(self):
        """Call qbzr pull."""
        subprocess.call(['bzr', 'qpull'], cwd=self.project_path)

    def finish(self):
        #Shutdown your plugin
        pass

    def get_preferences_widget(self):
        #Return a widget for customize yor plugin
        pass
