# -*- coding: utf-8 -*-
from dotdesktop.main import *