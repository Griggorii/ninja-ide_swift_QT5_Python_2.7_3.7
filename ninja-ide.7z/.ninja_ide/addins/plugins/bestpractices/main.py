#!/usr/bin/env python
# -*- coding: utf-8 -*-
# PEP8:OK, LINT:OK, PY3:OK


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Best Practice Checker "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = '30/10/2013'
__prj__ = 'bestpractices'
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from sip import setapi
import ast
from datetime import datetime

from PyQt4.QtGui import (QLabel, QPushButton, QWidget, QDockWidget, QVBoxLayout,
    QIcon, QComboBox, QGraphicsDropShadowEffect, QColor, QMessageBox, QGroupBox,
    QSpinBox, QScrollArea)

try:
    from PyKDE4.kdeui import KTextEdit as QTextEdit
except ImportError:
    from PyQt4.QtGui import QTextEdit  # lint:ok

from ninja_ide.gui.explorer.explorer_container import ExplorerContainer
from ninja_ide.core import plugin


# constants
HELPMSG = '''<h3>Ninja Best Practice Checker</h3><i>Go beyond PEP-8!</i><br><br>
''' + ''.join((__doc__, ', v', __version__, __license__, 'by', __author__))
FILE, CLASS, FUNCTION, LINENR, LEVEL = 0, 1, 2, 3, 4
MAXVAL = {'maxAttributesPerClass': 20, 'maxFunctionsPerClass': 20,
    'maxFunctionsPerFile': 20, 'maxClassesPerFile': 5,
    'maxParametersPerFunction': 5, 'maxLinesPerFunction': 100,
    'maxControlStatementsPerFunction': 20, 'maxLinesPerFile': 999,
    'maxIndentationLevel': 5, 'maxTabs': 5}


# API 2
(setapi(a, 2) for a in ("QDate", "QDateTime", "QString", "QTime", "QUrl",
                        "QTextStream", "QVariant"))


###############################################################################


class Main(plugin.Plugin):
    ' main class for plugin '
    def initialize(self, *args, **kwargs):
        ' class init '
        super(Main, self).initialize(*args, **kwargs)
        self.group0 = QGroupBox()
        self.group0.setTitle(' Options ')
        self.group0.setCheckable(True)
        self.group0.toggled.connect(lambda: self.group0.hide())
        self.spin1, self.spin2, self.spin3 = QSpinBox(), QSpinBox(), QSpinBox()
        self.spin4, self.spin5, self.spin6 = QSpinBox(), QSpinBox(), QSpinBox()
        self.spin7, self.spin8, self.spin9 = QSpinBox(), QSpinBox(), QSpinBox()
        self.spin10, self.output = QSpinBox(), QTextEdit()
        self.reset = QPushButton(QIcon.fromTheme("face-smile"), 'Reset Options')
        self.reset.clicked.connect(self.reset_options)
        self.reset_options()
        self.output.setReadOnly(True)
        vboxg3 = QVBoxLayout(self.group0)
        for each_widget in (QLabel('<b>Max Attributes Per Class:'), self.spin1,
            QLabel('<b>Max Methods Per Class:'), self.spin2,
            QLabel('<b>Max Functions Per File:'), self.spin3,
            QLabel('<b>Max Classes Per File:'), self.spin4,
            QLabel('<b>Max Parameters Per Function:'), self.spin5,
            QLabel('<b>Max Lines Per Function:'), self.spin6,
            QLabel('<b>Max ControlStatements Per Function:'), self.spin7,
            QLabel('<b>Max Lines Per File:'), self.spin8,
            QLabel('<b>Max Indentation Levels:'), self.spin9,
            QLabel('<b>Max Tabs:'), self.spin10, self.reset):
            vboxg3.addWidget(each_widget)

        self.group1, self.auto = QGroupBox(), QComboBox()
        self.group1.setTitle(' Automation ')
        self.group1.setCheckable(True)
        self.group1.setToolTip('<font color="red"><b>WARNING:Advanced Setting!')
        self.group1.toggled.connect(lambda: self.group1.hide())
        self.auto.addItems(['Never run automatically', 'Run when File Saved',
            'Run when File Executed', 'Run when Tab Changed',
            'Run when File Opened', 'Run before File Saved'])
        self.auto.currentIndexChanged.connect(self.on_auto_changed)
        QVBoxLayout(self.group1).addWidget(self.auto)

        self.button = QPushButton(' Analyze for Best Practice ')
        self.button.setMinimumSize(75, 50)
        self.button.clicked.connect(self.run)
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0)
        glow.setBlurRadius(99)
        glow.setColor(QColor(99, 255, 255))
        self.button.setGraphicsEffect(glow)

        class TransientWidget(QWidget):
            ' persistant widget thingy '
            def __init__(self, widget_list):
                ' init sub class '
                super(TransientWidget, self).__init__()
                vbox = QVBoxLayout(self)
                for each_widget in widget_list:
                    vbox.addWidget(each_widget)

        tw = TransientWidget((QLabel('<i>Best Practice analyzer'),
            self.group0, self.group1, QLabel('<b>Best Practice Errors:'),
            self.output, self.button))
        self.scrollable, self.dock = QScrollArea(), QDockWidget()
        self.scrollable.setWidgetResizable(True)
        self.scrollable.setWidget(tw)
        self.dock.setWindowTitle(__doc__)
        self.dock.setStyleSheet('QDockWidget::title{text-align: center;}')
        self.dock.setWidget(self.scrollable)
        ExplorerContainer().addTab(self.dock, "Check")
        QPushButton(QIcon.fromTheme("help-about"), 'About', self.dock
            ).clicked.connect(lambda:
            QMessageBox.information(self.dock, __doc__, HELPMSG))

    def run(self):
        ' run the actions '
        global MAXVAL
        self.output.clear()
        self.button.setDisabled(True)
        maxvalues = {'maxAttributesPerClass': int(self.spin1.value()),
            'maxFunctionsPerClass': int(self.spin2.value()),
            'maxFunctionsPerFile': int(self.spin3.value()),
            'maxClassesPerFile': int(self.spin4.value()),
            'maxParametersPerFunction': int(self.spin5.value()),
            'maxLinesPerFunction': int(self.spin6.value()),
            'maxControlStatementsPerFunction': int(self.spin7.value()),
            'maxLinesPerFile': int(self.spin8.value()),
            'maxIndentationLevel': int(self.spin9.value()),
            'maxTabs': int(self.spin10.value())}
        MAXVAL = maxvalues
        self.output.append(SimplePythonChecker().analyze(str(
            self.locator.get_service("editor").get_opened_documents()[
             self.locator.get_service("editor").get_tab_manager().currentIndex()
            ]), maxvalues))
        self.output.setFocus()
        self.button.setEnabled(True)

    def on_auto_changed(self):
        ' automation connects '
        if self.auto.currentIndex() is 1:
            self.locator.get_service('editor').fileSaved.connect(lambda:
                self.run())
            QMessageBox.information(self.dock, __doc__,
            '<b>Now Actions will Run Automatically when any File is Saved !')
        elif self.auto.currentIndex() is 2:
            self.locator.get_service('editor').fileExecuted.connect(lambda:
                self.run())
            QMessageBox.information(self.dock, __doc__,
            '<b>Now Actions will Run Automatically when any File is Executed !')
        elif self.auto.currentIndex() is 3:
            self.locator.get_service('editor').currentTabChanged.connect(lambda:
                self.run())
            QMessageBox.information(self.dock, __doc__,
            '<b>Now Actions will Run Automatically when current Tab is Changed')
        elif self.auto.currentIndex() is 4:
            self.locator.get_service('editor').fileOpened.connect(lambda:
                self.run())
            QMessageBox.information(self.dock, __doc__,
            '<b>Now Actions will Run Automatically when any File is Opened !')
        elif self.auto.currentIndex() is 5:
            self.locator.get_service('editor').beforeFileSaved.connect(lambda:
                self.run())
            QMessageBox.information(self.dock, __doc__,
            '<b>Now Actions will Run Automatically before any File is Saved !')
        self.group1.setDisabled(True)

    def reset_options(self):
        ' reset the options '
        self.spin1.setRange(1, 99)
        self.spin2.setRange(1, 99)
        self.spin3.setRange(1, 99)
        self.spin4.setRange(1, 99)
        self.spin5.setRange(1, 9)
        self.spin6.setRange(1, 999)
        self.spin7.setRange(1, 99)
        self.spin8.setRange(1, 9999)
        self.spin9.setRange(1, 9)
        self.spin10.setRange(1, 9)
        self.spin1.setValue(20)
        self.spin2.setValue(20)
        self.spin3.setValue(20)
        self.spin4.setValue(5)
        self.spin5.setValue(5)
        self.spin6.setValue(100)
        self.spin7.setValue(20)
        self.spin8.setValue(999)
        self.spin9.setValue(5)
        self.spin10.setValue(5)


###############################################################################


class GreenYellowRedLimit(object):
    """ this class handles three ranges: green, yellow and red.  """
    def __init__(self, _limit, message):
        """ stores limit information """
        self._limit, self.message = _limit, message

    def isGreenFor(self, value):
        """ Checking for a value to be in a valid range. """
        return value <= self._limit

    def isRedFor(self, value):
        """ Checking for a value to be in an invalid range. """
        return value > self._limit

    def getMessage(self, pathAndFileName, lineNr, value):
        """ generates printable warning/error message """
        return "<li>Line <b>{}</b>: Error: {} ({} > {}).".format(
               lineNr, self.message, value, self._limit)


class Limits(object):
    """ Does group all limits to be checked by this scripts """
    def __init__(self, maxvalues):
        """ initializes container for limit defintions only """
        self.definitions, self.maxval = {}, maxvalues

    def registerLimit(self, name, limit):
        """ registration of a limit """
        if not name in self.definitions:
            self.definitions[name] = limit
        return limit

    def maxAttributesPerClass(self):
        """ Too many attributes per class """
        return self.registerLimit(self.maxAttributesPerClass.__name__,
            GreenYellowRedLimit(self.maxval['maxAttributesPerClass'],
                                "Too many attributes in class"))

    def maxFunctionsPerClass(self):
        """ Too many functions per class """
        return self.registerLimit(self.maxFunctionsPerClass.__name__,
            GreenYellowRedLimit(self.maxval['maxFunctionsPerClass'],
                                "Too many functions in class"))

    def maxFunctionsPerFile(self):
        """ Too many functions per file """
        return self.registerLimit(self.maxFunctionsPerFile.__name__,
            GreenYellowRedLimit(self.maxval['maxFunctionsPerFile'],
                                "Too many functions in file"))

    def maxClassesPerFile(self):
        """ Too many classes per file """
        return self.registerLimit(self.maxClassesPerFile.__name__,
            GreenYellowRedLimit(self.maxval['maxClassesPerFile'],
                                "Too many classes in file"))

    def maxParametersPerFunction(self):
        """ Too many parameters in function/method """
        return self.registerLimit(self.maxParametersPerFunction.__name__,
            GreenYellowRedLimit(self.maxval['maxParametersPerFunction'],
                                "Too many arguments in method"))

    def maxLinesPerFunction(self):
        """ Too many lines per function/method """
        return self.registerLimit(self.maxLinesPerFunction.__name__,
            GreenYellowRedLimit(self.maxval['maxLinesPerFunction'],
                                "Too many lines in block"))

    def maxControlStatementsPerFunction(self):
        """ Too many control statements """
        return self.registerLimit(self.maxControlStatementsPerFunction.__name__,
            GreenYellowRedLimit(self.maxval['maxControlStatementsPerFunction'],
                                "Too many control statements"))

    def maxLinesPerFile(self):
        """ Too many lines in file """
        return self.registerLimit(self.maxLinesPerFile.__name__,
            GreenYellowRedLimit(self.maxval['maxLinesPerFile'],
                                "Too many lines in file"))

    def maxIndentationLevel(self):
        """ Too many indentation levels """
        return self.registerLimit(self.maxIndentationLevel.__name__,
            GreenYellowRedLimit(self.maxval['maxIndentationLevel'],
                                "Too many indentation levels"))

    def maxTabs(self):
        """ Too many tabs """
        return self.registerLimit(self.maxTabs.__name__,
            GreenYellowRedLimit(0, "Too many tabs"))


class FileData(object):
    """ represent all information for one file from one analyse """
    def __init__(self, pathAndFileName):
        """ initializes members for one file analyse """
        self.pathAndFileName, self.messages = pathAndFileName, []
        self.classes, self.attributes, self.functions = {}, {}, {}
        self.errors, self.totalLines, self.totalBlankLines = 0, 0, 0


class SimplePythonChecker(ast.NodeVisitor):
    """ traverse code checking Comments, length of lines, indentation depth """
    def __init__(self):
        """ initializing to have some empty containers and the limits """
        self.limits, self.current, self.files = Limits(MAXVAL), {LEVEL: 0}, {}

    def analyze(self, pathAndFileName, maxvalues):
        """ main method for analyzing one python file path and filename """
        newFileData, self.limits = FileData(pathAndFileName), Limits(maxvalues)
        self.files[pathAndFileName] = newFileData
        self.current[FILE] = newFileData
        with open(pathAndFileName) as f:
            code = f.read()
        tree = ast.parse(code)
        self.visit(tree)
        self.analyzeCode(code)
        self.checkLimits()
        return self.finalize()

    def analyzeCode(self, code):
        """ line based analyse. the content of the whole file (usually) """
        currentFile, lineNr = self.current[FILE], 1
        for line in code.split('\n'):
            limitToCheck, value = self.limits.maxTabs(), line.count("\t")
            self.checkLimit(lineNr, limitToCheck, value)
            if len(line.strip()) == 0:
                currentFile.totalBlankLines += 1
                functions = [function
                            for function in list(currentFile.functions.values())
                            if function["lineNr"] < lineNr and
                            function["lineNr"] + function["lines"] > lineNr]
                if len(functions) == 1:
                    functions[0]["blankLines"] += 1
            lineNr += 1

        limitToCheck, lineNr = self.limits.maxLinesPerFile(), 1
        value = code.count("\n") + 1
        self.checkLimit(lineNr, limitToCheck, value -
                        currentFile.totalBlankLines)
        currentFile.totalLines = value

    def visit_ClassDef(self, node):
        """ stores class. walking AST tree a class definition has been found """
        currentFile, newClass = self.current[FILE], {}
        newClass["lineNr"], newClass["attributes"] = node.lineno, set()
        newClass["functions"] = set()
        currentFile.classes[node.name] = newClass
        self.current[CLASS] = node.name
        self.generic_visit(node)

    def visit_Attribute(self, node):
        """ stores attributes and counts them class wise walking AST tree """
        currentFile = self.current[FILE]
        if FUNCTION in self.current and self.current[FUNCTION] == "__init__":
            newAttribute = {}
            newAttribute["lineNr"] = node.lineno
            if CLASS in self.current and self.current[CLASS]:
                newAttribute["class"] = self.current[CLASS]
                currentFile.classes[self.current[CLASS]]["attributes"].add(
                    node.attr)
            currentFile.attributes[node.attr] = newAttribute
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        """ stores function and register it at class if it's a method. """
        currentFile, newFunction = self.current[FILE], {}
        newFunction["lineNr"], newFunction["cstms"] = node.lineno, 0
        newFunction["blankLines"] = 0
        try:
            newFunction["argumentNames"] = [arg.arg for arg in node.args.args]
        except:
            newFunction["argumentNames"] = [arg.id for arg in node.args.args]
        if CLASS in self.current and self.current[CLASS]:
            currentClass = currentFile.classes[self.current[CLASS]]
            if node.lineno <= currentClass["lineNr"]:
                self.current[CLASS] = None
            else:
                newFunction["class"] = self.current[CLASS]
                currentClass["functions"].add(node.name)
        currentFile.functions[node.name] = newFunction
        self.current[FUNCTION] = node.name
        self.generic_visit(node)
        newFunction["lines"] = self.current[LINENR] - node.lineno
        self.current[FUNCTION] = None

    def visit_If(self, node):
        """ required to check for indentation level and complexity """
        currentFile = self.current[FILE]
        self.current[LEVEL] += 1
        limitToCheck = self.limits.maxIndentationLevel()
        lineNr, value = node.lineno, self.current[LEVEL]
        self.checkLimit(lineNr, limitToCheck, value)
        if self.current[FUNCTION] in currentFile.functions:
            currentFunction = currentFile.functions[self.current[FUNCTION]]
            currentFunction["cstms"] += 1
        self.generic_visit(node)
        self.current[LEVEL] -= 1

    def visit_For(self, node):
        """ required to check for indentation level and complexity """
        currentFile = self.current[FILE]
        self.current[LEVEL] += 1
        limitToCheck = self.limits.maxIndentationLevel()
        lineNr, value = node.lineno, self.current[LEVEL]
        self.checkLimit(lineNr, limitToCheck, value)
        if self.current[FUNCTION] in currentFile.functions:
            currentFunction = currentFile.functions[self.current[FUNCTION]]
            currentFunction["cstms"] += 1
        self.generic_visit(node)
        self.current[LEVEL] -= 1

    def visit_While(self, node):
        """ required to check for indentation level and complexity """
        currentFile = self.current[FILE]
        self.current[LEVEL] += 1

        limitToCheck = self.limits.maxIndentationLevel()
        lineNr, value = node.lineno, self.current[LEVEL]
        self.checkLimit(lineNr, limitToCheck, value)
        if self.current[FUNCTION] in currentFile.functions:
            currentFunction = currentFile.functions[self.current[FUNCTION]]
            currentFunction["cstms"] += 1
        self.generic_visit(node)
        self.current[LEVEL] -= 1

    def visit_Return(self, node):
        """ required to check for complexity """
        currentFile = self.current[FILE]
        if self.current[FUNCTION] in currentFile.functions:
            currentFunction = currentFile.functions[self.current[FUNCTION]]
            currentFunction["cstms"] += 1
        self.generic_visit(node)

    def checkLimits(self):
        """ checking different limits """
        currentFile = self.current[FILE]
        for className in currentFile.classes:
            limitToCheck = self.limits.maxAttributesPerClass()
            value = len(currentFile.classes[className]["attributes"])
            lineNr = currentFile.classes[className]["lineNr"]
            self.checkLimit(lineNr, limitToCheck, value)
            limitToCheck = self.limits.maxFunctionsPerClass()
            value = len(currentFile.classes[className]["functions"])
            self.checkLimit(lineNr, limitToCheck, value)
        for functionName in currentFile.functions:
            limitToCheck = self.limits.maxParametersPerFunction()
            lineNr = currentFile.functions[functionName]["lineNr"]
            value = len(currentFile.functions[functionName]["argumentNames"])
            if "self" in currentFile.functions[functionName]["argumentNames"]:
                value -= 1
            self.checkLimit(lineNr, limitToCheck, value)
            limitToCheck = self.limits.maxLinesPerFunction()
            value = currentFile.functions[functionName]["lines"]
            value -= currentFile.functions[functionName]["blankLines"]
            self.checkLimit(lineNr, limitToCheck, value)
            limitToCheck = self.limits.maxControlStatementsPerFunction()
            value = currentFile.functions[functionName]["cstms"]
            self.checkLimit(lineNr, limitToCheck, value)
        limitToCheck = self.limits.maxFunctionsPerFile()
        value, lineNr = len(currentFile.functions), 1
        self.checkLimit(lineNr, limitToCheck, value)
        limitToCheck = self.limits.maxClassesPerFile()
        value = len(currentFile.classes)
        self.checkLimit(lineNr, limitToCheck, value)

    def checkLimit(self, lineNr, limitToCheck, value):
        """ check single limit and print message if given value is not valid """
        currentFile = self.current[FILE]
        if not limitToCheck.isGreenFor(value):
            message = limitToCheck.getMessage(currentFile.pathAndFileName,
                                              lineNr, value)
            currentFile.messages.append((lineNr, message))
            if limitToCheck.isRedFor(value):
                currentFile.errors += 1

    def generic_visit(self, node):
        """ calculate how many line are in a block (function/method/class) """
        try:
            self.current[LINENR] = node.lineno
        except:
            pass
        ast.NodeVisitor.generic_visit(self, node)

    def finalize(self):
        """ printing some final information from last analyse """
        currentFile, results = self.current[FILE], '<html><ol>'
        for message in sorted(currentFile.messages):
            results += message[1]
        functions = [name for name in currentFile.functions
            if len(currentFile.functions[name]["argumentNames"]) == 0
            or not currentFile.functions[name]["argumentNames"][0] == 'self']
        results += "</ol><hr><b>Lines Processed:</b> {}<br>".format(
                                                        currentFile.totalLines)
        results += "<b>Blank Lines:</b> {}<br>".format(
                                                    currentFile.totalBlankLines)
        results += "<b>Functions:</b> {}<br>".format(len(functions))
        results += "<b>Methods:</b> {}<br>".format(len(currentFile.functions) -
                                          len(functions))
        results += "<b>Errors:</b> {}<br>".format(
                                                        currentFile.errors)
        results += "<b>File:</b> {}<br>".format(currentFile.pathAndFileName)
        results += "<b>Last:</b> {}".format(
                                       datetime.now().isoformat().split('.')[0])
        return results


###############################################################################


if __name__ == "__main__":
    print(__doc__)
