# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja CSV to JSON "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 05/09/2013 '
__prj__ = ' csv2json '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path
from json import dumps
from csv import reader

from PyQt4.QtGui import QFileDialog, QIcon, QAction, QInputDialog

from ninja_ide.core import plugin


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.locator.get_service("menuApp").add_action(QAction(QIcon.fromTheme("edit-select-all"), "CSV to JSON", self, triggered=lambda: self.locator.get_service("editor").add_editor(content=dumps(list(reader(open(path.abspath(QFileDialog.getOpenFileName(None, "{} - Open a CSV File".format(__doc__), path.expanduser("~"), 'CSV(*.csv)'))))), indent=int(QInputDialog.getInteger(None, __doc__, "JSON Indentation Spaces:", 4, 0, 8, 2)[0]), sort_keys=True), syntax='python')))


###############################################################################


if __name__ == "__main__":
    print(__doc__)
