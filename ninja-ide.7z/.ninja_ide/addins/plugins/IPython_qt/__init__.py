from IPython_qt import my_IPython_qt
