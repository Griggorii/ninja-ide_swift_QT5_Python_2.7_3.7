#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# THE WISKEY-WARE LICENSE
# -----------------------
#
# "THE WISKEY-WARE LICENSE":
# <jbc.develop@gmail.com> wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC
#

# ==============================================================================
# DOC
# ==============================================================================

"""A Simple Client for http://codepad.com

"""




# ==============================================================================
# IMPORTS
# ==============================================================================

import urllib
import urllib2
import urlparse


# ==============================================================================
# CONSTANTS
# ==============================================================================

URL = "http://codepad.org/"


FORMAT_2_EXT = {
    "Python": ["py", "pyw"],
    "Tcl": ["tcl"],
    "Haskell": ["hs"],
    "PHP": ["php"],
    "Ruby": ["rb"],
    "C": ["c"],
    "Plain Text": ["txt"],
    "D": ["d"],
    "OCaml": ["ocaml"],
    "Perl": ["pl"],
    "Lua": ["lua"],
    "C++": ["cpp"],
    "Scheme": ["ss"]
}


PLAIN_FORMAT = "Plain Text"


# ==============================================================================
# FUNCTIONS
# ==============================================================================

def paste(source, file_format=PLAIN_FORMAT, title="", poster=""):
    """Paste a given source code into codepad with a given format

    """
    data = urllib.urlencode({
            'code':source,
            'lang':file_format,
            'submit':'Submit'
    })
    conn = urllib2.urlopen(URL, data)
    return conn.geturl()


def copy(dpaste_id):
    """Retrieve a code from a given id

    """
    return urllib2.urlopen(URL + str(dpaste_id) + "/raw.txt").read()


def url_copy(url):
    """Copy content of a giver url as text
    
    """
    pid = urlparse.urlparse(url).path[1:]
    if pid.endswith("/"):
        pid = pid[:-1]
    return copy(pid)


# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    print(__doc__)
