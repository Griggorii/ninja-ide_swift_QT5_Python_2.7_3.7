#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# THE WISKEY-WARE LICENSE
# -----------------------
#
# "THE WISKEY-WARE LICENSE":
# <jbc.develop@gmail.com> wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC
#

# ==============================================================================
# DOC
# ==============================================================================

"""A Simple Client for http://dpaste.com/

"""

# ==============================================================================
#
# ==============================================================================

__author__ = "JuanBC"
__mail__ = "jbc.develop@gmail.com"
__version__ = "0.1.1"
__license__ = "WISKEY_WARE"
__date__ = "2011/11/14"


# ==============================================================================
# IMPORTS
# ==============================================================================

import urllib
import urllib2
import urlparse


# ==============================================================================
# CONSTANTS
# ==============================================================================

URL = "http://dpaste.com/"



FORMAT_2_EXT = {
    "Python": ["py", "pyw"],
    "PythonConsole": [],
    "Sql": ["sql"],
    "DjangoTemplate": [],
    "JScript": ["js"],
    "Css": ["css"],
    "Xml": ["xml"],
    "Diff": ["diff"],
    "Ruby": ["rb"],
    "Rhtml": ["rhtml"],
    "Haskell": ["hs"],
    "Apache": [],
    "Bash": ["sh"],
    "": ["txt"]
}

PLAIN_FORMAT = ""

# ==============================================================================
# FUNCTIONS
# ==============================================================================

def paste(source, file_format=PLAIN_FORMAT, title="", poster=""):
    """Paste a given source code into dpaste.com with a given format

    """
    data = urllib.urlencode({"content": source,
                             "language": file_format,
                             "title": title,
                             "poster": poster})
    conn = urllib2.urlopen(URL, data)
    return conn.geturl()


def copy(dpaste_id):
    """Retrieve a code from a given dpaste id

    """
    return urllib2.urlopen(URL + str(dpaste_id) + "/plain").read()


def url_copy(url):
    """Copy content of a given url as text
    
    """
    pid = urlparse.urlparse(url).path[1:]
    if pid.endswith("/"):
        pid = pid[:-1]
    return copy(pid)


# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    print(__doc__)
