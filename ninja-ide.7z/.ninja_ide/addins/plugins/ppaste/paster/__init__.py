#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# THE WISKEY-WARE LICENSE
# -----------------------
#
# "THE WISKEY-WARE LICENSE":
# <juan@brainiac> wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return juan
#

# ==============================================================================
# DOC
# ==============================================================================

'''Wrapper over various public paste code services

'''

# ==============================================================================
# IMPORTS
# ==============================================================================

import os
import urllib2
import urlparse
import HTMLParser

import BeautifulSoup

import dpaste
import pasteubuntu
import codepad
import pastee


# ==============================================================================
# CONSTANTS
# ==============================================================================

OK_PARSED = "ok"
WARN_PARSED = "warn"

HTML_PARSER = HTMLParser.HTMLParser()

PASTERS = {
    "paste.ubuntu": pasteubuntu,
    "dPaste": dpaste,
    "codepad": codepad,
    "pastee": pastee,
}

_EXT_2_FORMAT = {}


# ==============================================================================
# FUNCTIONS
# ==============================================================================

def get_url(paster_name):
    '''Retrieve a url of a service

    '''
    return PASTERS[paster_name].URL


def formats_2_ext(paster_name):
    '''Retrieves a dictiorany with keys = suported format of a paste and
    value = the extensions of this formats.

    '''
    return PASTERS[paster_name].FORMAT_2_EXT


def ext_2_format(paster_name):
    '''Retrieves a dictiorany with keys =  file extension
    value = format of this extension

    '''
    if paster_name not in _EXT_2_FORMAT:
        ext_2_format = {}
        for k, vs in formats_2_ext(paster_name).items():
            for v in vs:
                ext_2_format[v] = k
        _EXT_2_FORMAT[paster_name] = ext_2_format
    return _EXT_2_FORMAT[paster_name]


def filename2format(paster_name, filename):
    """Retrieves the format of a given filename
    for a given paster_name

    """
    basename = os.path.basename(filename)
    plain = PASTERS[paster_name].PLAIN_FORMAT
    if "." in basename:
        ext = basename.rsplit(".", 1)[1].lower()
        return ext_2_format(paster_name).get(ext, plain)
    return plain


def paste(paster_name, source, file_format="", title="", poster=""):
    '''Paste a code into service

    '''
    return PASTERS[paster_name].paste(source=source,
                                 file_format=file_format,
                                 title=title, poster=poster)


def copy(url):
    """Copy content of a given url as text if the service is not supported
    return the html instead

    """
    for paster in PASTERS.values():
        try:
            paster_netloc = urlparse.urlparse(paster.URL).netloc
            url_netloc = urlparse.urlparse(url).netloc
            if  paster_netloc  and url_netloc and paster_netloc == url_netloc:
                return paster.url_copy(url), OK_PARSED
        except:
            pass
    html = urllib2.urlopen(url).read()
    soup = BeautifulSoup.BeautifulSoup(html)
    txt = HTML_PARSER.unescape(u'\n'.join(soup.findAll(text=True))).strip()
    return txt, WARN_PARSED


def get_msg(paster_name):
    """Retrieves a MSG variable from paster
    """
    return getattr(PASTERS[paster_name], "MSG", "")


# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    print(__doc__)
