#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# THE WISKEY-WARE LICENSE
# -----------------------
#
# "THE WISKEY-WARE LICENSE":
# <jbc.develop@gmail.com> wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC
#

# ==============================================================================
# DOC
# ==============================================================================

"""A Simple Client for http://paste.ubuntu.com/

"""

# ==============================================================================
#
# ==============================================================================

__author__ = "JuanBC"
__mail__ = "jbc.develop@gmail.com"
__version__ = "0.1.1"
__license__ = "WISKEY_WARE"
__date__ = "2011/11/14"


# ==============================================================================
# IMPORTS
# ==============================================================================

import urllib
import urllib2
import HTMLParser
import urlparse

import BeautifulSoup


# ==============================================================================
# CONSTANTS
# ==============================================================================

URL = "http://paste.ubuntu.com/"

FORMAT_2_EXT = {
    "text": ["txt"],
    "apacheconf": [],
    "as": ["as"],
    "bash": ["sh"],
    "bat": ["bat"],
    "bbcode": [],
    "befunge": [],
    "boo": ["boo"],
    "c": ["c", "h"],
    "c-objdump": [],
    "common-lisp": ["lisp"],
    "control": [],
    "cpp": ["cpp", "h"],
    "cpp-objdump": [],
    "csharp": ["cs"],
    "css": [".css"],
    "d": ["d"],
    "d-objdump": [],
    "delphi": ["pas"],
    "diff": ["diff"],
    "dylan": [],
    "erb": ["erb"],
    "erlang": ["erl"],
    "gas": [],
    "genshi": [],
    "genshitext": [],
    "groff": [],
    "haskell": ["hs"],
    "html": ["html"],
    "ini": ["ini"],
    "irc": ["irc"],
    "java": ["java"],
    "js": ["js"],
    "jsp": ["jsp"],
    "lhs": ["lhs"],
    "llvm": [],
    "lua": ["lua"],
    "make": ["make"],
    "mako": [],
    "minid": [],
    "moocode": [],
    "mupad": [],
    "myghty": [],
    "mysql": ["mysql"],
    "objdump": [],
    "objective-c": [],
    "ocaml": ["ml"],
    "perl": ["pl"],
    "php": ["php"],
    "pot": ["pot"],
    "pycon": [],
    "pytb": [],
    "python": ["py", "pyw"],
    "raw": [],
    "rb": ["rb"],
    "rbcon": [],
    "redcode": [],
    "rhtml": ["rhtml"],
    "rst": ["rst"],
    "scheme": ["ss"],
    "smarty": [],
    "sourceslist": [],
    "sql": ["sql"],
    "squidconf": [],
    "tex": ["tex"],
    "text": ["txt"],
    "trac-wiki": [],
    "vb.net": ["vb"],
    "vim": ["vim"],
    "xml": ["xml"],
    
    # EXTRAS
    "xml+django": [],
    "xml+erb": [],
    "xml+mako": [],
    "xml+myghty": [],
    "xml+php": [],
    "xml+smarty": [],
    "js+django": [],
    "js+erb": [],
    "js+genshitext": [],
    "js+mako": [],
    "js+myghty": [],
    "js+php": [],
    "js+smarty": [],
    "html+django": [],
    "html+genshi": [],
    "html+mako": [],
    "html+myghty": [],
    "html+php": [],
    "html+smarty": []
    
}


PLAIN_FORMAT = "text"

HTML_PARSER= HTMLParser.HTMLParser()

# ==============================================================================
# FUNCTIONS
# ==============================================================================


def paste(source, file_format=PLAIN_FORMAT, title="", poster=""):
    """Paste a given source code into with a given format

    """
    data = urllib.urlencode({"content": source,
                             "syntax": file_format,
                             "poster": poster})
    conn = urllib2.urlopen(URL, data)
    return conn.geturl()


def copy(paste_id):
    """Retrieve a code from a given paste id

    """
    html = urllib2.urlopen(URL + str(paste_id)).read()
    soup = BeautifulSoup.BeautifulSoup(html)
    texts = soup.find("td", {"class": "code"})
    return HTML_PARSER.unescape(u''.join(texts.findAll(text=True))).strip()


def url_copy(url):
    """Copy content of a giver url as text
    
    """
    pid = urlparse.urlparse(url).path[1:]
    if pid.endswith("/"):
        pid = pid[:-1]
    return copy(pid)


# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    print(__doc__)
