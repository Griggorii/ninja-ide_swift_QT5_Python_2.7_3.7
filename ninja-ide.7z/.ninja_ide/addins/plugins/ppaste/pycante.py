#!/usr/bin/env python
# -*- coding: utf-8 -*-

# THE WISKEY-WARE LICENSE
# -----------------------

# "THE WISKEY-WARE LICENSE":
# <jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC


#===============================================================================
# DOC
#===============================================================================

"""The hotest way to deal with PyQt

Allows a unique way to deal with Qt Widgets QtDesigner or files. If the instance 
has a setupUI method is executed at the time of creation.

example:

    from PyQt4 import QtGui
    import pycante

    class MyWidget(pycante.E("/path/to/file.ui"), AnotherClass);
        pass
    
    class MyAnotherWidget(pycante.E(QtGui.QFrame), , AnotherClass):
        pass
        
    w0 = MyWidget()
    w1 = MyAnotherWidget()


"""

#===============================================================================
# META
#===============================================================================

__version__ = "0.2.1c"
__license__ = "BEER License"
__author__ = "JBC"
__email__ = "jbc dot develop at gmail dot com"
__url__ = "https://bitbucket.org/leliel12/pycante"
__date__ = "2011-08-24"


#===============================================================================
# IMPORTS
#===============================================================================

import os, sys, inspect

from PyQt4 import QtGui
from PyQt4 import uic


#===============================================================================
# AutoSetupClass
#===============================================================================

class AutoSetup(object):
    """This class is used for auto execute 'setupUi' method if exist in a
    widget
    
    """
    
    def __init__(self, *args, **kwargs):
        super(AutoSetup, self).__init__(*args, **kwargs)
        if hasattr(self, "setupUi") and callable(self.setupUi):
            self.setupUi(self)


#===============================================================================
# DECORATOR
#===============================================================================

def E(ui_or_widget):
    """Resolve a qt widget class from ui file path or Widget class
    
    @param ui_or_widget for inerith visual stile (can be a designer ui file)
    @return New base class 
    
    Example:
    
        class MyWidget(E("my/ui/file.ui")):
            pass
            
        class AnotherWidget(E(QtGui.QFrame)):
            pass
    
    """
    ui_path = None
    bases = None
    
    if inspect.isclass(ui_or_widget) and issubclass(ui_or_widget, QtGui.QWidget):
        bases = [ui_or_widget]
    else:
        ui_path = ui_or_widget
        bases = list(uic.loadUiType(ui_path))
    
    name = bases[0].__name__
    bases = tuple([AutoSetup] + bases)
    cls_locals = {"__ui_file__": ui_path}
    return type(name, bases, cls_locals)


def EDir(path):
    """Creates a binding for resolve in 'path' directory a qt widget class 
    from ui file path or Widget class ignoring it.
    
    """
    assert isinstance(path, basestring)
    
    def ED(ui_or_widget):
        if isinstance(ui_or_widget, basestring):
            return E(os.path.join(path, ui_or_widget))
        return E(ui_or_widget)
        
    return ED


#==============================================================================
# MAIN
#===============================================================================

if __name__ == "__main__":
    print(__doc__)
