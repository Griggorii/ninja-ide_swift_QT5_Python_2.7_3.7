#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# THE WISKEY-WARE LICENSE
# -----------------------
#
# "THE WISKEY-WARE LICENSE":
# <jbc.develop@gmail.com> wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC
#

# ==============================================================================
# DOCS
# ==============================================================================

"""Send your code to public paste

Usage:
    Push the button in the toolbar and send the content of the actual editor
    to public paste

"""

# ==============================================================================
# META
# ==============================================================================

__prj__ = 'Ninja Public Paste'
__version__ = '0.5'
__license__ = "THE WISKEY-WARE LICENSE"
__author__ = 'JuanBC'
__email__ = 'jbc.develop@gmail.com'
__url__ = 'https://bitbucket.org/leliel12/ninja-ide_plugins'
__date__ = '2011/11/13'

__full_license__ = """
"THE WISKEY-WARE LICENSE":
<jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
can do whatever you want with this stuff. If we meet some day, and you think
this stuff is worth it, you can buy me a wiskey in return JuanBC"""


# ==============================================================================
# IMPORTS
# ==============================================================================

import string
import os
import json
import datetime
import webbrowser

from PyQt4.QtGui import QWidget
from PyQt4.QtGui import QIcon
from PyQt4.QtGui import QAction
from PyQt4.QtGui import QMessageBox
from PyQt4.QtGui import QTextBrowser
from PyQt4.QtGui import QInputDialog
from PyQt4.QtCore import pyqtSignal


from ninja_ide.core import plugin
from ninja_ide.gui.editor import editor
from ninja_ide import resources

import paster
import res
import pycante


# ==============================================================================
# CONSTANTS
# ==============================================================================

PPASTE_FILE_PATH = os.path.join(resources.HOME_NINJA_PATH, "ppaste.json")

# $body
HTML_TEMPLATE = string.Template("""
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html><head><meta name="qrichtext" content="1" /><style type="text/css">
p, li { white-space: pre-wrap; }
</style></head><body style=" font-family:'Ubuntu'; font-size:10pt; font-weight:400; font-style:normal;">$body</body></html>
""".strip())

# $idx $url $name $time $icn
HISTORY_ENTRY_TEMPLATE = string.Template("""
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">
  <b>$idx.</b>
  $name
  <b>-</b>
  $date $time
  <b>:</b>
  <a href="openhere://$url"><img src="$icon" alt="Open Here" height="16" width="16"></a>
  <a href="$url"><span style=" text-decoration: underline; color:#0000ff;">$url</span></a>
</p>
""".strip())

# $url $service_msg
URL_TEMPLATE = string.Template("""
<p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">Your code url: <a href="${url}"><span style=" text-decoration: underline; color:#0000ff;">${url}</span></a></p>
<p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">${service_msg}</p>
""".strip())

# $title $doc $author $version $url $license
ABOUT_TEMPLATE = string.Template("""
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">$title</span></p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">$doc</p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">Author: </span>$author</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">Version: </span>$version</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">Homepage: </span><a href="$url"><span style=" text-decoration: underline; color:#0000ff;">$url</span></a></p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">License:</span></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">$license</p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"></p>
""".strip())

tr = lambda x:{
    "bmEKbmEKbmEKbmEKbmE=".decode("base64") :
    "QkFUTUFOICEhIQ==".decode("base64") + "\n"
}.get(x, "")


UI = pycante.EDir(res.PATH)


# ==============================================================================
# ABOUT CLASSES
# ==============================================================================

class AboutFrame(UI("AboutFrame.ui")):

    # emit this signal on save method
    saved = pyqtSignal(basestring, name="saved")

    def __init__(self, parent, selected_service):
        super(self.__class__, self).__init__(parent)

        richtext = lambda code: "<br/>".join(
            code.replace("<", "&lt;").replace(">", "&gt;").splitlines()
        )

        about_msg = HTML_TEMPLATE.substitute(
                        body=ABOUT_TEMPLATE.substitute(
                            title=richtext(__prj__),
                            doc=richtext(__doc__),
                            author=richtext(__author__),
                            version=richtext(__version__),
                            url=richtext(__url__),
                            license=richtext(__full_license__)
                        )
                    )
        self.aboutLabel.setText(about_msg)
        for k, v in paster.PASTERS.items():
            icon = QIcon(res.get(k + ".png"))
            self.serviceComboBox.addItem(icon, v.URL, k)

        selected_idx = self.serviceComboBox.findData(selected_service)
        self.serviceComboBox.setCurrentIndex(selected_idx)

    def save(self):
        """Called from ninja ide when save button is called

        """
        idx = self.serviceComboBox.currentIndex()
        service = unicode(self.serviceComboBox.itemData(idx))
        self.saved.emit(service)


# ==============================================================================
# MAIN PLUGIN CLASS
# ==============================================================================

class NinjaPublicPaste(QWidget, plugin.Plugin):

    def _set_history(self):
        """Set the history misc text browser area

        """
        body = []
        icon = res.get("download.png")
        for idx, hentry in enumerate(self.history):
            body.append(
                HISTORY_ENTRY_TEMPLATE.substitute(idx=idx + 1,
                                                  icon=icon,
                                                  **hentry)
            )
        history_msg = HTML_TEMPLATE.substitute(body="".join(body))
        self.historyTextBrowser.setText(history_msg)

    def on_historyTextBrowser_anchorClicked(self, anchor):
        url = anchor.toString()
        if "openhere://" in url:
            url = url.replace("openhere://http//", "http://")
            self.open_remote(url)
        else:
            webbrowser.open(url)

    def send_all_slot(self):
        """This slot is called when a user hit the action for send all
        content of actual editor to public paste

        """
        tab = self.editor_s.get_actual_tab()
        text = self.editor_s.get_text().encode("utf-8")
        if not tab or not isinstance(tab, editor.Editor) or not text:
            title = self.tr("To Public Paste")
            msg = self.tr("Nothing to send")
            QMessageBox.critical(self, title, msg)

        else:
            cursor = tab.textCursor()
            send_type = "content"
            if cursor.hasSelection():
                text = unicode(cursor.selectedText()).encode("utf-8")
                send_type = "SELECTION"
            filename = (os.path.basename(self.editor_s.get_editor_path())
                        or "editor")
            title = self.tr("To Public Paste")
            msg = tr(text) + self.tr("Send {} {} to {}?").format(filename,
                                                                  send_type,
                                                                  self.service)
            status = QMessageBox.question(self, title, msg,
                                          QMessageBox.Ok, QMessageBox.Cancel)
            if status == QMessageBox.Ok:
                try:
                    fileformat = paster.filename2format(self.service, filename)
                    now = datetime.datetime.now()
                    paste_title = "{0} {1}".format(filename, send_type)
                    url = paster.paste(self.service, text, fileformat,
                                       paste_title, "Ninja-IDE")
                    self.history.insert(0, {"url": url,
                                            "date": now.strftime("%Y/%m/%d"),
                                            "time": now.strftime("%H:%M:%S"),
                                            "name": paste_title,})
                    while len(self.history) > 20: self.history.pop()
                    with open(PPASTE_FILE_PATH, "w") as fp:
                        json.dump({"service": self.service,
                                   "history": self.history},
                                  fp, indent=2)
                except Exception as err:
                    title = self.tr("Error Public Paste")
                    QMessageBox.critical(self, title, str(err))

                else:
                    self._set_history()
                    service_msg = self.tr(paster.get_msg(self.service))
                    title = self.tr("Sucess!")
                    msg = HTML_TEMPLATE.substitute(
                        body=URL_TEMPLATE.substitute(url=url,
                                                     service_msg=service_msg))
                    # HACK!
                    self.historyTextBrowser.setOpenExternalLinks(True)
                    QMessageBox.information(self, title, msg)
                    self.historyTextBrowser.setOpenExternalLinks(False)

    def retrieve_slot(self):
        title = self.tr("Download")
        msg = self.tr("Code url")
        url, ok = QInputDialog.getText(self, title, msg)
        if ok:
            self.open_remote(url)

    def save_snippets_slot(self, service):
        self.service = service
        with open(PPASTE_FILE_PATH, "w") as fp:
            json.dump({"service": self.service,
                       "history": self.history},
                      fp, indent=2)

    def open_remote(self, url):
        try:
            code, status = paster.copy(unicode(url))
            if status != paster.OK_PARSED:
                title = self.tr("Continue")
                msg = self.tr("The code is not correctly parsed. Show it anyway?")
                status = QMessageBox.question(self, title, msg)
                if status != QMessageBox.Ok:
                    return
            self.editor_s.add_editor(content=code)
        except Exception as err:
            title = self.tr("Error")
            QMessageBox.critical(self, title, str(err))

    def initialize(self):
        # Init your plugin
        if not os.path.exists(PPASTE_FILE_PATH):
            with open(PPASTE_FILE_PATH, "w") as fp:
                json.dump({"service": paster.PASTERS.keys()[0],
                           "history": []}, fp)

        with open(PPASTE_FILE_PATH) as fp:
            data = json.load(fp)
            self.history = data["history"]
            self.service = data["service"]

        self.editor_s = self.locator.get_service('editor')
        self.misc_s = self.locator.get_service('misc')
        self.toolbar_s = self.locator.get_service('toolbar')


        self.historyTextBrowser = QTextBrowser(self)
        self.historyTextBrowser.setOpenLinks(False)
        self.historyTextBrowser.anchorClicked.connect(self.on_historyTextBrowser_anchorClicked)
        self._set_history()
        self.misc_s.add_widget(self.historyTextBrowser,
                               res.get("history.png"),
                               self.tr("Paste History"))

        self.actionSendAll = QAction(QIcon(res.get("paste.png")),
                                     self.tr("Send to Public Paste"),
                                     self)
        self.actionSendAll.triggered.connect(self.send_all_slot)
        self.toolbar_s.add_action(self.actionSendAll)

        self.actionRetrieve = QAction(QIcon(res.get("download.png")),
                                     self.tr("Download from public paste"),
                                     self)
        self.actionRetrieve.triggered.connect(self.retrieve_slot)
        self.toolbar_s.add_action(self.actionRetrieve)

    def finish(self):
        #Shutdown your plugin
        pass

    def get_preferences_widget(self):
        aboutFrame = AboutFrame(self, self.service)
        aboutFrame.saved.connect(self.save_snippets_slot)
        return aboutFrame


# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == '__main__':
    print(__doc__)
