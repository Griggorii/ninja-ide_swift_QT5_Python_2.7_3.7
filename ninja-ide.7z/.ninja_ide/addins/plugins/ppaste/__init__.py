#!/usr/bin/env python
# -*- coding: utf-8 *-*

# THE WISKEY-WARE LICENSE
# -----------------------

# "THE WISKEY-WARE LICENSE":
# <jbc.develp@gmail.com>  wrote this file. As long as you retain this notice you
# can do whatever you want with this stuff. If we meet some day, and you think
# this stuff is worth it, you can buy me a wiskey in return JuanBC


#===============================================================================
# DOCS
#===============================================================================

"""Plugin for send code to public paste sites from  in ninja-ide

"""


#===============================================================================
# IMPORTS
#===============================================================================

import ninja_ppaste
from ninja_ppaste import NinjaPublicPaste


#===============================================================================
# META GATEWAY
#===============================================================================

__prj__ = ninja_ppaste.__prj__
__version__ = ninja_ppaste.__version__
__license__ = ninja_ppaste.__license__
__author__ = ninja_ppaste.__author__
__email__ = ninja_ppaste.__email__
__url__ = ninja_ppaste.__url__
__date__ = ninja_ppaste.__date__
__full_license__ = ninja_ppaste.__full_license__


#===============================================================================
# MAIN
#===============================================================================

if __name__ == '__main__':
    print(__doc__)