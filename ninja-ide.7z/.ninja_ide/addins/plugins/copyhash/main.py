# -*- coding: utf-8 -*-
# PEP8:OK, LINT:OK, PY3:OK


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Ninja copy hash "
__version__ = ' 0.1 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 15/12/2013 '
__prj__ = ' copyhash '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from os import path, listdir
from hashlib import md5, sha1, sha224, sha256, sha384, sha512

from PyQt4.QtGui import QAction, QMenu, QApplication

from ninja_ide.core import plugin


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.menu = QMenu('Copy Hash')
        self.menu.addActions([
            QAction('MD5', self, triggered=lambda:
                QApplication.clipboard().setText(self.hashit(md5))),
            QAction('SHA1', self, triggered=lambda:
                QApplication.clipboard().setText(self.hashit(sha1))),
            QAction('SHA224', self, triggered=lambda:
                QApplication.clipboard().setText(self.hashit(sha224))),
            QAction('SHA256', self, triggered=lambda:
                QApplication.clipboard().setText(self.hashit(sha256))),
            QAction('SHA384', self, triggered=lambda:
                QApplication.clipboard().setText(self.hashit(sha384))),
            QAction('SHA512', self, triggered=lambda:
                QApplication.clipboard().setText(self.hashit(sha512)))])
        self.ex_locator = self.locator.get_service('explorer')
        self.ex_locator.add_project_menu(self.menu, lang='all')

    def hashit(self, formato):
        """ hash a file or folder """
        file_or_dir = self.ex_locator.get_current_project_item().get_full_path()
        if self.ex_locator.get_current_project_item().isFolder is True:
            return self.hash_folder(file_or_dir, formato)
        else:
            return self.hash_file(file_or_dir, formato)

    def hash_file(self, filename, formato):
        """ hash a file """
        with open(filename, 'rb') as f:
            return str(formato(f.read()).hexdigest())

    def hash_folder(self, folder, fm):
        """ hash a folder """
        return str([(f, fm(open(path.join(folder, f), 'rb').read()).hexdigest())
                    for f in listdir(folder)
                    if path.isfile(path.join(folder, f)) and
                    not f.startswith('.')])


###############################################################################


if __name__ == "__main__":
    print(__doc__)
