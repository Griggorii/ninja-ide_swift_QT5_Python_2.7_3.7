# -*- coding: utf-8 -*-
# PEP8:NO, LINT:OK, PY3:NO


#############################################################################
## This file may be used under the terms of the GNU General Public
## License version 2.0 or 3.0 as published by the Free Software Foundation
## and appearing in the file LICENSE.GPL included in the packaging of
## this file.  Please review the following information to ensure GNU
## General Public Licensing requirements will be met:
## http:#www.fsf.org/licensing/licenses/info/GPLv2.html and
## http:#www.gnu.org/copyleft/gpl.html.
##
## This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
## WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#############################################################################


# metadata
" Continuous Integration "
__version__ = ' 0.2 '
__license__ = ' GPL '
__author__ = ' juancarlospaco '
__email__ = ' juancarlospaco@ubuntu.com '
__url__ = ''
__date__ = ' 05/09/2013 '
__prj__ = ' travis '
__docformat__ = 'html'
__source__ = ''
__full_licence__ = ''


# imports
from datetime import datetime
from getpass import getuser

from PyQt4.QtCore import Qt
from PyQt4.QtGui import (QAction, QCheckBox, QColor, QComboBox, QDialog,
                         QGraphicsDropShadowEffect, QGroupBox, QHBoxLayout,
                         QIcon, QLabel, QLineEdit, QPushButton, QVBoxLayout,
                         QWidget)

from ninja_ide.core import plugin


###############################################################################


class Main(plugin.Plugin):
    " Main Class "
    def initialize(self, *args, **kwargs):
        " Init Main Class "
        super(Main, self).initialize(*args, **kwargs)
        self.locator.get_service("menuApp").add_action(QAction(QIcon.fromTheme(
        "edit-select-all"), __doc__, self, triggered=lambda: self.get_dialog()))
        self.dialog = QDialog()
        self.metada = QCheckBox('Add Date and Time on a Comment')
        self.button = QPushButton('Generate YML File !')
        self.button.setMinimumSize(400, 50)
        self.button.clicked.connect(self.make_yml)
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0)
        glow.setBlurRadius(99)
        glow.setColor(QColor(99, 255, 255))
        self.button.setGraphicsEffect(glow)
        self.group1, self.group2 = QGroupBox(), QGroupBox()
        self.group1.setTitle('Travis')
        self.group2.setTitle('Travis')
        self.py25 = QCheckBox('Python 2.5 (Deprecated)')
        self.py26 = QCheckBox('Python 2.6 (Deprecated)')
        self.py27 = QCheckBox('Python 2.7 (Default)')
        self.py32, self.py33 = QCheckBox('Python 3.2'), QCheckBox('Python 3.3')
        self.pypy = QCheckBox('Python PyPy (Experimental)')
        self.cach = QCheckBox('Use Network-Local APT Cache for faster apt-get')
        self.mong, self.couc = QCheckBox('Mongo DB'), QCheckBox('Couch DB')
        self.elas, self.kres = QCheckBox('ElasticSearch'), QCheckBox('Kestrel')
        self.memc, self.rabb = QCheckBox('MemCacheD'), QCheckBox('RabbitMQ')
        self.redi, self.cass = QCheckBox('Redis'), QCheckBox('Cassandra')
        self.riak, self.neo4 = QCheckBox('Riak'), QCheckBox('Neo4J')
        [a.setChecked(True) for a in(self.metada, self.py27, self.cach)]
        self.b4in = QLineEdit('sudo apt-get update -qq')
        self.container = QWidget()
        self.inst = QLineEdit('pip install -r requirements.txt --use-mirrors')
        self.b4sc = QLineEdit('rm --recursive --force --verbose *.py[cod]')
        self.scrp = QLineEdit('nosetests --verbose --detailed-errors')
        self.sucs, self.when = QLineEdit('true'), QComboBox()
        self.when.addItems(['always', 'change', 'never'])
        self.mail = QLineEdit(getuser() + '@gmail.com')
        self.ircc = QLineEdit(getuser() + 's_channel')
        self.host = QLineEdit(getuser() + '-dev-server.com')
        help2 = QLabel('''<a href="https://travis-ci.org"><center>
                          GitHub Login to Travis Libre C.I.</a>''')
        help2.setTextInteractionFlags(Qt.LinksAccessibleByMouse)
        help2.setOpenExternalLinks(True)
        help3 = QLabel('''<a href="http://lint.travis-ci.org/"><center>
                          Travis Lint .travis.yml Config Validator</a>''')
        help3.setTextInteractionFlags(Qt.LinksAccessibleByMouse)
        help3.setOpenExternalLinks(True)
        vboxg1 = QVBoxLayout(self.group1)
        for each_widget in (QLabel('<b>Try to Build / Run / Test my App on'),
            self.py25, self.py26, self.py27, self.py32, self.py33, self.pypy,
            QLabel('<b>Bash command to run Before install your App'), self.b4in,
            QLabel('<b>Bash command to Install your App'), self.inst,
            QLabel('<b>Bash command to run Before C.I. process'), self.b4sc,
            QLabel('<b>Bash command to Build / Run / Test your App'), self.scrp,
            QLabel('<b>Bash command to run on Sucess of your App'), self.sucs,
            help2):
            vboxg1.addWidget(each_widget)
        vboxg2 = QVBoxLayout(self.group2)
        for each_widget in (QLabel('<b>Servers to Start on Boot'), self.mong,
            self.couc, self.elas, self.kres, self.memc, self.rabb, self.redi,
            self.cass, self.riak, self.neo4,
            QLabel('<b>Mail to send C.I. Notifications of your App'), self.mail,
            QLabel('<b>IRC to send C.I. Notifications of your App'), self.ircc,
            QLabel('<b>When to Send Notifications'), self.when,
            QLabel('<b>Custom Hostname DNS /etc/hosts for IPv4/6'), self.host,
            QLabel('<b>Cache'), self.cach, help3):
            vboxg2.addWidget(each_widget)

        hboxg, vboxg = QHBoxLayout(self.container), QVBoxLayout(self.dialog)
        [hboxg.addWidget(a) for a in (self.group1, self.group2)]
        for each_widget in (QLabel('<center><h3>' + __doc__), self.container,
            self.metada, QLabel('<center><small><i>' + ''.join((__doc__,
            __version__, __license__, 'by', __author__))), self.button):
            vboxg.addWidget(each_widget)
        self.guimode = QComboBox(self.dialog)
        self.guimode.addItems(['Full Mode', 'Simple Mode'])
        self.guimode.currentIndexChanged.connect(lambda: self.group2.show()
            if self.guimode.currentIndex() is 0 else self.group2.hide())

    def get_dialog(self):
        ' show dialog auto fill data '
        self.dialog.show()

    def make_yml(self):
        ' create YML file '
        tra = str('\n'.join((
            '# {} by {} .travis.yml Continuous Integration by Ninja-IDE'.format(
                datetime.now().isoformat().split('.')[0], getuser())
                if self.metada.isChecked() else '', ' ',
            'language: python',
            'python:',
            '  - 2.5  # Deprecated!' if self.py25.isChecked() else '',
            '  - 2.6  # Deprecated!' if self.py26.isChecked() else '',
            '  - 2.7' if self.py27.isChecked() else '',
            '  - 3.2' if self.py32.isChecked() else '',
            '  - 3.3' if self.py33.isChecked() else '',
            '  - pypy  # Experimental!' if self.pypy.isChecked() else '', ' ',
            'before_install:  # runs before installing your app',
            '  - "export DISPLAY=:99.0"  # turn on headless X emulator',
            '  - "sh -e /etc/init.d/xvfb start"  # turn on headless X emulator',
            '  - "{}"'.format(self.b4in.text()),
            '  - cd $TRAVIS_BUILD_DIR  # force to stay on build dir',
            ' ',
            'install: {}  # installs your app'.format(self.inst.text()), ' ',
            'before_script: {}  # run before your app'.format(self.b4sc.text()),
            ' ',
            'script: {}  # runs your app'.format(self.scrp.text()), ' ',
            'after_script: true  # runs after your app', ' ',
            'after_success: {}  # runs when sucess'.format(self.sucs.text()),
            ' ',
            'after_failure: {}  # runs when failed'.format(self.sucs.text()),
            ' ',
            'notifications:',
            '  irc:',
            '    channels: "irc.freenode.org#{}"'.format(self.ircc.text()),
            '    template:',
            '      - "%{repository}@%{branch}: %{message} ( %{build_url} )."',
            '      - "Build: %{build_number}, SHA: %{commit}."',
            '      - "Committer: %{author}, Diff: %{compare_url}."',
            '    on_success: {}'.format(self.when.currentText()),
            '    on_failure: {}'.format(self.when.currentText()),
            '    use_notice: true  # false to disable',
            '    email:',
            '      recipients: {}'.format(self.mail.text()),
            '      template:',
            '        - "%{repository}@%{branch}: %{message} ( %{build_url} )."',
            '        - "Build: %{build_number}, SHA: %{commit}."',
            '        - "Committer: %{author}, Diff: %{compare_url}."',
            '      on_success: {}'.format(self.when.currentText()),
            '      on_failure: {}'.format(self.when.currentText()), ' ',
            'cache: apt  # Cache APT packages' if self.cach.isChecked() else '',
            ' ',
            'addons:',
            '    hosts: {}  # /etc/hosts custom entry'.format(self.host.text()),
            ' ',
            'services:' if any((self.mong.checkState(), self.couc.checkState(),
                                self.elas.checkState(), self.kres.checkState(),
                                self.memc.checkState(), self.rabb.checkState(),
                                self.redi.checkState(), self.cass.checkState(),
                                self.riak.checkState(), self.neo4.checkState())
                                ) else '',
            '    - mongodb' if self.mong.isChecked() else '',
            '    - couchdb' if self.couc.isChecked() else '',
            '    - elasticsearch' if self.elas.isChecked() else '',
            '    - memcached' if self.memc.isChecked() else '',
            '    - rabbitmq' if self.rabb.isChecked() else '',
            '    - redis-server' if self.redi.isChecked() else '',
            '    - cassandra' if self.cass.isChecked() else '',
            '    - riak' if self.riak.isChecked() else '',
            '    - neo4j' if self.neo4.isChecked() else '',
            '    - kestrel' if self.kres.isChecked() else '',
        ))).strip()
        self.locator.get_service("editor").add_editor(content=tra, syntax='yml')
        self.dialog.hide()


###############################################################################


if __name__ == "__main__":
    print(__doc__)
