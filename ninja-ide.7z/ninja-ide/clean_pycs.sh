find . \( -name '*.pyc' -or -name '*.qmlc' -or -name '*.jsc' \) -type f -delete
