# -*- coding: utf-8 -*-

from ninja_ide.core import plugin


class TestPlugin(plugin.Plugin):
    pass
