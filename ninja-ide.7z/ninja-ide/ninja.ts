<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="ninja_ide/translations.py" line="9"/>
        <source>NINJA-IDE</source>
        <comment>&amp;File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="10"/>
        <source>NINJA-IDE</source>
        <comment>&amp;Edit</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="11"/>
        <source>NINJA-IDE</source>
        <comment>&amp;View</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="12"/>
        <source>NINJA-IDE</source>
        <comment>&amp;Source</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="13"/>
        <source>NINJA-IDE</source>
        <comment>&amp;Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="14"/>
        <source>NINJA-IDE</source>
        <comment>E&amp;xtensions</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="15"/>
        <source>NINJA-IDE</source>
        <comment>Abou&amp;t</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="18"/>
        <source>NINJA-IDE</source>
        <comment>Show Selector</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="19"/>
        <source>NINJA-IDE</source>
        <comment>NINJA-IDE (SESSION: %(session)s)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="20"/>
        <source>NINJA-IDE</source>
        <comment>Duplicate</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="21"/>
        <source>NINJA-IDE</source>
        <comment>Remove Line</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="22"/>
        <source>NINJA-IDE</source>
        <comment>Move Up</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="23"/>
        <source>NINJA-IDE</source>
        <comment>Move Down</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="24"/>
        <source>NINJA-IDE</source>
        <comment>Close File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="25"/>
        <source>NINJA-IDE</source>
        <comment>New File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="26"/>
        <source>NINJA-IDE</source>
        <comment>Open</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="27"/>
        <source>NINJA-IDE</source>
        <comment>Save</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="28"/>
        <source>NINJA-IDE</source>
        <comment>Save As</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="29"/>
        <source>NINJA-IDE</source>
        <comment>Save All</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="30"/>
        <source>NINJA-IDE</source>
        <comment>Undo</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="31"/>
        <source>NINJA-IDE</source>
        <comment>Redo</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="32"/>
        <source>NINJA-IDE</source>
        <comment>Comment</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="33"/>
        <source>NINJA-IDE</source>
        <comment>Uncomment</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="34"/>
        <source>NINJA-IDE</source>
        <comment>Insert Comment Title</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="35"/>
        <source>NINJA-IDE</source>
        <comment>Indent More</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="36"/>
        <source>NINJA-IDE</source>
        <comment>Indent Less</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="37"/>
        <source>NINJA-IDE</source>
        <comment>Show Split Assistance</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="38"/>
        <source>NINJA-IDE</source>
        <comment>Close Current Split</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="39"/>
        <source>NINJA-IDE</source>
        <comment>Split Editor Horizontally</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="40"/>
        <source>NINJA-IDE</source>
        <comment>Split Editor Vertically</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="41"/>
        <source>NINJA-IDE</source>
        <comment>Reload File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="42"/>
        <source>NINJA-IDE</source>
        <comment>Insert &amp;Import</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="43"/>
        <source>NINJA-IDE</source>
        <comment>Go To Definition</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="44"/>
        <source>NINJA-IDE</source>
        <comment>Python Help</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="45"/>
        <source>NINJA-IDE</source>
        <comment>Print File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="46"/>
        <source>NINJA-IDE</source>
        <comment>New Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="47"/>
        <source>NINJA-IDE</source>
        <comment>Choose a Template:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="48"/>
        <source>NINJA-IDE</source>
        <comment>Open Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="49"/>
        <source>NINJA-IDE</source>
        <comment>Save Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="50"/>
        <source>NINJA-IDE</source>
        <comment>Find in Files</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="51"/>
        <source>NINJA-IDE</source>
        <comment>Run File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="52"/>
        <source>NINJA-IDE</source>
        <comment>Run Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="53"/>
        <source>NINJA-IDE</source>
        <comment>Stop</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="54"/>
        <source>NINJA-IDE</source>
        <comment>Editor Schemes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="55"/>
        <source>NINJA-IDE</source>
        <comment>Language Manager</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="56"/>
        <source>NINJA-IDE</source>
        <comment>Plugins Store</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="406"/>
        <source>NINJA-IDE</source>
        <comment>Show Start Page</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="58"/>
        <source>NINJA-IDE</source>
        <comment>Report Bugs!</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="59"/>
        <source>NINJA-IDE</source>
        <comment>Plugins Documentation</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="60"/>
        <source>NINJA-IDE</source>
        <comment>About NINJA-IDE</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="61"/>
        <source>NINJA-IDE</source>
        <comment>About Qt</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="62"/>
        <source>NINJA-IDE</source>
        <comment>Python Documentation</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="63"/>
        <source>NINJA-IDE</source>
        <comment>How to Write NINJA-IDE Plugins</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="64"/>
        <source>NINJA-IDE</source>
        <comment>Cut</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="65"/>
        <source>NINJA-IDE</source>
        <comment>Copy</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="66"/>
        <source>NINJA-IDE</source>
        <comment>Paste</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="67"/>
        <source>NINJA-IDE</source>
        <comment>Find</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="68"/>
        <source>NINJA-IDE</source>
        <comment>Find and Replace</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="69"/>
        <source>NINJA-IDE</source>
        <comment>Code Locator</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="70"/>
        <source>NINJA-IDE</source>
        <comment>Convert Selected Text to: UPPER</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="71"/>
        <source>NINJA-IDE</source>
        <comment>Convert Selected Text to: lower</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="72"/>
        <source>NINJA-IDE</source>
        <comment>Convert Selected Text to: Title Word</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="73"/>
        <source>NINJA-IDE</source>
        <comment>Preferences</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="257"/>
        <source>NINJA-IDE</source>
        <comment>Activate Session</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="75"/>
        <source>NINJA-IDE</source>
        <comment>Deactivate Session</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="76"/>
        <source>NINJA-IDE</source>
        <comment>Close All Projects</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="77"/>
        <source>NINJA-IDE</source>
        <comment>Exit</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="78"/>
        <source>NINJA-IDE</source>
        <comment>Open Project Properties</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="79"/>
        <source>NINJA-IDE</source>
        <comment>Preview Web in Default Browser</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="80"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide &amp;Console</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="81"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide &amp;Editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="82"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide Tabs and &amp;Spaces</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="83"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide &amp;All</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="84"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide &amp;Explorer</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="85"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide &amp;Toolbar</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="86"/>
        <source>NINJA-IDE</source>
        <comment>Full Screen &amp;Mode</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="87"/>
        <source>NINJA-IDE</source>
        <comment>Zoom &amp;In  (Ctrl+Wheel-Up)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="88"/>
        <source>NINJA-IDE</source>
        <comment>Zoom &amp;Out  (Ctrl+Wheel-Down)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="89"/>
        <source>NINJA-IDE</source>
        <comment>Count Code Lines</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="90"/>
        <source>NINJA-IDE</source>
        <comment>Debugging Tricks</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="91"/>
        <source>NINJA-IDE</source>
        <comment>Insert Prints per Selected Line.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="92"/>
        <source>NINJA-IDE</source>
        <comment>Insert pdb.set_trace()</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="93"/>
        <source>NINJA-IDE</source>
        <comment>&amp;Remove Trailing Spaces</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="94"/>
        <source>NINJA-IDE</source>
        <comment>Replace Tabs With &amp;Spaces</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="95"/>
        <source>NINJA-IDE</source>
        <comment>Close Split</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="96"/>
        <source>NINJA-IDE</source>
        <comment>Right click to change navigation options</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="98"/>
        <source>NINJA-IDE</source>
        <comment>Code Jumps</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="99"/>
        <source>NINJA-IDE</source>
        <comment>Bookmarks</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="100"/>
        <source>NINJA-IDE</source>
        <comment>Breakpoints</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="101"/>
        <source>NINJA-IDE</source>
        <comment>New Document</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="102"/>
        <source>NINJA-IDE</source>
        <comment> (Read-Only)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="103"/>
        <source>NINJA-IDE</source>
        <comment>no description available</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="104"/>
        <source>NINJA-IDE</source>
        <comment>Left-Click to change File.
Right-Click to see Options.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="107"/>
        <source>NINJA-IDE</source>
        <comment>Add to Project...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="108"/>
        <source>NINJA-IDE</source>
        <comment>Change Syntax</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="109"/>
        <source>NINJA-IDE</source>
        <comment>Close All Files</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="110"/>
        <source>NINJA-IDE</source>
        <comment>Close All Files But This</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="111"/>
        <source>NINJA-IDE</source>
        <comment>Copy File Location to Clipboard</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="114"/>
        <source>NINJA-IDE</source>
        <comment>Show File in Explorer</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="115"/>
        <source>NINJA-IDE</source>
        <comment>Reopen Last Closed File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="116"/>
        <source>NINJA-IDE</source>
        <comment>Undock Editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="117"/>
        <source>NINJA-IDE</source>
        <comment>Click for Project Options.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="118"/>
        <source>NINJA-IDE</source>
        <comment>Undock</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="119"/>
        <source>NINJA-IDE</source>
        <comment>Projects</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="120"/>
        <source>NINJA-IDE</source>
        <comment>Symbols</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="121"/>
        <source>NINJA-IDE</source>
        <comment>Errors</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="122"/>
        <source>NINJA-IDE</source>
        <comment>Migration 2to3</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="123"/>
        <source>NINJA-IDE</source>
        <comment>Web Inspector</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="124"/>
        <source>NINJA-IDE</source>
        <comment>Your Qt version doesn&apos;t support the Web Inspector</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="127"/>
        <source>NINJA-IDE</source>
        <comment>Add File to Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="128"/>
        <source>NINJA-IDE</source>
        <comment>Cancel</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="129"/>
        <source>NINJA-IDE</source>
        <comment>Choose</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="130"/>
        <source>NINJA-IDE</source>
        <comment>Add Here!</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="131"/>
        <source>NINJA-IDE</source>
        <comment>Undock Tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="135"/>
        <source>NINJA-IDE</source>
        <comment>Project Properties</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="136"/>
        <source>NINJA-IDE</source>
        <comment>Project Data</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="137"/>
        <source>NINJA-IDE</source>
        <comment>Project Execution</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="138"/>
        <source>NINJA-IDE</source>
        <comment>Project Metadata</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="139"/>
        <source>NINJA-IDE</source>
        <comment>Name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="140"/>
        <source>NINJA-IDE</source>
        <comment>Project Location:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="141"/>
        <source>NINJA-IDE</source>
        <comment>Project Type:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="142"/>
        <source>NINJA-IDE</source>
        <comment>Description:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="143"/>
        <source>NINJA-IDE</source>
        <comment>URL:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="144"/>
        <source>NINJA-IDE</source>
        <comment>Licence:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="409"/>
        <source>NINJA-IDE</source>
        <comment>Supported Extensions:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="146"/>
        <source>NINJA-IDE</source>
        <comment>Indentation:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="147"/>
        <source>NINJA-IDE</source>
        <comment>Use Tabs.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="148"/>
        <source>NINJA-IDE</source>
        <comment>Properties Invalid</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="149"/>
        <source>NINJA-IDE</source>
        <comment>The project must have a name.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="150"/>
        <source>NINJA-IDE</source>
        <comment>Main File:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="151"/>
        <source>NINJA-IDE</source>
        <comment>Python Custom Interpreter:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="152"/>
        <source>NINJA-IDE</source>
        <comment>Custom PYTHONPATH:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="153"/>
        <source>NINJA-IDE</source>
        <comment>One path per line</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="154"/>
        <source>NINJA-IDE</source>
        <comment>Additional builtins/globals:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="623"/>
        <source>NINJA-IDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="159"/>
        <source>NINJA-IDE</source>
        <comment>Pre-exec Script:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="160"/>
        <source>NINJA-IDE</source>
        <comment>Post-exec Script:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="161"/>
        <source>NINJA-IDE</source>
        <comment>Properties</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="162"/>
        <source>NINJA-IDE</source>
        <comment>Separate the params with commas (ie: help, verbose)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="165"/>
        <source>NINJA-IDE</source>
        <comment>Params (comma separated):</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="166"/>
        <source>NINJA-IDE</source>
        <comment>Virtualenv Folder:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="412"/>
        <source>NINJA-IDE</source>
        <comment>Select Python Path</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="168"/>
        <source>NINJA-IDE</source>
        <comment>Select Virtualenv Folder</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="169"/>
        <source>NINJA-IDE</source>
        <comment>Virtualenv Folder</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="172"/>
        <source>NINJA-IDE</source>
        <comment>This is not a valid Virtualenv Folder</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="175"/>
        <source>NINJA-IDE</source>
        <comment>Select Main File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="176"/>
        <source>NINJA-IDE</source>
        <comment>Select Pre Execution Script File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="179"/>
        <source>NINJA-IDE</source>
        <comment>Select Post Execution Script File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="186"/>
        <source>NINJA-IDE</source>
        <comment>Split your paths using newlines [ENTER].</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="195"/>
        <source>NINJA-IDE</source>
        <comment>Mouse over supported extensions for instructions</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="201"/>
        <source>NINJA-IDE</source>
        <comment>@<byte value="x9"/>(Filter only by Files)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="202"/>
        <source>NINJA-IDE</source>
        <comment>&lt;<byte value="x9"/>(Filter only by Classes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="203"/>
        <source>NINJA-IDE</source>
        <comment>&gt;<byte value="x9"/>(Filter only by Methods)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="204"/>
        <source>NINJA-IDE</source>
        <comment>-<byte value="x9"/>(Filter only by Attributes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="205"/>
        <source>NINJA-IDE</source>
        <comment>.<byte value="x9"/>(Filter only by Classes and Methods in this File)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="208"/>
        <source>NINJA-IDE</source>
        <comment>/<byte value="x9"/>(Filter only by the current Editors)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="211"/>
        <source>NINJA-IDE</source>
        <comment>:<byte value="x9"/>(Go to Line)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="212"/>
        <source>NINJA-IDE</source>
        <comment>!<byte value="x9"/>(Filter only by Non Python Files)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="213"/>
        <source>NINJA-IDE</source>
        <comment>No results were found!</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="214"/>
        <source>NINJA-IDE</source>
        <comment>Definition Not Found</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="215"/>
        <source>NINJA-IDE</source>
        <comment>This Definition does not belong to this Project.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="218"/>
        <source>NINJA-IDE</source>
        <comment>Session active</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="221"/>
        <source>NINJA-IDE</source>
        <comment>Session: %(session)s still active, do you want to update this session with the current files and projects before closing?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="225"/>
        <source>NINJA-IDE</source>
        <comment>Some changes were not saved</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="226"/>
        <source>NINJA-IDE</source>
        <comment>%(files)s

Do you want to save them?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="229"/>
        <source>NINJA-IDE</source>
        <comment>Press and Drag to Move</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="233"/>
        <source>NINJA-IDE</source>
        <comment>Case Sensitive</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="234"/>
        <source>NINJA-IDE</source>
        <comment>Find Whole Words</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="238"/>
        <source>NINJA-IDE</source>
        <comment>Display Errors and Warnings</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="239"/>
        <source>NINJA-IDE</source>
        <comment>PEP8 Violations: </comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="240"/>
        <source>NINJA-IDE</source>
        <comment>Lint Errors: </comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="244"/>
        <source>NINJA-IDE</source>
        <comment>NINJA-IDE - Preferences</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="245"/>
        <source>NINJA-IDE</source>
        <comment>Sessions Manager</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="246"/>
        <source>NINJA-IDE</source>
        <comment>Save your opened files and projects into a session and change really quick
between projects and files sessions.
This allows you to save your working environment, keep working in another
project and then go back exactly where you left.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="254"/>
        <source>NINJA-IDE</source>
        <comment>Delete Session</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="255"/>
        <source>NINJA-IDE</source>
        <comment>Update Session</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="256"/>
        <source>NINJA-IDE</source>
        <comment>Create New Session</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="258"/>
        <source>NINJA-IDE</source>
        <comment>Create Session</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="259"/>
        <source>NINJA-IDE</source>
        <comment>The Current Files and Projects will be associated to this session.
Session Name:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="263"/>
        <source>NINJA-IDE</source>
        <comment>Session Name Invalid</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="264"/>
        <source>NINJA-IDE</source>
        <comment>The Session name is invalid or already exists.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="267"/>
        <source>NINJA-IDE</source>
        <comment>Session %(session)s Updated!</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="268"/>
        <source>NINJA-IDE</source>
        <comment>File has been modified</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="269"/>
        <source>NINJA-IDE</source>
        <comment>
The file has been modified outside the application
Do you want to reload it?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="276"/>
        <source>NINJA-IDE</source>
        <comment>Text to Replace</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="277"/>
        <source>NINJA-IDE</source>
        <comment>File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="278"/>
        <source>NINJA-IDE</source>
        <comment>Line</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="279"/>
        <source>NINJA-IDE</source>
        <comment>Replace:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="280"/>
        <source>NINJA-IDE</source>
        <comment>C&amp;ase Sensitive</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="281"/>
        <source>NINJA-IDE</source>
        <comment>R&amp;egular Expression</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="282"/>
        <source>NINJA-IDE</source>
        <comment>Rec&amp;ursive</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="283"/>
        <source>NINJA-IDE</source>
        <comment>Search by Phrase (Exact Match)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="284"/>
        <source>NINJA-IDE</source>
        <comment>Options</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="285"/>
        <source>NINJA-IDE</source>
        <comment>Search for all the words (anywhere in the document, not together).</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="288"/>
        <source>NINJA-IDE</source>
        <comment>Main</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="289"/>
        <source>NINJA-IDE</source>
        <comment>Directory:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="290"/>
        <source>NINJA-IDE</source>
        <comment>Filter:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="291"/>
        <source>NINJA-IDE</source>
        <comment>Text:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="292"/>
        <source>NINJA-IDE</source>
        <comment>Clear</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="293"/>
        <source>NINJA-IDE</source>
        <comment>Replace Results With:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="294"/>
        <source>NINJA-IDE</source>
        <comment>Are you sure you want to replace the content in this files?
(The change is not reversible)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="298"/>
        <source>NINJA-IDE</source>
        <comment>Replace File Contents</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="299"/>
        <source>NINJA-IDE</source>
        <comment>Console</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="300"/>
        <source>NINJA-IDE</source>
        <comment>Output</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="301"/>
        <source>NINJA-IDE</source>
        <comment>Web Preview</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="302"/>
        <source>NINJA-IDE</source>
        <comment>Content</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="303"/>
        <source>NINJA-IDE</source>
        <comment>Shortcut</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="304"/>
        <source>NINJA-IDE</source>
        <comment>Accept</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="308"/>
        <source>NINJA-IDE</source>
        <comment>Remove Line/Selection</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="309"/>
        <source>NINJA-IDE</source>
        <comment>Move Line/Selection Up</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="310"/>
        <source>NINJA-IDE</source>
        <comment>Move Line/Selection Down</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="311"/>
        <source>NINJA-IDE</source>
        <comment>Close Current Tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="312"/>
        <source>NINJA-IDE</source>
        <comment>New Tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="601"/>
        <source>NINJA-IDE</source>
        <comment>Save Current Project (All Open Files)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="606"/>
        <source>NINJA-IDE</source>
        <comment>Hide Misc Container</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="315"/>
        <source>NINJA-IDE</source>
        <comment>Hide Editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="608"/>
        <source>NINJA-IDE</source>
        <comment>Hide Explorer</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="610"/>
        <source>NINJA-IDE</source>
        <comment>Execute Current File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="611"/>
        <source>NINJA-IDE</source>
        <comment>Execute Current Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="612"/>
        <source>NINJA-IDE</source>
        <comment>Debug</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="613"/>
        <source>NINJA-IDE</source>
        <comment>Switch Keyboard Focus</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="614"/>
        <source>NINJA-IDE</source>
        <comment>Stop Execution</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="322"/>
        <source>NINJA-IDE</source>
        <comment>Find Next</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="323"/>
        <source>NINJA-IDE</source>
        <comment>Find Previous</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="324"/>
        <source>NINJA-IDE</source>
        <comment>Show Python Help</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="325"/>
        <source>NINJA-IDE</source>
        <comment>Split Tabs Vertically</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="326"/>
        <source>NINJA-IDE</source>
        <comment>Split Tabs Horizontally</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="618"/>
        <source>NINJA-IDE</source>
        <comment>Activate/Deactivate Follow Mode</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="328"/>
        <source>NINJA-IDE</source>
        <comment>Jump to line</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="329"/>
        <source>NINJA-IDE</source>
        <comment>Import From Everywhere</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="330"/>
        <source>NINJA-IDE</source>
        <comment>Complete Declarations</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="331"/>
        <source>NINJA-IDE</source>
        <comment>Show Code Locator</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="332"/>
        <source>NINJA-IDE</source>
        <comment>Show File Opener</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="333"/>
        <source>NINJA-IDE</source>
        <comment>Go Back</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="334"/>
        <source>NINJA-IDE</source>
        <comment>Go Forward</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="335"/>
        <source>NINJA-IDE</source>
        <comment>Open Recently Closed File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="336"/>
        <source>NINJA-IDE</source>
        <comment>Change to Next Tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="337"/>
        <source>NINJA-IDE</source>
        <comment>Change to Previous Tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="338"/>
        <source>NINJA-IDE</source>
        <comment>Move Tab Right</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="339"/>
        <source>NINJA-IDE</source>
        <comment>Move Tab Left</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="340"/>
        <source>NINJA-IDE</source>
        <comment>Activate Navigation History</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="341"/>
        <source>NINJA-IDE</source>
        <comment>Activate Navigation Breakpoints</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="342"/>
        <source>NINJA-IDE</source>
        <comment>Activate Navigation Bookmarks</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="343"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide Clipboard history</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="344"/>
        <source>NINJA-IDE</source>
        <comment>Copy to Clipboard History</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="345"/>
        <source>NINJA-IDE</source>
        <comment>Paste from Clipboard History</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="627"/>
        <source>NINJA-IDE</source>
        <comment>Switch Between Current Splits</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="349"/>
        <source>NINJA-IDE</source>
        <comment>Insert Bookmark/Breakpoint</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="630"/>
        <source>NINJA-IDE</source>
        <comment>Move Current Tab to Next Split</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="351"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide Tabs in Editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="352"/>
        <source>NINJA-IDE</source>
        <comment>Show Indentation Guide</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="353"/>
        <source>NINJA-IDE</source>
        <comment>Highlight Occurrences of Word Under Cursor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="633"/>
        <source>NINJA-IDE</source>
        <comment>Load Defaults</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="634"/>
        <source>NINJA-IDE</source>
        <comment>Menu item shortcuts will be refreshed on restart.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="360"/>
        <source>NINJA-IDE</source>
        <comment>Shortcut is already in use, do you want to remove it?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="366"/>
        <source>NINJA-IDE</source>
        <comment>General</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="367"/>
        <source>NINJA-IDE</source>
        <comment>Interface</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="368"/>
        <source>NINJA-IDE</source>
        <comment>Plugins</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="369"/>
        <source>NINJA-IDE</source>
        <comment>Theme</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="370"/>
        <source>NINJA-IDE</source>
        <comment>Editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="371"/>
        <source>NINJA-IDE</source>
        <comment>Configuration</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="372"/>
        <source>NINJA-IDE</source>
        <comment>Completion</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="373"/>
        <source>NINJA-IDE</source>
        <comment>Scheme Designer</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="374"/>
        <source>NINJA-IDE</source>
        <comment>Shortcuts</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="375"/>
        <source>NINJA-IDE</source>
        <comment>Execution</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="376"/>
        <source>NINJA-IDE</source>
        <comment>This section shows the configurations exposed by the Plugins.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="379"/>
        <source>NINJA-IDE</source>
        <comment>On Start:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="380"/>
        <source>NINJA-IDE</source>
        <comment>On Close:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="647"/>
        <source>NINJA-IDE</source>
        <comment>Workspace and Project:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="382"/>
        <source>NINJA-IDE</source>
        <comment>Reset NINJA-IDE Preferences:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="383"/>
        <source>NINJA-IDE</source>
        <comment>Load Files from Last Session</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="386"/>
        <source>NINJA-IDE</source>
        <comment>Activate Plugins</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="387"/>
        <source>NINJA-IDE</source>
        <comment>Notify me of new updates.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="390"/>
        <source>NINJA-IDE</source>
        <comment>Explorer Panel:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="391"/>
        <source>NINJA-IDE</source>
        <comment>Tool Bar Customization:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="393"/>
        <source>NINJA-IDE</source>
        <comment>Language:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="395"/>
        <source>NINJA-IDE</source>
        <comment>Show Project Explorer.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="396"/>
        <source>NINJA-IDE</source>
        <comment>Show Symbols List.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="397"/>
        <source>NINJA-IDE</source>
        <comment>Show Web Inspector.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="398"/>
        <source>NINJA-IDE</source>
        <comment>Show File Errors.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="399"/>
        <source>NINJA-IDE</source>
        <comment>Toolbar Items:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="400"/>
        <source>NINJA-IDE</source>
        <comment>Default Items</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="401"/>
        <source>NINJA-IDE</source>
        <comment>The New Item will be inserted after the item selected.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="403"/>
        <source>NINJA-IDE</source>
        <comment>Select Language:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="404"/>
        <source>NINJA-IDE</source>
        <comment>Requires restart...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="405"/>
        <source>NINJA-IDE</source>
        <comment>Show Migration Tips.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="407"/>
        <source>NINJA-IDE</source>
        <comment>Confirm Exit.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="408"/>
        <source>NINJA-IDE</source>
        <comment>Workspace</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="410"/>
        <source>NINJA-IDE</source>
        <comment>Reset Preferences</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="411"/>
        <source>NINJA-IDE</source>
        <comment>Select Workspace</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="415"/>
        <source>NINJA-IDE</source>
        <comment>Reset Preferences?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="416"/>
        <source>NINJA-IDE</source>
        <comment>Are you sure you want to reset your preferences?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="419"/>
        <source>NINJA-IDE</source>
        <comment>Indentation Length</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="420"/>
        <source>NINJA-IDE</source>
        <comment>Tabs</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="421"/>
        <source>NINJA-IDE</source>
        <comment>Spaces</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="422"/>
        <source>NINJA-IDE</source>
        <comment>Line Margin</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="423"/>
        <source>NINJA-IDE</source>
        <comment>Show Line At</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="424"/>
        <source>NINJA-IDE</source>
        <comment>Use Platform End-Of-Line</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="427"/>
        <source>NINJA-IDE</source>
        <comment>Using Underline</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="430"/>
        <source>NINJA-IDE</source>
        <comment>Using Background</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="433"/>
        <source>NINJA-IDE</source>
        <comment>Highlight Errors</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="434"/>
        <source>NINJA-IDE</source>
        <comment>Show Lint Error Tooltip Information</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="437"/>
        <source>NINJA-IDE</source>
        <comment>Highlight PEP8 Style Errors</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="440"/>
        <source>NINJA-IDE</source>
        <comment>Show PEP8 Error Tooltip Information</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="443"/>
        <source>NINJA-IDE</source>
        <comment>Show Python3 Migration Tips.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="446"/>
        <source>NINJA-IDE</source>
        <comment>Center on Scroll</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="447"/>
        <source>NINJA-IDE</source>
        <comment>Remove Trailing Spaces and
Add Last Line Automatically</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="450"/>
        <source>NINJA-IDE</source>
        <comment>Show Tabs and Spaces</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="453"/>
        <source>NINJA-IDE</source>
        <comment>Allow Word Wrap.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="454"/>
        <source>NINJA-IDE</source>
        <comment>Check for Missing Docstrings.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="457"/>
        <source>NINJA-IDE</source>
        <comment>Download Schemes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="458"/>
        <source>NINJA-IDE</source>
        <comment>MiniMap:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="459"/>
        <source>NINJA-IDE</source>
        <comment>Typography:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="460"/>
        <source>NINJA-IDE</source>
        <comment>Scheme color:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="461"/>
        <source>NINJA-IDE</source>
        <comment>Use MiniMap 
 (Requires restart, 
 Opacity unsupported on OsX)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="464"/>
        <source>NINJA-IDE</source>
        <comment>Opacity</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="465"/>
        <source>NINJA-IDE</source>
        <comment>Size</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="466"/>
        <source>NINJA-IDE</source>
        <comment>% Area relative to editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="468"/>
        <source>NINJA-IDE</source>
        <comment>Editor Font:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="471"/>
        <source>NINJA-IDE</source>
        <comment>Invalid Font</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="474"/>
        <source>NINJA-IDE</source>
        <comment>This font can not be used in the editor.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="477"/>
        <source>NINJA-IDE</source>
        <comment>Characters</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="478"/>
        <source>NINJA-IDE</source>
        <comment>Typing Assistance</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="479"/>
        <source>NINJA-IDE</source>
        <comment>Highlighter Extras</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="480"/>
        <source>NINJA-IDE</source>
        <comment>Create Scheme</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="481"/>
        <source>NINJA-IDE</source>
        <comment>Remove scheme</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="482"/>
        <source>NINJA-IDE</source>
        <comment>Pick Color</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="486"/>
        <source>NINJA-IDE</source>
        <comment>Fold</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="487"/>
        <source>NINJA-IDE</source>
        <comment>Unfold</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="488"/>
        <source>NINJA-IDE</source>
        <comment>Fold All</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="489"/>
        <source>NINJA-IDE</source>
        <comment>Unfold All</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="490"/>
        <source>NINJA-IDE</source>
        <comment>Unfold Classes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="491"/>
        <source>NINJA-IDE</source>
        <comment>Unfold Classes and Methods</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="492"/>
        <source>NINJA-IDE</source>
        <comment>Unfold Classes and Attributes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="495"/>
        <source>NINJA-IDE</source>
        <comment>Fold Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="496"/>
        <source>NINJA-IDE</source>
        <comment>Unfold Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="497"/>
        <source>NINJA-IDE</source>
        <comment>Attributes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="498"/>
        <source>NINJA-IDE</source>
        <comment>Functions</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="499"/>
        <source>NINJA-IDE</source>
        <comment>Classes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="500"/>
        <source>NINJA-IDE</source>
        <comment>Filename</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="501"/>
        <source>NINJA-IDE</source>
        <comment>Invalid Filename</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="502"/>
        <source>NINJA-IDE</source>
        <comment>The filename is empty, please enter a filename</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="508"/>
        <source>NINJA-IDE</source>
        <comment>Set as Main Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="509"/>
        <source>NINJA-IDE</source>
        <comment>Remove this project from the Python console</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="512"/>
        <source>NINJA-IDE</source>
        <comment>Add this project to the Python console</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="515"/>
        <source>NINJA-IDE</source>
        <comment>Close Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="516"/>
        <source>NINJA-IDE</source>
        <comment>Add New File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="517"/>
        <source>NINJA-IDE</source>
        <comment>Add New Folder</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="518"/>
        <source>NINJA-IDE</source>
        <comment>Enter New Folder Name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="519"/>
        <source>NINJA-IDE</source>
        <comment>Create &apos;__init__.py&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="520"/>
        <source>NINJA-IDE</source>
        <comment>Create &apos;__init__.py&apos; Failed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="521"/>
        <source>NINJA-IDE</source>
        <comment>Remove Folder</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="522"/>
        <source>NINJA-IDE</source>
        <comment>Rename File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="523"/>
        <source>NINJA-IDE</source>
        <comment>Move File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="524"/>
        <source>NINJA-IDE</source>
        <comment>Copy File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="525"/>
        <source>NINJA-IDE</source>
        <comment>Delete File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="526"/>
        <source>NINJA-IDE</source>
        <comment>Do you want to delete the following file?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="529"/>
        <source>NINJA-IDE</source>
        <comment>Do you want to delete the following folder?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="532"/>
        <source>NINJA-IDE</source>
        <comment>Edit UI file</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="533"/>
        <source>NINJA-IDE</source>
        <comment>Enter New File Name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="534"/>
        <source>NINJA-IDE</source>
        <comment>Open Project Directory</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="535"/>
        <source>NINJA-IDE</source>
        <comment>Copy File To</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="536"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide Filesize Info</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="540"/>
        <source>NINJA-IDE</source>
        <comment>Traceback</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="541"/>
        <source>NINJA-IDE</source>
        <comment>Some plugins have errors and were removed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="544"/>
        <source>NINJA-IDE</source>
        <comment>Plugin Error Report</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="548"/>
        <source>NINJA-IDE</source>
        <comment>Plugin Manager</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="549"/>
        <source>NINJA-IDE</source>
        <comment>Close</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="550"/>
        <source>NINJA-IDE</source>
        <comment>Reload</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="551"/>
        <source>NINJA-IDE</source>
        <comment>Official Available</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="552"/>
        <source>NINJA-IDE</source>
        <comment>Community Available</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="553"/>
        <source>NINJA-IDE</source>
        <comment>Update</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="554"/>
        <source>NINJA-IDE</source>
        <comment>Install</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="555"/>
        <source>NINJA-IDE</source>
        <comment>Uninstall</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="556"/>
        <source>NINJA-IDE</source>
        <comment>Installed</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="557"/>
        <source>NINJA-IDE</source>
        <comment>Manual Install</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="558"/>
        <source>NINJA-IDE</source>
        <comment>Version</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="559"/>
        <source>NINJA-IDE</source>
        <comment>Select Plugin Path</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="560"/>
        <source>NINJA-IDE</source>
        <comment>External Plugin</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="561"/>
        <source>NINJA-IDE</source>
        <comment>URL is missing</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="562"/>
        <source>NINJA-IDE</source>
        <comment>NINJA needs to be restarted for changes to take effect</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="565"/>
        <source>NINJA-IDE</source>
        <comment>Requirements</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="566"/>
        <source>NINJA-IDE</source>
        <comment>It seems that some plugins have unresolved dependencies,
    you should install them as follows (at the command line)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="573"/>
        <source>NINJA-IDE</source>
        <comment>Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="574"/>
        <source>NINJA-IDE</source>
        <comment>Files</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="578"/>
        <source>NINJA-IDE</source>
        <comment>Complete:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="579"/>
        <source>NINJA-IDE</source>
        <comment>Parentheses:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="580"/>
        <source>NINJA-IDE</source>
        <comment>Keys:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="581"/>
        <source>NINJA-IDE</source>
        <comment>Brackets:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="582"/>
        <source>NINJA-IDE</source>
        <comment>Simple Quotes:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="583"/>
        <source>NINJA-IDE</source>
        <comment>Double Quotes:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="584"/>
        <source>NINJA-IDE</source>
        <comment>Complete Declarations
(execute the opposite action with: {0}).</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="587"/>
        <source>NINJA-IDE</source>
        <comment>Code Completion:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="588"/>
        <source>NINJA-IDE</source>
        <comment>Activate Code Completion With: &quot;.&quot;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="594"/>
        <source>NINJA-IDE</source>
        <comment>Expand File Combo</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="595"/>
        <source>NINJA-IDE</source>
        <comment>Expand Symbol Combo</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="596"/>
        <source>NINJA-IDE</source>
        <comment>Duplicate Line/Selection</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="597"/>
        <source>NINJA-IDE</source>
        <comment>Create New Tab</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="598"/>
        <source>NINJA-IDE</source>
        <comment>Create New Project</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="599"/>
        <source>NINJA-IDE</source>
        <comment>Open File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="600"/>
        <source>NINJA-IDE</source>
        <comment>Save Current File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="602"/>
        <source>NINJA-IDE</source>
        <comment>Print Current File</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="603"/>
        <source>NINJA-IDE</source>
        <comment>Comment Line/Selection</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="604"/>
        <source>NINJA-IDE</source>
        <comment>Uncomment Line/Selection</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="605"/>
        <source>NINJA-IDE</source>
        <comment>Insert Horizontal line</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="607"/>
        <source>NINJA-IDE</source>
        <comment>Hide Editor Area</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="609"/>
        <source>NINJA-IDE</source>
        <comment>Show/Hide Tabs and Spaces</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="615"/>
        <source>NINJA-IDE</source>
        <comment>Hide All (Except Editor)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="616"/>
        <source>NINJA-IDE</source>
        <comment>Full Screen</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="617"/>
        <source>NINJA-IDE</source>
        <comment>Find Word Under Cursor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="619"/>
        <source>NINJA-IDE</source>
        <comment>Navigate Back</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="620"/>
        <source>NINJA-IDE</source>
        <comment>Navigate Forward</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="621"/>
        <source>NINJA-IDE</source>
        <comment>Activate History Navigation</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="624"/>
        <source>NINJA-IDE</source>
        <comment>Show Copy/Paste History</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="625"/>
        <source>NINJA-IDE</source>
        <comment>Copy to Copy/Paste History</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="626"/>
        <source>NINJA-IDE</source>
        <comment>Paste From Copy/Paste History</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="631"/>
        <source>NINJA-IDE</source>
        <comment>Shortcut Is Already in Use</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="632"/>
        <source>NINJA-IDE</source>
        <comment>Do you want to remove it?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="637"/>
        <source>NINJA-IDE</source>
        <comment>Notification</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="638"/>
        <source>NINJA-IDE</source>
        <comment>Position On Screen</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="639"/>
        <source>NINJA-IDE</source>
        <comment>left</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="640"/>
        <source>NINJA-IDE</source>
        <comment>right</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="641"/>
        <source>NINJA-IDE</source>
        <comment>top</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="642"/>
        <source>NINJA-IDE</source>
        <comment>bottom</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="645"/>
        <source>NINJA-IDE</source>
        <comment>Select Python executable</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="646"/>
        <source>NINJA-IDE</source>
        <comment>Python Exec:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="648"/>
        <source>NINJA-IDE</source>
        <comment>-B: don&apos;t write .py[co] files on import</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="651"/>
        <source>NINJA-IDE</source>
        <comment>-d: debug output from parser</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="652"/>
        <source>NINJA-IDE</source>
        <comment>-E: ignore PYTHON* environment variables (such as PYTHONPATH)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="655"/>
        <source>NINJA-IDE</source>
        <comment>-O: optimize generated bytecode slightly</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="658"/>
        <source>NINJA-IDE</source>
        <comment>-OO: remove doc-strings in addition to the -O optimizations</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="661"/>
        <source>NINJA-IDE</source>
        <comment>-Q: division options:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="662"/>
        <source>NINJA-IDE</source>
        <comment>-s: don&apos;t add user site directory to sys.path</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="665"/>
        <source>NINJA-IDE</source>
        <comment>-S: don&apos;t imply &apos;import site&apos; on initialization</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="668"/>
        <source>NINJA-IDE</source>
        <comment>-t: issue warnings about inconsistent tab usage</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="671"/>
        <source>NINJA-IDE</source>
        <comment>-tt: issue errors about inconsistent tab usage</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="674"/>
        <source>NINJA-IDE</source>
        <comment>-v: verbose (trace import statements)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="677"/>
        <source>NINJA-IDE</source>
        <comment>-W: warning control:</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="678"/>
        <source>NINJA-IDE</source>
        <comment>-x: skip first line of source</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="679"/>
        <source>NINJA-IDE</source>
        <comment>-3: warn about Python 3.x incompatibilities that 2to3 cannot trivially fix</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="686"/>
        <source>NINJA-IDE</source>
        <comment>Current code</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="687"/>
        <source>NINJA-IDE</source>
        <comment>Suggested code</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="688"/>
        <source>NINJA-IDE</source>
        <comment>Apply changes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="689"/>
        <source>NINJA-IDE</source>
        <comment>Save the file before applying changes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="693"/>
        <source>NINJA-IDE</source>
        <comment>Insert at line</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="694"/>
        <source>NINJA-IDE</source>
        <comment>with comment</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="695"/>
        <source>NINJA-IDE</source>
        <comment>Add</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="699"/>
        <source>NINJA-IDE</source>
        <comment>Code</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="700"/>
        <source>NINJA-IDE</source>
        <comment>Preview</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="701"/>
        <source>NINJA-IDE</source>
        <comment>The name you have chosen is invalid. 
Please pick a different name.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="705"/>
        <source>NINJA-IDE</source>
        <comment>Do you want to overwrite the file</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ninja_ide/translations.py" line="706"/>
        <source>NINJA-IDE</source>
        <comment>The scheme has been saved</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
